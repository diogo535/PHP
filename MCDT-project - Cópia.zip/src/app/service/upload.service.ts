import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpEvent, HttpErrorResponse, HttpEventType } from '@angular/common/http';
import { map } from 'rxjs/operators';
//apiservice
import { APIService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  uploadURL:string;
  rootUrl:string;

  constructor(private httpClient: HttpClient, private apiservice: APIService) {
     this.rootUrl = this.apiservice.getRestServer();
  }

  public uploadFile(data, token, rowID, pedidoID, id_formulario) {
    return this.httpClient.post<any>(this.rootUrl+"services/upload.php?token="+ token +"&row_id="+ rowID +"&pedido_id=" + pedidoID + '&form_id='+id_formulario, data);
  }
}
