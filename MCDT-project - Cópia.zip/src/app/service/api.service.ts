import { Injectable, Inject } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { Location } from '@angular/common';
import { Router } from '@angular/router';
import { Componente } from '../Classes/componente';

import Swal from 'sweetalert2/dist/sweetalert2.js'
import 'sweetalert2/src/sweetalert2.scss'
declare var $: any;
import { BehaviorSubject ,  Observable, Subscription } from 'rxjs';
import { NavbarComponent } from '../component/navbar/navbar.component';

import * as moment from 'moment';

@Injectable()
export class APIService{
	TOKEN:string;
	result:any;
	rootUrl: string;
	rootUrlTESTES: string;
	rootUrlAuthority: string;
	arrayPrincipalFinal = [];
	arraySecundarioFinal = [];
	uri_consultar: string;

	dialogSubscribe: Subscription;

	linguas = new Array();
	teste:string;


	constructor(private httpClient: HttpClient, private router: Router, private location: Location){
		this.rootUrl = this.getRestServer();
	}


	SETarraylinguas(value){
		this.linguas[5]="Alterar palavra passe";
		this.linguas[7]="Palavra passe antiga";
		this.linguas[8]="Nova palavra passe";
		this.linguas[9]=value;
		this.linguas[10]="Alterar";
		this.linguas[11]="Novo";
		this.linguas[12]="Introduzir";
		this.linguas[13]="Apagar";
		this.linguas[14]="Eliminar";
	}

	GETarraylinguas(key){
		return this.linguas[key];
	}

	GETarraySecundario(){
		return this.arraySecundarioFinal;
	}

	SETuriConsultar(caminho){
		this.uri_consultar=caminho;
	}

	GETuriConsultar(){
		return this.uri_consultar;
	}

	getName(){
		return localStorage.getItem('user');
	}

	getToken(){
		return localStorage.getItem('Token');
	}

	setComponent(name){
		localStorage.setItem('component', name);
	}

	getComponent(){
		return localStorage.getItem('component');
	}

	setIDComponente(id){
		localStorage.setItem('form_id', id);
	}

	getIDComponente(){
		return localStorage.getItem('form_id');
	}

	getRestServer(){
		//MUDARCOMPILAR
		// if (location.host == '10.10.10.92:4200' || location.host == 'webmail.werk.pt:4200') {
		// 	this.rootUrlAuthority = 'saasapi.werk.pt';
		// }	else {
		// 	this.rootUrlAuthority = 'P'+location.host;
		// }
		// return 'https://'+this.rootUrlAuthority+'/ipaapi/';


		//caso vá para tubos
		return 'https://ptubos.werk.pt/ipaapi/';
		//caso vá para suporte
		//return 'https://psuporte.werk.pt/ipaapi/';
		//caso vá para lcenteno (MCDT testes)
		//return 'https://plcenteno.werk.pt/ipaapi/';
		//caso vá para confar medicines
		//return 'https://pmedicines.confar.pt/ipaapi/';
		//caso vá para confar pcenteno (teste de MCDT)
		//return 'https://plcenteno.werk.pt/ipaapi/';

		//SÓ USAR EM CASO DE EMERGENCIA!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!(com cuidado..........)
		//return 'https://pe3e3.mcdt.pt/ipaapi/';
		//return 'https://pd9o4.werk.pt/ipaapi/';
		//return 'https://pa3i6.werk.pt/ipaapi/';
		//return 'https://pi9i4.werk.pt/ipaapi/';
		//return 'https://pt5o7.werk.pt/ipaapi/';
	}

	getBrandName(){
		if (localStorage.getItem('BrandName')){
			return localStorage.getItem('BrandName');
		}else{
			return "WERK";
		}
	}

	getLoginHeader(){
		if (localStorage.getItem('LoginHeader')){
			return localStorage.getItem('LoginHeader');
		}else{
			return "WERK";
		}
	}

	getUserID(){
		return localStorage.getItem('ID');
	}

	getData(path): Observable<any> {
		const headers = new HttpHeaders({});
		headers.append('authority',this.rootUrlAuthority);
		headers.append('method','GET');
		headers.append('scheme','https');
		headers.append('accept','text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8');
		headers.append('accept-encoding','gzip, deflate, br');
		headers.append('accept-language','pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7');
		headers.append('cache-control','no-cache');
	  return this.httpClient.get(path, { headers: headers });
	}

	adjustColor(color, amount) {
		return '#' + color.replace(/^#/, '').replace(/../g, color => ('0'+Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2));
	}

	cont:number = 0;
	contShowExpirar:number = 0;

	destinoToken(){
		const headers = new HttpHeaders({});
		headers.append('Access-Control-Allow-Headers', 'Content-Type');
		headers.append('Access-Control-Allow-Methods', 'POST');
		headers.append('Access-Control-Allow-Origin', '*');


		this.httpClient.get(this.rootUrl+"tokenOK?token="+this.getToken(), {headers: headers})
		.subscribe(res => {
			this.result = res;
			this.cont++;
			if(this.result.status == "ok" || this.result.status == "Ok" || this.result.status == "OK"){
				this.cont = 0;

				var horaExpira = this.result.inativo.dataFim.substring(11);
				var currentTime = moment();
				var horaAtual =  moment(currentTime).format("HH:mm:ss");
		    var horaAtualAdiantada =  moment(currentTime).add(this.result.inativo.tempo, "minutes").format("HH:mm:ss");
				//console.log( "Atual Adiantada: ", horaAtualAdiantada, ">=", "Expira: ", horaExpira, "||", "Atual: ", horaAtual)

				var ms = moment(horaExpira,"HH:mm:ss").diff(moment(horaAtual,"HH:mm:ss"));
				var miliseconds = moment.duration(ms).asMilliseconds();
				//console.log("Milisegundos: ", miliseconds);

				if (horaAtualAdiantada >= horaExpira){
					this.contShowExpirar++;
					//console.log("contShowExpirar: ", this.contShowExpirar)
					if(this.contShowExpirar == 1){
						//-8000 para dar tempo de fechar senao fica sempre a fazer tarefa por trás
						this.showVaiExpirar(this.result.inativo.titulo, this.result.inativo.mensagem, miliseconds-8000, this.result.inativo.textoBotaoOk);
					}
				}
			}
			if(this.result.status == "error"){
				if(this.cont == 1){
					//Naveva para login
					this.router.navigate(['/login']);
					localStorage.setItem('Token', null);

					// //success	error	warning	info	question
					// this.showConfirmation(this.result.titulo, this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar);
					// this.dialogSubscribe = this.borrowerChangedObservable.subscribe((borrower) => {
					// 	if(borrower == true){
					// 		//sempre necessario
					// 		this.dialogSubscribe.unsubscribe();
					// 		this.changeValue(null);
					// 	}else if(borrower == false){
					// 		//sempre necessario
					// 		this.dialogSubscribe.unsubscribe();
					// 		this.changeValue(null);
					// 	}
					// });
				}
			}
		},
		erro => {
			this.showError("ANERR0018");
		}
	);

	}

	getNavBar(){
		return this.rootUrl+'config_navbar';
	}

	getComponentURL(){
		return this.rootUrl+'config_componentes?token='+this.getToken();
	}

	public getDataJSON() {
	  return this.httpClient.get<JSON>(this.getComponentURL())
	}

	SETarrayPrincipal(dados){
		this.arrayPrincipalFinal.length = 0;
		var array = [];
		array.push(dados[0]);
		Object.keys(array).map((index) => {
			for(var dat in array[index]){
				this.arrayPrincipalFinal.push({ title: dat, value: array[index][dat] });
			}
		});
	}

	GETarrayPrincipal(){
		return this.arrayPrincipalFinal;
	}

	SETarraySecundario(dados){
		this.arraySecundarioFinal.length = 0;
		var array1 = [];
		for(var i = 1; i < dados.length; i++){
			array1.push(dados[i]);
		}
		var array2 = [];
		Object.keys(array1).map((index) => {
			for(var dat in array1[index]){
				array2.push({ title: dat, value: array1[index][dat] });
			}
		});

		var leng = array2.length;
		do{
			for(var x=0, y=13; y<leng; x=x+14,y=y+14){
					this.arraySecundarioFinal.push(array2.slice(x,y));
			}
		}while(y <= leng)
	}

	//----------------------------------------------------------------- DIALOGS

	public borrowerChanged = new BehaviorSubject<boolean>(null);
	borrowerChangedObservable = this.borrowerChanged.asObservable();
	changeValue(value){
    this.borrowerChanged.next(value);
  }

	//success/error/warning/info/question
	showConfirmation(title, text, type,cancelButtonText='Cancelar',confirmButtonText='Ok', showCancelButton=true, timer=0,showConfirmButton=true, confirmButtonColor='#3085d6',cancelButtonColor='#d33', allowOutsideClick=false){

		Swal({
		  title: title,
		  html: text,
		  type: type,
		  showCancelButton: showCancelButton,
			showConfirmButton: showConfirmButton,
		  confirmButtonColor: confirmButtonColor,
			cancelButtonText: cancelButtonText,
		  cancelButtonColor: cancelButtonColor,
		  confirmButtonText: confirmButtonText,
			allowOutsideClick: allowOutsideClick,
			timer: timer
		}).then((result) => {
		  if (result.value) {
				this.changeValue(true);
		  }else{
				this.changeValue(false);
			}
		})
	}

	texto=" - Erro na resposta.<br>Se tiver alguma dúvida, por favor contacte o suporte atraves de suporte@werk.pt ou (+351)211 570 970. Obrigado!";
	showError(text){
		Swal({
		  title: "Erro",
		  html: text+this.texto,
		  type: "error",
		  showCancelButton: false,
		  confirmButtonText: "OK",
		}).then((result) => {
		  if (result.value) {
				this.changeValue(true);
		  }else{
				this.changeValue(false);
			}
		})

		this.dialogSubscribe = this.borrowerChangedObservable.subscribe((borrower) => {
			if(borrower == true){
				//sempre necessario
				this.dialogSubscribe.unsubscribe();
				this.changeValue(null);
			}
		});
	}


	showInputs(title, url, btnOkTexto=null, btnCancelarTexto=null){
		var d = new Date();
	  //var hora = d.getHours() + ":" + d.getMinutes()+5;
		var data = d.getFullYear() + '-' + ('0'+(d.getMonth()+1)).slice(-2) + '-' + d.getDate();

		var currentTime = moment();
    var hora =  moment(currentTime).add(5, 'minutes').format("HH:mm");

    var horaAtual =  moment(currentTime).format("HH:mm");

		Swal({
			title: title,
      animation: true,
      customClass:'bounceInDown',
      showCancelButton: true,
      confirmButtonText:"Confirmar",
			cancelButtonText:"Cancelar",
			allowOutsideClick: false,
      html:
			// "<select id='medico' class='form_input' style='width: 80%; padding: 12px 20px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;'> <option value='nope' disabled selected>Selecionar médico</option><option value='volvo'>Volvo</option><option value='saab'>Saab</option><option value='vw'>VW</option><option value='audi'>Audi</option></select>" +"</br>" +
      "<input id='codacesso' name='codacesso' autocomplete='off' maxlength='6' type='text' class='form_input' required placeholder='Codigo Prestação(sem *)' style='width: 80%; padding: 12px 20px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;' />" +"</br>" +
      "<input id='date' name='date' autocomplete='off' type='date' class='form_input'  required  placeholder='Data' style='width: 47%;   height=40%; padding: 12px 20px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box; ' value="+data+">" + "&nbsp&nbsp&nbsp&nbsp" +
      "<input id='end_time' name='end_time' autocomplete='off' type='time' class='form_input'  required  placeholder='Hora' style='width: 29%; height=40%; padding: 12px 20px;margin: 8px 0; border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box; ' value="+hora+">",
      preConfirm: async () => {

				//get value
				// var medico = (<HTMLInputElement>document.getElementById('medico')).value;
				// //console.log("OLHA O MEDICOOOOOOO: ", medico);

				var codAcesso = (<HTMLInputElement>document.getElementById('codacesso')).value;
        var date = (<HTMLInputElement>document.getElementById('date')).value;
				var end_time = (<HTMLInputElement>document.getElementById('end_time')).value;

				//Validadores
				var dateValidate = Date.parse(date.toString());
				var hourValidate = moment(end_time, "HH:mm", true).isValid();
				var dt1 = moment(date);
				var now = moment(data);


				try {
					// if(medico != 'nope'){
						if(codAcesso.length == 6){
							if(!isNaN(dateValidate)){
								if(dt1 >= now){
									if(hourValidate){
										if(end_time >= horaAtual){
						          const response = await fetch(this.rootUrl + url +"&token="+this.getToken() +"&o2=" + codAcesso + "&dt1=" + date + "&dtt1=" + end_time);
						          if (!response.ok) {
						            throw new Error(response.statusText);
						          }else{
												//TODO mostrar mensagem de retorno do pedido
											}
					          	return response.json();
										}else{
											Swal.showValidationMessage(`Inserir hora superior ou igual a hoje`);
										}
									}else{
										Swal.showValidationMessage(`Inserir hora correta`);
									}
								}else{
									Swal.showValidationMessage(`Inserir data superior ou igual a hoje`);
								}
							}else{
								Swal.showValidationMessage(`Inserir data correta`);
							}
						}else{
							Swal.showValidationMessage(`Inserir campo Códido de acesso com 6 digitos`);
						}
					// }else{
					// 	Swal.showValidationMessage(`Inserir médico`);
					// }
        }
        catch (error) {
          Swal.showValidationMessage(`Erro no pedido`);
        }
      }
    }).then((result) => {
		  if (result.value) {
				this.changeValue(true);
		  }else{
				this.changeValue(false);
			}
		})
	}


	showVaiExpirar(titulo, descricao, tempo, textoBotaoOK){
		var countDownDate = moment().add(tempo, 'milliseconds');

		let timerInterval;
		Swal({
		  title: titulo,
		  html: descricao+' <span></span>',
		  timer: tempo,
			confirmButtonText:textoBotaoOK,
			onBeforeOpen: () => {
		    timerInterval = setInterval(() => {
					var diff = countDownDate.diff(moment());
					Swal.getContent().querySelector('span').textContent = moment.utc(diff).format("mm:ss");
					console.log("diff: ", diff);
					if(diff<1000){
						//Naveva para login
						this.router.navigate(['/login']);
						localStorage.setItem('Token', null);
					}
		    }, 1000);
		  },
		  onClose: () => {
		    clearInterval(timerInterval)
				//no tokenOK tem este cont para só fazer 1x
				this.contShowExpirar=0;
		  },
			allowOutsideClick: false
		}).then((result) => {
		  if (result.value) {
				this.changeValue(true);
		  }else{
				this.changeValue(false);
			}
		})

	}

	passwordPrompt(title){
		var d = new Date();
	  //var hora = d.getHours() + ":" + d.getMinutes()+5;
		var data = d.getFullYear() + '-' + ('0'+(d.getMonth()+1)).slice(-2) + '-' + d.getDate();

		var currentTime = moment();
    var hora =  moment(currentTime).add(5, 'minutes').format("HH:mm");

    var horaAtual =  moment(currentTime).format("HH:mm");
		Swal({
			title: title,
			animation: true,
			customClass:'bounceInDown',
			showCancelButton: true,
			confirmButtonText:"Alterar",
			cancelButtonText:"Cancelar",
			allowOutsideClick: false,
			html:
			// "<input id='codacesso' name='codacesso' autocomplete='new-password' type='password' class='form_input' required placeholder='Palavra passe antiga' style='width: 80%; padding: 12px 20px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;' />" +"</br>" +
			// "<input id='codacesso' name='codacesso' autocomplete='new-password' type='password' class='form_input' required placeholder='palavra passe nova' style='width: 80%; padding: 12px 20px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;' />" +"</br>" +
			// "<input id='codacesso' name='codacesso' autocomplete='new-password' type='password' class='form_input' required placeholder='palavra passe nova novamente' style='width: 80%; padding: 12px 20px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;' />" +"</br>",
			"<input type='password' name='email' id='email_fake' class='hidden' autocomplete='off' style='display: none;' />"+
			// "<input id='codacesso' name='codacesso' autocomplete='new-password' type='password' class='form_input' required placeholder='Palavra passe antiga' style='width: 80%; padding: 12px 20px;margin: 8px 0;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;' />" +"</br>" +
			"<input type='text' name='email' id='email'/>"+
			"<input type='password' name='password' id='password_fake' class='hidden' autocomplete='off' style='display: none;' />"+
			"<input type='password' name='password' id='password' autocomplete='off' />",


		}).then((result) => {
		  if (result.value) {
				this.changeValue(true);
		  }else{
				this.changeValue(false);
			}
		})

			// if (password) {
			//   Swal.fire('Entered password: ' + password)
			// }
	}

	//ABANDONEI PORQUE NÃO CONSEGUIA PASSAR NOME CORRETAMENTE PARA COMPONENTE ONDE CHAMAVA SERVIÇO 30-08-2019
	//NÃO ENVIA FICHEIRO CORRECTAMENTE
	// filePopupBK(pedidoID, rowID, nivel, token){
	// 	var name;
	// 	var restServer = this.getRestServer();
	// 	return Swal({
	//     input: 'file',
	//     inputAttributes: {
	//         name:"upload[]",
	//         id:"fileToUpload",
	//         //accept: "application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
	//         multiple:"multiple"
	//     },
	//     showCloseButton: true,
	//     showCancelButton: true
	// 	}).then(function() {
	// 			var formData = new FormData();
	// 			formData.append('fileToUpload', $('#fileToUpload')[0]);
	// 			$.ajax({
	// 				//url: restServer+"services/upload.php?token="+ token +"&row_id="+ rowID +"&nvl="+ nivel +"&pedido_id=" + pedidoID,
	// 				url: "https://psuporte.werk.pt/services/upload.php?token="+ token +"&row_id="+ rowID +"&nvl="+ nivel +"&pedido_id=" + pedidoID,
	// 				type: "POST",
	// 				data: formData,
	// 				processData: false,
	// 				contentType: false,
	// 				success: function (data) {
	// 					name = data.name;
	// 					Swal.close();
	// 				}
	//     	});
	// 	})
	// }
	//
	//
	// filePopup(pedidoID, rowID, nivel, token){
	// 	var result;
	// 	var restServer = this.getRestServer();
	// 	Swal({
	//     title: "Carregar ficheiros",
	//     html:
	// 			'<input type="file" class="swal2-file" placeholder="" style="display: flex;" id="filechooser">'+'</br>'+
	// 			'<button id="btn-sent" class="btn btn-primary">Enviar</button>',
	//     showConfirmButton: false
	//   }).then((result) => {
	// 	  if (result.value) {
	// 			this.changeValue(true);
	// 	  }else{
	// 			this.changeValue(false);
	// 		}
	// 	});
	// 	$(document).on('click', "#btn-sent", function() {
	// 		var elementReference = <HTMLInputElement> document.getElementById("filechooser");
	// 		if(elementReference.files.length == 0 ){
	// 		    Swal.showValidationMessage(`Inserir documento`);
	// 		}else{
	// 			var formData = new FormData();
	// 			formData.append("file", $("#filechooser")[0].files[0]);
	// 	    $.ajax({
	// 				//url: restServer+"services/upload.php?token="+ token +"&row_id="+ rowID +"&nvl="+ nivel +"&pedido_id=" + pedidoID,
	// 				url: "https://psuporte.werk.pt/services/upload.php?token="+ token +"&row_id="+ rowID +"&nvl="+ nivel +"&pedido_id=" + pedidoID,
	// 				type: "POST",
	// 				data: formData,
	// 				processData: false,
	// 				contentType: false,
	// 				success: function (data) {
	// 					result = data;
	// 					Swal.close();
	// 				}
	//     	});
	// 		}
	// 	});
	// 	//console.log(result);
	// 	return result;
	// }



}
