//Modulos
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';

//Tabela
import { FormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import { MatStepperModule, MatAutocompleteModule, MatButtonModule, MatTableModule, MatSortModule, MatPaginatorModule, MatIconModule, MatCardModule, MatFormFieldModule, MatInputModule, MatMenuModule, MatDialogModule,  MatPaginatorIntl} from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CommonModule } from '@angular/common';
import { MatSelectModule } from '@angular/material';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { MatRadioModule } from '@angular/material/radio';
import { HttpClientModule, HttpClient } from '@angular/common/http';
//toolbar
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatTabsModule } from '@angular/material/tabs';
//Child Router
import { RouterModule } from '@angular/router';
import { routes } from './routing/app-routing.module';
//Paginacao da tabela noutra lingua
import { getDutchPaginatorIntl } from './component/tabelas/tabela/tabelapaginator.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import { MAT_DATE_LOCALE, MAT_DATE_FORMATS, DateAdapter } from '@angular/material';
import { MomentDateAdapter, MomentDateModule} from '@angular/material-moment-adapter';
import { registerLocaleData } from '@angular/common';
import localePt from '@angular/common/locales/pt';
import 'moment/locale/pt';
//Components
import { TabelaSearchComponent } from './component/tabelas/tabela-search/tabela-search.component';
import { NavbarComponent } from './component/navbar/navbar.component';
import { RegisterComponent } from './component/sessao/register/register.component';
import { LoginComponent } from './component/sessao/login/login.component';
import { DialogComponent } from './component/sessao/register/dialog/dialog.component';
import { PasswordComponent } from './component/sessao/password/password.component';
import { TabelaComponentRouting } from './routing/app-routing.module';
import { BemVindoComponent } from './routing/app-routing.module';
import { DetailsComponent } from './component/details/details.component';
import { DetailstepperComponent } from './component/detailstepper/details.component';
import { AppComponent } from './app.component';
import { TabelaComponent } from './component/tabelas/tabela/tabela.component';
import { InfoComponent } from './component/info/info.component';
import { MatExpansionModule } from '@angular/material/expansion';
//bootstrap
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LoaderComponent } from './loader/loader.component';
import { LoaderService } from './loader/loader.service';
import { SpinnerComponent } from './spinner/spinner.component'
import { SpinnerService } from './spinner/spinner.service';
import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';
import { FooterComponent } from './component/footer/footer.component';
import { SidenavComponent } from './component/DASHBOARD-navbar-sidenav/sidenav.component';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { ScrollToModule } from '@nicky-lenaers/ngx-scroll-to';
import { ColorPickerModule } from 'ngx-color-picker';
//Service
import { APIService } from './service/api.service'
import { UploadService } from './service/upload.service'

//graficos
import { ChartsModule } from 'ng2-charts';
import 'chart.piecelabel.js'; // after 'ng2-charts'



//Alteracao lingua da tabela na paginacao
registerLocaleData(localePt);
export const MY_FORMATS = {
  parse: {
    dateInput: 'L',
  },
  display: {
    dateInput: 'L',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@NgModule({
  exports: [
    CommonModule,
    MatToolbarModule,
    MatButtonModule
  ],
  imports: [
    ColorPickerModule,
    MatAutocompleteModule,
    MatSidenavModule,
    ScrollToModule,
    MatListModule,
    MatInputModule,
    MatStepperModule,
    MatInputModule,
    MatButtonModule,
    MatTabsModule,
    MatButtonToggleModule,
    MatCheckboxModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatExpansionModule,
    MatTooltipModule,
    MatToolbarModule,
    BrowserModule,
    HttpClientModule,
    MatSelectModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    CommonModule,
    MatButtonModule,
    FormsModule,
    CdkTableModule,
    MatTableModule,
    MatIconModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatPaginatorModule,
    MatSortModule,
    MatMenuModule,
    MatDialogModule,
    ReactiveFormsModule,
    MomentDateModule,
    BrowserModule,
    RouterModule.forRoot(routes, {useHash: true}),
    NgbModule.forRoot(),
    SweetAlert2Module.forRoot({
      buttonsStyling: false,
      customClass: 'modal-content',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn'
    }),
    ScrollToModule.forRoot(),
    ChartsModule
  ],
  declarations: [
    LoaderComponent,
    AppComponent,
    TabelaComponent,
    TabelaComponentRouting,
    BemVindoComponent,
    DetailsComponent,
    NavbarComponent,
    TabelaSearchComponent,
    RegisterComponent,
    LoginComponent,
    DialogComponent,
    PasswordComponent,
    InfoComponent,
    DetailstepperComponent,
    SpinnerComponent,
    FooterComponent,
    SidenavComponent
  ],
  entryComponents: [
    DetailsComponent,
    TabelaSearchComponent,
    TabelaComponentRouting,
    InfoComponent,
    TabelaComponent,
    DialogComponent,
    PasswordComponent,
    DetailstepperComponent
  ],
  bootstrap:[
     AppComponent,
  ],
  providers: [
    LoaderService,
    SpinnerService,
    APIService,
    UploadService,
    HttpClient,
    DetailsComponent,
    DetailstepperComponent,
    NavbarComponent,
    TabelaComponent,
    AppComponent,
    { provide: MatPaginatorIntl, useValue: getDutchPaginatorIntl() },
    { provide: MAT_DATE_LOCALE, useValue: 'pt-PT' },
    { provide: LOCALE_ID, useValue: 'pt-PT' },
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS }
  ]
})
export class AppModule {
}
