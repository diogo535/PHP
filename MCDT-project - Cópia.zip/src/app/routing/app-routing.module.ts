import { Router } from '@angular/router';
//Modules
import { Component, OnInit, NgModule, ModuleWithProviders } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
//Routing
import { RouterModule, Routes } from '@angular/router';
//Componentes
import { AppComponent } from './../app.component';
import { DetailsComponent } from './../component/details/details.component';
import { RegisterComponent } from './../component/sessao/register/register.component';
import { NavbarComponent } from './../component/navbar/navbar.component';
import { LoginComponent } from './../component/sessao/login/login.component';
import { InfoComponent } from '../component/info/info.component';
//apiservice
import { APIService } from '../service/api.service';
import { LoaderService } from '../loader/loader.service';

import { MatTabChangeEvent } from '@angular/material';
//RXJS
import 'rxjs';

import { Observable, Subscription } from 'rxjs';

//GRAFICOS
import { ChartsModule } from 'ng2-charts';
import { ChartDataSets, ChartOptions, ChartType } from 'chart.js';
import * as pluginDataLabels from 'chartjs-plugin-datalabels';
import * as Chart from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import { Label } from "ng2-charts";



//Component bemvindo
@Component({
  selector: 'app-bemVindo',
  templateUrl: './bemVindo.html',
  styleUrls: ['./bemVindo.css']
})

export class BemVindoComponent {
  rootUrl:string;
  token:string;

  data: any;
  descricoes:any;
  valores:any;

  //
  result:any;
  dConfig=[];
  listaobjPrincipalInserir=[];
  par=[];
  impar=[];
  dados:any;
  dynamicClass="";

  //HARDCODED TABELA POR TENICO
  uri_listar:string;
  id_formulario:string;
  angular_path:string;
  displayedColumns=[];
  displayedColumnsName=[];
  componente_angular:string;
  descricao:string;
  idpai:string;
  ondeVou:string;
  tipo_formulario:string;
  uri_inserir:string;
  uri_consultar:string;
  uri_gravar:string;
  uri_gravar_secundario:string;

  //valores em cima dos graficos
  public barChartPlugins = [pluginDataLabels];

  // ---------------------------------- GRAFICOS DINAMICOS
  constructor(
      //UPLOAD FILES
      private apiservice: APIService,
      private http: HttpClient) {

        //this.apiservice.showInputs("OK", "OK");

    this.rootUrl = this.apiservice.getRestServer();

    var displayedColumns = "numero;data_abertura;tecnico_nome;cliente_nome;assunto";
    var displayedColumnsName = "Numero;Data;Nome Tecnico;Cliente;Assunto";
    this.angular_path = "pedidosabertos";
    this.displayedColumns.push(displayedColumns.split(";"));
    this.displayedColumnsName.push(displayedColumnsName.split(";"));
    this.componente_angular = "TabelaComponentRouting";
    this.descricao = "Pedidos abertos de "+this.apiservice.getName();
    this.id_formulario = "rc8enuqiohkjrem8qnwfyuxienwrew33";
    this.idpai = "yd4t6h2s47890wm14ioemu2sioh,qwk";
    this.ondeVou = "app-pedidos";
    this.tipo_formulario = "51";
    this.uri_inserir = "crud_new";
    this.uri_consultar = "detalhe_pedido";
    this.uri_gravar = null;
    this.uri_gravar_secundario = null;

    const headers = new HttpHeaders({});
    headers.append('Access-Control-Allow-Headers', 'Content-Type');
    headers.append('Access-Control-Allow-Methods', 'get');
    headers.append('Access-Control-Allow-Origin', '*');


    //this.http.get("http://www.mocky.io/v2/5cb6014b330000e8385d7f83").subscribe(
    this.http.get(this.apiservice.rootUrl+"grafico?tecnico_id="+this.apiservice.getUserID()+"&token="+this.apiservice.getToken(), {headers: headers}).subscribe(

      data => {

        this.result = data;
        this.dConfig.push(this.result[0].dConfig[0]);

        //PAR
        this.listaobjPrincipalInserir=[];
        for(var z=0; z<this.dConfig.length; z++){
          var temp=[];
          for (var i = 0; i < this.dConfig[z].length; i++) {
              if(i % 2 === 0) {
                temp.push(this.dConfig[z][i]);
              }
          }
          this.par.push(temp);

          //IMPAR
          var temp=[];
          var temp1=[];
          for (var i = 0; i < this.dConfig[z].length; i++) {
              if(i % 2 !== 0) {
                temp.push(this.dConfig[z][i]);
              }
          }
          this.impar.push(temp);
        }

        //console.log("ARRAY par: ", this.par);
        //console.log("ARRAY impar: ", this.impar);

      }, erro => {
    		//console.log(erro);
    	}
    );
      this.apiservice.destinoToken();
      this.token = this.apiservice.getToken();
      //console.log("TOKEN: ", this.token);
  }

  //Não repete inputs varias vezes
  fazSoUmaVez(indexDaLista, campo, repeticoes){
    if(repeticoes < 1){
      return true;
    }else{
      return false;
    }
  }

  //consoante lengnt do array faz boostrap
  classDiv(array){
    var num;
    num = array.length;
    ////console.log("ESTOU AQUI DENTRO DO CLASS DIV: ", num);
    if(num == 1){
      this.dynamicClass="col-lg-12";
    }
    if(num == 2){
      this.dynamicClass="col-lg-6";
    }
    if(num == 3){
      this.dynamicClass="col-lg-4";
    }
    if(num == 4){
      this.dynamicClass="col-lg-3";
    }

    ////console.log("this.dynamicClass: ", this.dynamicClass);
    return this.dynamicClass;
  }







  //------------------------------ GRAFICOS TABS
//   public lineChartType:string = 'line';
//   public pieChartType:string = 'pie';
//   // Doughnut - GRAFICO
//   public doughnutChartColors:any[] = [ {backgroundColor: ["grey", "white"]}];
//   public doughnutChartOptions:any={
//     title: {
//       display: true,
//       text: '.: Requisições mês atual :.'
//     }
//   };
//   public doughnutChartLabels:string[] = ['Realizadas', 'Agendadas'];
//   public doughnutChartData:number[] = [50, 2];
//   public doughnutChartType:string = 'doughnut';
//
//
//   //Bars - GRAFICO
//   public barChartOptions:any = {
//     scaleShowVerticalLines: false,
//     responsive: true,
//     title: {
//       display: true,
//       text: '.: Requisições dos últimos 4 meses :.'
//     }
//   };
//   public barChartLabels:string[] = ['Outubro', 'Novembro', 'Dezembro', 'Janeiro'];
//   public barChartType:string = 'bar';
//   public barChartLegend:boolean = true;
//
//   public barChartData:any[] = [
//     {data: [65, 59, 80, 81], label: 'Materializadas'},
//     {data: [28, 48, 40, 19], label: 'Desmaterializadas'}
//   ];
//
//  // events
//   tabChanged1(tabChangeEvent: MatTabChangeEvent){
//     if(tabChangeEvent.index == 0){
//       this.pieChartType = 'pie';
//     }else if(tabChangeEvent.index == 1){
//       this.pieChartType = 'doughnut';
//     }
//     //console.log(this.doughnutChartColors);
//   }
//
//   tabChanged2(tabChangeEvent: MatTabChangeEvent){
//     if(tabChangeEvent.index == 0){
//       this.lineChartType = 'line';
//     }else if(tabChangeEvent.index == 1){
//       this.lineChartType = 'bar';
//     }
//   }
//
//   public chartClicked(e:any):void {
//   }
//
//   public chartHovered(e:any):void {
//   }
}


//Component Pedidos - *ngIf="id_formulario" para evitar que carregue componente tão rapido que do outro lado falte os parametros passados.
@Component({
  selector: 'app-tabelaRouting',
  template: `
  <section class="content-component">
    <app-tabela
      *ngIf="id_formulario"

      [id_formulario]="id_formulario"
      [descricao]="descricao"
      [tipo_formulario]="tipo_formulario"
      [angular_path]="angular_path"
      [displayedColumns]="displayedColumns"
      [displayedColumnsName]="displayedColumnsName"
      [ondeVou]="ondeVou"
      [componente_angular]="componente_angular"

      [uri_listar]="uri_listar"
      [uri_consultar]="uri_consultar"
      [uri_inserir]="uri_inserir"
      [uri_gravar]="uri_gravar"
      [uri_gravar_secundario]="uri_gravar_secundario"
      [uri_apagar]="uri_apagar"
      [uri_apagar_secundario]="uri_apagar_secundario"
      >
    </app-tabela>
  </section>`
})

export class TabelaComponentRouting {

  id_formulario:string;
  descricao:string;
  tipo_formulario:number;
  angular_path:string;
  displayedColumns=[];
  displayedColumnsName=[];
  ondeVou:string;
  componente_angular:string;

  uri_listar:string;
  uri_inserir:string;
  uri_consultar:string;
  uri_gravar_secundario:string;
  uri_gravar:string;
  uri_apagar:string;
  uri_apagar_secundario:string;

  dialogSubscribe: Subscription;

  //Recebe array do RestAPI com boolean e msg
  result: any;

  constructor(private apiservice: APIService, private loader:LoaderService, private router: Router) {
      this.loadDataComponent();

      if (this.router.url === '/info3' || this.router.url === '/info4' || this.router.url === '/info5'){
        this.apiservice.showConfirmation("Informação","Na versão de demonstração não é possivel a criação de ficheiros.","info","","OK",false);
        this.dialogSubscribe = this.apiservice.borrowerChangedObservable.subscribe((borrower) => {
          if(borrower == true){

            //sempre necessario
            this.dialogSubscribe.unsubscribe();
            this.apiservice.changeValue(null);
          }else if(borrower == false){

            //sempre necessario
            this.dialogSubscribe.unsubscribe();
            this.apiservice.changeValue(null);
          }
        });

      }
  }

  loadDataComponent() {
    this.apiservice.getDataJSON().subscribe(
      data => {
         var count = Object.keys(data).length;
         for(var i=0; i < count; i++){
           if(this.apiservice.getComponent() == data[i].angular_path){
            this.uri_listar = data[i].uri_listar;
            this.descricao = data[i].descricao;
            this.id_formulario = data[i].id_formulario;
            this.tipo_formulario = data[i].tipo_formulario;
            this.displayedColumns.push(data[i].displayedColumns.split(";"));
            this.displayedColumnsName.push(data[i].displayedColumnsName.split(";"));
            this.angular_path = data[i].angular_path;
            this.ondeVou = data[i].ondeVou;
            this.componente_angular = data[i].componente_angular;
            this.uri_inserir = data[i].uri_inserir;
            this.uri_consultar = data[i].uri_consultar;
            this.uri_gravar = data[i].uri_gravar;
            this.uri_gravar_secundario = data[i].uri_gravar_secundario;
            this.uri_apagar = data[i].uri_apagar;
            this.uri_apagar_secundario = data[i].uri_apagar_secundario;
          }
        }
      }, err => {
        this.apiservice.showError("ANERR0008");
      }
    )
  }
}

export const routes: Routes = [
      {
        path: 'admin',
        component: RegisterComponent
      },
      {
        path: 'login',
        component: LoginComponent
      },
      {
        path: 'index',
        component: BemVindoComponent
      },
      {
        path: '',
        redirectTo: '/index',
        pathMatch: 'full'
      },
      {
        path: '**',
        redirectTo: '/index',
        pathMatch: 'full'
    }
];
