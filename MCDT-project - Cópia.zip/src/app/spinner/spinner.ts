export interface SpinnerState {
    show: boolean;
}
