import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { SpinnerState } from './spinner';
@Injectable()
export class SpinnerService {
    // Observable string source
    private dataStringSource = new Subject<string>();
    private spinnerSubject = new Subject<SpinnerState>();
    // Observable string stream
    dataString$ = this.dataStringSource.asObservable();
    spinnerState = this.spinnerSubject.asObservable();
    constructor() { }
    show(value) {
        this.spinnerSubject.next(<SpinnerState>{show: true});
        this.dataStringSource.next(value)
    }
    hide() {
        this.spinnerSubject.next(<SpinnerState>{show: false});
    }
}
