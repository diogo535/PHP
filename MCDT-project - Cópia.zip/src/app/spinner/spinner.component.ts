import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { SpinnerService } from './spinner.service';
import { SpinnerState } from './spinner';

@Component({
    selector: 'angular-spinner',
    templateUrl: 'spinner.component.html',
    styleUrls: ['spinner.component.css']
})
export class SpinnerComponent implements OnInit {
    show = false;
    showText:string;
    private subscription: Subscription;
    constructor(private spinnerService: SpinnerService){}
    ngOnInit() {
        this.subscription = this.spinnerService.spinnerState.subscribe((state: SpinnerState) => {
                this.show = state.show;
        });
        this.spinnerService.dataString$.subscribe(
        data => {
          this.showText = data;
        });
    }
    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}
