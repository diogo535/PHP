import { Component, Inject, OnInit, ChangeDetectorRef, ViewChild } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog, MatDatepicker } from '@angular/material';
import { Router,RouterEvent, NavigationStart } from '@angular/router';
import { FormBuilder, FormGroup,FormControl } from '@angular/forms';
// Service
import { APIService } from '../../service/api.service'
import { LoaderService } from '../../loader/loader.service';
import { SpinnerService } from '../../spinner/spinner.service';
import { UploadService } from '../../service/upload.service';
//
// Rxjs
import { Subscription , Observable} from 'rxjs';

import { filter , map, startWith} from 'rxjs/operators';

import * as moment from 'moment';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})

//COMPONENTE RESPONSAVÉL POR MOSTRAR/CRIAR - DIALOG
export class DetailsComponent implements OnInit {
  //
  emptyPlaceholder='';

  date = new FormControl(new Date());
  ficheiro:File;

  //Root que vem do API SERVICE GLOBAL
  rootUrl:string;

  //Array que recebe dos dialog-open nos componentes
  dados:any;

  //
  local:string = null;

  //Variavel global para criacao de dynamicFields definidos no HTML
  dFAPI=[];
  dFASI=[];
  dFAPV=[];
  dFASV=[];
  listaobjPrimarioVer=[];
  listaobjSecundarioVer=[];
  listaobjPrincipalInserir=[];
  listaobjSecundarioInserir=[];

  //Body para metodos POST
  body = new HttpParams();

  //Recebe array do RestAPI com boolean e msg
  result: any;

  //Para saber se abre dialog DETALHES ou component INFO
  ondeVouBool: boolean;

  //Arrays reponsaveis pelo display dinamico no HTML
  arrayPricipal = [];
  arraySecundario = [];
  listaClientesDropdown = [];
  optionField=[];
  dropFilhaArray=[];
  uri_gravar="";
  uri_gravar_secundario="";
  uri_apagar="";
  uri_apagar_secundario="";
  uri_inserir="";
  apaga_p="";
  apagar_f="";
  id_formulario="";
  destino="";
  array=[];
  element: HTMLElement;

  //Altera vista nos componente HTML
  bool_estado:number = 0;
  bool_alterado:boolean = true;
  dialogSubscribe: Subscription;
  dialogSubscribeName: Subscription;
  routerSubscription: Subscription;

  //25-07-2019 campos ocultos geraram problemas, contamos quais os casos que existem para ter dinamicos
  contOcultos=0;

  //bool para saber se tema foi alterado
  mudaCor:string = '';

  //TYPEAHEAD
  myControl = new FormControl();
  options: any[] = [];
  filteredOptions: Observable<string[]>;
  public displayProperty(value){
    if (value){
      return value.nome;
    }
  }
  filter(val){
    return this.options.filter(options=>
      options.nome.toString().toLowerCase().includes(val.toString().toLowerCase()));
  }
  bindValue(indice, id){
    this.listaobjPrincipalInserir[indice].value = id;
  }

  //CALENDAR SÓ MESES E ANOS
  private pickerDate;
  //Se der erro meter a true ou false, angular 7 necessariio
  @ViewChild('picker', {static: false}) datePicker: MatDatepicker<any>;
  closeDatePicker(event, indice) {
    this.pickerDate = moment(event).format('YYYY-MM');
    this.datePicker.close();
    var dateFrom = moment(this.pickerDate).endOf('month').format('YYYY-MM-DD');
    this.listaobjPrincipalInserir[indice].value = dateFrom;
    //console.log("RESULTADO FINAL: ", dateFrom);
  }

  constructor(
      //UPLOAD FILES
      private uploadService: UploadService,
      private formBuilder: FormBuilder,
      //LOADING
      private spinner:SpinnerService,
      private loader:LoaderService,
      //
      private apiService: APIService,
      public dialogRef: MatDialogRef<DetailsComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
      private http: HttpClient,
      public dialog: MatDialog,
      private router: Router,
      private cdRef:ChangeDetectorRef) {

    //Caminho da api que vem do servico
    this.rootUrl = this.apiService.getRestServer();
    //Passa para Array criado globalmente DADOS DA ROW que vem do componente carregado
    this.dados = data;

    //Logica para controlar atribuição de variaveis ARRAY QUE VEM NO PEDIDO TEM PRIORIDADE

    //MODIFICADO EM PRODUÇÃO
    try{
      this.destino = data.array[0].destino;
    }catch (e){
      console.log(e);
    }

    console.log("destino - data.array: ", this.destino);
    if(this.destino == undefined){
      this.destino = this.dados.destino;
      console.log("destino - this.dados: ", this.destino);
    }

    //id_formulario vem do formulario e form_id vem dos pedidos a API
    //MODIFICADO EM PRODUÇÃO
    try{
      this.id_formulario = data.array[0].form_id;
    }catch (e){
      console.log(e);
    }

    console.log("id_formulario - data.array: ", this.id_formulario);
    if(this.id_formulario == undefined){
      this.id_formulario = this.dados.id_formulario;
      console.log("id_formulario - this.dados: ", this.id_formulario);
    }

    //MODIFICADO EM PRODUÇÃO
    try{
      this.uri_gravar = data.array[0].uri_gravar;
    }catch (e){
      console.log(e);
    }
    console.log("uri_gravar - data.array: ", this.uri_gravar);
    if(this.uri_gravar == undefined){
      this.uri_gravar = this.dados.uri_gravar;
      console.log("uri_gravar - this.dados: ", this.uri_gravar);
    }

    //MODIFICADO EM PRODUÇÃO
    try{
      this.uri_gravar_secundario = data.array[0].uri_gravar_secundario;
    }catch (e){
      console.log(e);
    }
    console.log("uri_gravar_secundario - data.array: ", this.uri_gravar_secundario);
    if(this.uri_gravar_secundario == undefined){
      this.uri_gravar_secundario = this.dados.uri_gravar_secundario;
      console.log("uri_gravar_secundario - this.dados: ", this.uri_gravar_secundario);
    }

    //MODIFICADO EM PRODUÇÃO
    try{
      this.uri_apagar = data.array[0].uri_apagar;
    }catch (e){
      console.log(e);
    }
    console.log("uri_apagar - data.array: ", this.uri_apagar);
    if(this.uri_apagar == undefined){
      this.uri_apagar = this.dados.uri_apagar;
      console.log("uri_apagar - this.dados: ", this.uri_apagar);
    }

    //MODIFICADO EM PRODUÇÃO
    try{
      this.uri_apagar_secundario = data.array[0].uri_apagar_secundario;
    }catch (e){
      console.log(e);
    }
    console.log("uri_apagar_secundario - data.array: ", this.uri_apagar_secundario);
    if(this.uri_apagar_secundario == undefined){
      this.uri_apagar_secundario = this.dados.uri_apagar_secundario;
      console.log("uri_apagar_secundario - this.dados: ", this.uri_apagar_secundario);
    }

    try{
      this.uri_inserir = data.array[0].uri_inserir;
    }catch (e){
      console.log(e);
    }
    console.log("uri_inserir - data.array: ", this.uri_inserir);
    if(this.uri_inserir == undefined){
      this.uri_inserir = this.dados.uri_inserir;
      console.log("uri_inserir - this.dados: ", this.uri_inserir);
    }

    if (this.destino == 'VER'){
      this.apaga_p = data.array[0].apaga_p;
      console.log("apaga_p - data.array: ", this.apaga_p);
      if(this.apaga_p == undefined){
        this.apaga_p = this.dados.uri_apagar;
        console.log("apaga_p - this.dados.res: ", this.apaga_p);
      }
    }else{
      console.log("ESTAS NO NOVO NÃO PRECISAS DE CAIXOTE DO LIXO");
    }

    // this.apagar_f = data.array[0].apagar_f;
    // console.log("apagar_f - data.array: ", this.apagar_f);
    // if(this.apagar_f == undefined){
    //   this.apagar_f = this.dados.res.apagar_f;
    //   console.log("apagar_f - this.dados.res: ", this.apagar_f);
    // }

    this.array = data.array;
    console.log("array: ", this.array);

    //ternario para verificar se pesquisa foi inserida no seletor da tabela
    //console.log("data.ondeVou no DETAILS: ", data.ondeVou);
    // if(data.ondeVou == 'null'){
    //   console.log("com plicas");
    // }
    // if(data.ondeVou == null){
    //   console.log("sem plicas");
    // }
    data.ondeVou == 'null' || data.ondeVou == null ? this.ondeVouBool = false : this.ondeVouBool = true;
    //console.log("ONDE VOU: ", this.ondeVouBool);

    //Funcão que verifica o que vem do componente (Se é para visualizar 'VER' ou para criar 'NOVO')
    this.MeteDados();

  } //FIM CONSTRUCTOR

  ngOnInit() {
   this.routerSubscription = this.router.events.pipe(
       filter((event: RouterEvent) => event instanceof NavigationStart),
       filter(() => !!this.dialogRef)
     )
     .subscribe(() => {
       //console.log("QUER DIZER QUE VOU FECHAR!!!!");
       this.dialogRef.close();
     });

     //UPLOAD FICHEIROS
     this.form = this.formBuilder.group({
        ficheiro: ['']
      });

    //TYPEAHEAD
    this.filteredOptions = this.myControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this.filter(value))
     );
   }

   ngAfterViewInit(){
     //focus do primeiro input
     try{
       var elementReference = <HTMLInputElement> document.getElementById("ipt0");
       if(elementReference == null){
         var elementReference = <HTMLInputElement> document.getElementById("inpt0");
       }
       elementReference.focus();
     }catch (e){
       console.log(e);
      }
     //para previnir erro de mudança de elemento
     this.cdRef.detectChanges();
   }

   // fullscreen(){
   //   // var inputPai = <HTMLDivElement> document.getElementsByClassName("cdk-overlay-pane");
   //   document.getElementsByClassName("cdk-overlay-pane").classList.add('MyClass');
   //   let element = document.getElementsByClassName('exampleDiv');
   //   element.className = 'example-class';
   // }






   abrePopup(posicao){
     //mostra barra de progresso
     this.loader.show();

     // for(var i=0;i<this.listaobjSecundarioInserir.length; i++){
     //   if(this.listaobjSecundarioInserir[i].dbid == 'id_P'){
     //     var rowID = this.listaobjSecundarioInserir[i].value;
     //   }
     // }
    // console.log("rowID: ", this.listaobjSecundarioVer[posicao][0].value);

    // this.apiService.filePopup(this.dados.ID,this.listaobjSecundarioVer[posicao][0].value,2,this.apiService.getToken()).subscribe(
    //   data => {
    //     this.loader.hide();
    //     console.log(data);
    //   }
    // );

   }


   //O QUE ABRE PARA FAZER UPLOAD DE FICHEIROS NA LINHA
   abreSteps(){
     //mostra barra de progresso
     this.loader.show();

     //CAMPOS PARA FAZER NOVO DIALOG
     this.http.get(this.rootUrl+this.uri_inserir+'?token='+this.apiService.getToken()+'&form_id='+this.id_formulario).subscribe(
       res => {
         //console.log("Resposta do pedido: ",res);

         //tirar barra de progresso
         this.loader.hide();

         const dialogRef = this.dialog.open(DetailsComponent, {
           width: '80%',
           height: '80%',
           autoFocus: false,
           disableClose: true,
           data: {
            //Array normal
            array: res,
            //Para verificar como proceder em details HARDCODED
            destino:'NOVO',
            //Para saber se navega para novo component ou mantem no mesmo HARCODED
            ondeVou: 'null',
            //Passa id do formaulario que vem no config_component
            id_formulario: this.id_formulario,
           }
         });
         // Quando fecha dialog chama load para atualizar
         dialogRef.afterClosed().subscribe(() => {
           //mete cont que faz controlo das vezes que carregamos para abrir dialog
           //this.cont = 0;
           //faz refresh dos dados a tabela
           //this.loadData();
           //Conficao para verificar local storage
           // if(localStorage.getItem("dialog") == "1"){
           //   //chama esta funcao caso utilizador escolher continuar a inserir no dialog
           //   this.processData(null);
           // }else{
           //   localStorage.setItem("dialog", "0");
           // }
         });
       },
       erro => {
        this.loader.hide();
        this.apiService.showError("ANERR0017");
      }
    );
  }



//Funcao para permitir apenas inserção de numeros no input (INPUT TYPE NUMBER NÂO PERMITE maxlength)
   isNumberKey(event: KeyboardEvent){
     var charCode = (event.which) ? event.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57) || (charCode >= 96 && charCode <= 105))
       return false;
     return true;
   }

   //--------------------------- INICIO UPLOAD FICHEIROS
      //INICIALIZA NO ngInit() - ESSENCIAL
      form: FormGroup;
      uploadResponse;
      nameFile:string;
      btnShow:boolean;

       onFileSelect(event) {
        if (event.target.files.length > 0) {
          const file = event.target.files[0];
          this.form.get('ficheiro').setValue(file);
          this.nameFile = file.name;
          this.btnShow = true;
        }
       }

       //ORIGINAL
       // onFileSelect(event) {
       //  if (event.target.files.length > 0) {
       //    // const file = event.target.files[0];
       //    // this.form.get('ficheiro').setValue(file);
       //  }
       // }

       onSubmitCustomPath(rowID) {
        const formData = new FormData();
        formData.append('file', this.form.get('ficheiro').value);
        var token = this.apiService.getToken();
        var nivel = 2;
        var pedidoID = this.dados.ID;
        var id_formulario = this.id_formulario;

        //chama spinner e injeta frase que queros mostrar
        this.spinner.show("Aguarde, a fazer upload para a nuvem!");
        this.uploadService.uploadFile(formData, token, rowID, pedidoID, id_formulario).subscribe(
          (res) => {
            this.spinner.hide()
            this.result = res;

            if(this.result){
              this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer,this.result.botaoConfirmar);
              this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
                if(borrower == true){
                    this.reset();
                    //sempre ncessario
                    this.dialogSubscribe.unsubscribe();
                    this.apiService.changeValue(null);
                }else if(borrower == false){
                  console.log("lá vai ele repetir");
                  //sempre ncessario
                  this.dialogSubscribe.unsubscribe();
                  this.apiService.changeValue(null);
                }
              });
            }
          },
          (err) => {
            console.log(err);
          }
        );
       }

       // onSubmit() {
       //  const formData = new FormData();
       //  formData.append('file', this.form.get('ficheiro').value);
       //  var token = this.apiService.getToken();
       //  var nivel = 2;
       //  var pedidoID = this.dados.ID;
       //  var id_formulario = this.id_formulario;
       //
       //  //chama spinner e injeta frase que queros mostrar
       //  this.spinner.show("Aguarde, a fazer upload para a nuvem!");
       //  //this.uploadService.uploadFile(formData).subscribe(
       //  this.uploadService.uploadFile(formData, token, rowID, pedidoID, id_formulario).subscribe(
       //    (res) => {
       //      this.spinner.hide()
       //      this.result = res;
       //
       //      if(this.result){
       //        this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer,this.result.botaoConfirmar);
       //        this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
       //          if(borrower == true){
       //              this.reset();
       //              //sempre ncessario
       //              this.dialogSubscribe.unsubscribe();
       //              this.apiService.changeValue(null);
       //          }else if(borrower == false){
       //            console.log("lá vai ele repetir");
       //            //sempre ncessario
       //            this.dialogSubscribe.unsubscribe();
       //            this.apiService.changeValue(null);
       //          }
       //        });
       //      }
       //    },
       //    (err) => {
       //      console.log(err);
       //    }
       //  );
       // }

      reset() {
        this.btnShow = false;
        this.nameFile = "";
      }


   //--------------------------- FIM UPLOAD FICHEIROS




//--------------------------- INICO FUNCOES DE PREENCHIMENTO AUTOMATICOS DE INPUT ---------------------------
    inputsTipo24_25 = [];

    calculaUri2Send(arraySplit,bdid){
      console.log("DEPOIS DE INSERIR this.listaobjPrincipalInserir: ", this.listaobjPrincipalInserir);

      var uri2Send="";
      var value="";
      var nivel=1;
      var ids="";

      for(var y=2;y<arraySplit.length;y++){
      console.log("arraysplit - ",y," - ", arraySplit[y], " - ", arraySplit[y].substring(0,1));
        if(arraySplit[y].substring(0,1) == 'P'){ // se estamos nas linhas e precisamos de um valor do cabeçalho, precisamos do primariover
          for(var i=0; i < this.listaobjPrimarioVer.length; i++){
            console.log("no PriVer - ",i,this.listaobjPrimarioVer[i].dbid);
            if(this.listaobjPrimarioVer[i].dbid == arraySplit[y].substring(1)){
              value = arraySplit[y].substring(1) + "=" + this.listaobjPrimarioVer[i].value;
              console.log("entrou no if do PriVer",value);
              break;
            }
          }
        } else if( arraySplit[y].substring(0,1) == 'S'){ // no caso de estarmos a trabalhar no secundário, nas linhas, os campos com S vem do que estamos a  inserir
          nivel=2;
          for(var i=0; i < this.listaobjSecundarioInserir.length; i++){
            console.log("no SecIns - ",i,this.listaobjSecundarioInserir[i].dbid);
            if(this.listaobjSecundarioInserir[i].dbid == arraySplit[y].substring(1)){
              value = arraySplit[y].substring(1)  + "=" + this.listaobjSecundarioInserir[i].value;
              console.log("entrou no if do SecIns",value);
              break;
            }
          }
        } else {  // no caso de estarmos a inserir cabeçalhos, temos o principal inserir. da basededados vem o campo sem P ou S
          console.log("Entrou no else. destino=",this.destino );
          var arraylocal=[];
            if (this.destino == 'VER'){
                arraylocal=this.listaobjPrimarioVer.slice();
            }else{
                arraylocal=this.listaobjPrincipalInserir.slice();
            }
            console.log("o arraylocal: ",arraylocal);
          for(var i=0; i <arraylocal.length ; i++){
            if( arraylocal[i].dbid == arraySplit[y]){
              //TIRA U no inicio do codigo local prescricao
              console.log("arraySplit[y]: ", arraySplit[y]);
              value = arraySplit[y] + "=" + arraylocal[i].value.substring(1);
              console.log("TEM QUE VIR AQUI!!!", arraylocal[i].value);
            }
          }

        }
        uri2Send+="&"+value;
      }
      console.log("Uri antes do ids=",uri2Send);
        ids="&id_form="+this.id_formulario+"&id_field="+bdid+"&nivel="+nivel;
        console.log("depois dos ids",ids);
      uri2Send= ids + uri2Send;
      console.log("Dentro do for",uri2Send);
        return uri2Send;
    }

    //funcao para forçar atualizar ngModel pois estamos a manipular os valores do input e não o ngModel
    updateNgModel($event, array, val){
      console.log("Vai atualizar NGMODEL!!!");
      array[val].value = $event;
    }

    vaieVem(val, bdid, nivel, nomeArray, on=null, bdid2, value2){


      console.log("------- listaobjPrimarioVer[in].value -----------", this.listaobjPrimarioVer[val].value);
      console.log("BDID::::", bdid);
      //var num = val+2;
      var inputPai = <HTMLInputElement> document.getElementById("ipt"+val);
      if(inputPai == null){
        var inputPai = <HTMLInputElement> document.getElementById("inpt"+val);
      }
      console.log("inputPai.value: ", inputPai.value);
      console.log("inputPai ipt", val);

      //var arrayHash = "codigoMCDT#3#Ss1#Pid1";
      var arrayHash = "";

      if(nivel==1){

        // if(this.dFAPI.length != this.dFAPV.length) {
        //   this.contOcultos =
    		// };

        console.log("VAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAL: ", val);

        console.log("this.destino: ", this.destino);

        if(this.dFAPI[0].length != this.dFAPV[0].length){
          console.log("Valor DISTINTO: ", this.dFAPI[0].length-this.dFAPV[0].length);
        }else{
          console.log("VALOR IGUAL");
        }


          console.log("DEPURAÇÂO ARRAY: ", this.dFAPI);
          console.log("DEPURAÇÂO COM VAL: ", val);
          if(this.destino == 'NOVO'){
            console.log("ESTOU AQUI-1");
            arrayHash = this.dFAPI[0][val][7];
          }
          else{
            console.log("ESTOU AQUI-2");
            arrayHash = this.dFAPI[0][val-1][7];
          }
          console.log("arrayHash: ", arrayHash);


          //logica para consoante nivel fazer dinamicamente diferentes tipos de input
          var arraySplit = arrayHash.split("#");
          console.log("arraySplit", arraySplit);
          for(var x=1; x < parseInt(arraySplit[1]); x++){
            //this.inputsTipo24_25[x] = <HTMLInputElement> document.getElementById("ipt"+(val+x));
            this.inputsTipo24_25[x] = nomeArray[val+x];
          }
          console.log("this.inputsTipo24_25 no nivel1: ", this.inputsTipo24_25);
      }else if(nivel==2){
          arrayHash = this.dFASI[0][val][7];

          //logica para consoante nivel fazer dinamicamente diferentes tipos de input
          var arraySplit = arrayHash.split("#");
          console.log("arraySplit", arraySplit);
          for(var x=1; x < parseInt(arraySplit[1]); x++){
            //this.inputsTipo24_25[x] = <HTMLInputElement> document.getElementById("inpt"+(val+x));
            this.inputsTipo24_25[x] = nomeArray[val+x];
          }
          console.log("this.inputsTipo24_25 no nivel2: ", this.inputsTipo24_25);

      }
      console.log("arrayHash: ", arrayHash);
      var uri2Send="";
      console.log("arraySplit[0]: ", arraySplit[0])
      switch(arraySplit[0]) {
         case 'codigoMCDT': {
            var res = inputPai.value.substring(4,5);
            if((inputPai.value.length == 5 && res != ".") || (this.listaobjSecundarioInserir[0].value.length == 6)){
              uri2Send=this.calculaUri2Send(arraySplit,bdid);
              console.log("uri2Send: ", uri2Send);
              this.codigoPesquisa(uri2Send);
            }else{
              //Limpa campos caso não cumpra requisitos
              for(var x=1; x<this.inputsTipo24_25.length; x++){
                this.inputsTipo24_25[x].value = "";
              }
            }
            break;
         }
         case "lostFocus": {


         }
         case "codigoLocal": {
            console.log("ENTROU NO CASE!!!");
            if(inputPai.value){
              uri2Send=this.calculaUri2Send(arraySplit,bdid);
              console.log("uri2Send: ", uri2Send);
              this.codigoPesquisa(uri2Send, bdid2, value2, nivel);
            }else{
              console.log("ENTROU NO ELSE!!!");
              //Limpa campos caso não cumpra requisitos
              for(var x=1; x<this.inputsTipo24_25.length; x++){
                this.inputsTipo24_25[x].value = "";
              }
            }
            break;
         }
         default: {
            break;
         }
      }
    }


   codigoPesquisa(uri2send, bdid2=null, value2=null, nivel=null){
     const headers = new HttpHeaders({});
     headers.append('Access-Control-Allow-Headers', 'Content-Type');
     headers.append('Access-Control-Allow-Methods', 'get');
     headers.append('Access-Control-Allow-Origin', '*');

     this.http.get(this.apiService.rootUrl+"tbt_pesquisa?token="+this.apiService.getToken()+uri2send, {headers: headers})
     //+this.listaobjSecundarioInserir[0].dbid+"="+this.listaobjSecundarioInserir[0].value+"&"+this.listaobjPrimarioVer[3].dbid+"="+this.listaobjPrimarioVer[3].value, {headers: headers})
     .subscribe(
       res => {

         this.result = res;
         console.log("this.result: ", this.result);

         if(this.result.status == "error"){
           this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer);
           this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
              if(borrower == true){
                //Limpa campos caso não cumpra requisitos
                for(var x=1; x<this.inputsTipo24_25.length; x++){
                  this.inputsTipo24_25[x].value = "";
                }

                //sempre ncessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
              }else if(borrower == false){
                //sempre ncessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
              }
            });
         }else if(this.result.status == "OK" || this.result.status == "ok" || this.result.status == "Ok"){
           console.log("Estou no OK!!!!!!!!!!!!!!!!");
           console.log("this.result.length: ", Object.keys(this.result).length);
           for(var x=1; x < Object.keys(this.result).length; x++){
             var nome = "mensagem"+x;
             if(this.result[nome]){
                this.inputsTipo24_25[x].value = this.result[nome];
             }
           }

           // fazer update dos 25
           if(bdid2 != null && value2!= null && nivel != null){
             //faz update
             for(var x=1; x<this.inputsTipo24_25.length; x++){
               //this.inputsTipo24_25[x].value = "";
               this.updateField(this.inputsTipo24_25[x].dbid,this.inputsTipo24_25[x].value,bdid2,value2,nivel);
               // console.log("O QUE VAI MANDAR PARA O UPDATE: ",this.inputsTipo24_25[x].dbid," - ", this.inputsTipo24_25[x].value," - ", dbid2," - ", value2," - ", nivel);
             }

           }
         }

     }, erro => {
       console.log(erro);
       this.apiService.showError("ANERR0006");
       this.dialogRef.close();
     });
   }

//--------------------------- FIM FUNCOES DE PREENCHIMENTO AUTOMATICOS DE INPUT ---------------------------


//--------------------------- CAMPO 26
// chamadaXML(estado, val1,val2, dbid1,value1,dbid2,value2,nivel){
//   console.log("SIM", value2);
//
//   const headers = new HttpHeaders({});
//   headers.append('Access-Control-Allow-Headers', 'Content-Type');
//   headers.append('Access-Control-Allow-Methods', 'POST');
//   headers.append('Access-Control-Allow-Origin', '*');
//
//   this.estado(estado, val1,val2, dbid1,value1,dbid2,value2,nivel)
//
//   //chama spinner e injeta frase que queros mostrar
//   this.spinner.show("Aguarde....");
//
//   setTimeout(() => {
//      console.log('VAI FAZER PEDIDO');
//      this.http.get(this.apiService.rootUrl+"xmlCCF?id="+value2+"&token="+this.apiService.getToken()+'&form_id='+this.id_formulario, {headers: headers})
//        .subscribe(res => {
//          console.log("res: ", res);
//          this.spinner.hide();
//        },
//        erro => {
//          console.log("erro: ", erro);
//          this.spinner.hide();
//        });
//   }, 2000);
//
//
//
// }


  apagarLinha(id,nivel=0){
    console.log("ID: ", id);
    //success	error	warning	info	question
    this.apiService.showConfirmation("Apagar registo", "Tem a certeza que pretende apagar o registo? Esta operação é irreversível!", "warning", "Cancelar", "Apagar", true, 0,true,'#3085d6','#d33');

    this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
      //console.log(borrower);
      if(borrower == true){
        if(nivel == 1){
          var path = this.rootUrl+this.uri_apagar+'?token='+this.apiService.getToken()+"&id="+id+'&form_id='+this.id_formulario+'&nvl='+nivel;
        }else{
          var path = this.rootUrl+this.uri_apagar_secundario+'?token='+this.apiService.getToken()+"&id="+id+'&form_id='+this.id_formulario+'&nvl='+nivel;
        }

        const headers = new HttpHeaders({});
        headers.append('Access-Control-Allow-Headers', 'Content-Type');
        headers.append('Access-Control-Allow-Methods', 'POST');
        headers.append('Access-Control-Allow-Origin', '*');

        //console.log(this.apiService.rootUrl+"getDropFilha?id="+id+"&idlinha="+idFunc+"&token="+this.apiService.getToken());
        //this.http.get(path, {headers: headers}).subscribe(
        this.http.post(path, {headers: headers}).subscribe(
          res => {
            this.result = res;
            if(this.result.status == "ok"|| this.result.status == "Ok" || this.result.status == "OK"){
              localStorage.setItem("dialog", "1");
              if(nivel == 1){
                localStorage.setItem("dialog", "0");
              }
              this.dialogRef.close();
            }
        },
        erro => {
          console.log(erro);
          this.apiService.showError("ANERR0010");
        });

        this.dialogSubscribe.unsubscribe();
        this.apiService.changeValue(null);
      }else if(borrower == false){
        //sempre ncessario
        this.dialogSubscribe.unsubscribe();
        this.apiService.changeValue(null);
      }

    });
  }

  getDropFilha(id, idFunc) {

    this.dropFilhaArray = [];

    const headers = new HttpHeaders({});
    headers.append('Access-Control-Allow-Headers', 'Content-Type');
    headers.append('Access-Control-Allow-Methods', 'POST');
    headers.append('Access-Control-Allow-Origin', '*');

    ////console.log(this.apiService.rootUrl+"getDropFilha?id="+id+"&idlinha="+idFunc+"&token="+this.apiService.getToken());
    this.http.get(this.apiService.rootUrl+"getDropFilha?id="+id+"&idlinha="+idFunc+"&token="+this.apiService.getToken(), {headers: headers})
    .subscribe(res => {

      //this.dropFilhaArray.push(res);

      var str = res.toString();
      str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
      var array = JSON.parse("[" + str + "]");
      this.dropFilhaArray.push(array);

      ////console.log("dropFilhaArray: ",this.dropFilhaArray[0]);
    },
    erro => {
      console.log(erro);
      this.apiService.showError("ANERR0011");
    });
  }

  updateField(dbid1,value1,dbid2,value2,nivel){
    //(console.log("VAI FAZER UPDATE!!!!");
    //var query = "&"+dbid1+"="+value1+"&"+dbid2+"="+value2;
    this.body = new HttpParams();
    this.body = this.body.append(dbid1,value1);
    if(value2=='tecnico_id_cor'){ // COR do TEMA para ir id do tecnico
      var tecnico_id = localStorage.getItem("ID")
      this.body = this.body.append(dbid2,tecnico_id);
      this.mudaCor = value1;
    }else{
      this.body = this.body.append(dbid2,value2);
    }
    this.body = this.body.append("nvl",nivel);

    console.log(this.body.toString());

    if(nivel == 1){
      var path = this.rootUrl+this.uri_gravar+'?token='+this.apiService.getToken()+'&'+this.body.toString()+'&pedido_id='+this.dados.ID;
    }else{
      var path = this.rootUrl+this.uri_gravar_secundario+'?token='+this.apiService.getToken()+'&'+this.body.toString()+'&pedido_id='+this.dados.ID;
    }

    this.getPOST(path, nivel);
  }

  estado(estado, val1,val2, dbid1=0,value1=0,dbid2=0,value2=0,nivel=0) {
    // Estado = 0 vimos do edit. carregamos pela primeira vez na caneta
    // Estado = 1 cancelamos a edição
    // Estado = 2 confirmamos a edição
    // val2 = -1 se estivermos em primário ou então estamos em linhas e é preciso colocar o on_in no ipt
    console.log("INFO::::: ",estado, dbid1,value1,dbid2,value2,nivel);

    if(val2 != -1){
        val1=val1+"_"+val2;
    }
    //console.log("dbid1=",dbid1,"value1=",value1,"dbid2=",dbid2,"value2=",value2,"nivel=",nivel);
    var elementReference = <HTMLInputElement> document.getElementById("ipt"+val1);
    //console.log("ipt atual: ", "ipt"+val1);
    var elementReference1 = <HTMLInputElement> document.getElementById("icnEDIT"+val1);
    //console.log("icon atual: ", "icnEDIT"+val1);
    var elementReference2 = <HTMLInputElement> document.getElementById("icnCHECK"+val1);
    //console.log("icon atual: ", "icnCHECK"+val1);
    var elementReference3 = <HTMLInputElement> document.getElementById("icnCANCEL"+val1);
    //console.log("icon atual: ", "icnCANCEL"+val1);

    if(estado>0){

      this.bool_alterado = true;
      elementReference.disabled = true;
      elementReference1.innerHTML = "edit";
      try{
        elementReference2.innerHTML = "";
        elementReference3.innerHTML = "";
      }catch{
          //dropdown não tem
      }

      if (estado==2){
        console.log("UPDATE estado = 0: ",dbid1,value1,dbid2,value2,nivel);
        this.updateField(dbid1,value1,dbid2,value2,nivel);

      }

    }else if(estado<0){
      this.bool_alterado = !this.bool_alterado;
      try{
        elementReference1.innerHTML == "edit" ? elementReference1.innerHTML = "" : elementReference1.innerHTML = "edit";
        elementReference3.innerHTML == "cancel" ? elementReference3.innerHTML = "" : elementReference3.innerHTML = "cancel";
      }catch{
        //dropdown não tem
      }

      if (estado==-2){
        //console.log("UPDATE estado < 0: ",dbid1,value1,dbid2,value2,nivel);
        this.updateField(dbid1,value1,dbid2,value2,nivel);
      }
    }else{//vai para 0
      this.bool_alterado = true;
      elementReference.disabled = false;
      elementReference1.innerHTML = "";
      elementReference2.innerHTML = "check_circle";
      elementReference3.innerHTML = "cancel";
    }
  }
//------------------------------------------------------------------------------------------- INICIO Função que esta no constructor responsavel por inserir data quando dialog é aberto

  MeteDados(){
    if(this.destino == 'NOVO'){
      this.loader.hide();

      if(this.array[0].dFAPI != null && this.array[0].dFAPI != "null"){
        var str = this.array[0].dFAPI.split(';').toString();
        str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
        var array = JSON.parse("[" + str + "]");
        this.dFAPI.push(array);
        //console.log("dFAPI NO DETAILS: ",this.dFAPI[0]);
        for(var i=0; i<this.dFAPI[0].length; i++){
          if(this.dFAPI[0][i][4] == 8){
            var stringToInt = +this.dFAPI[0][i][0];
            //console.log("ATENCAO QUE ESTE TEM STRING E VAI PARA INT:::::: ", stringToInt);
            this.listaobjPrincipalInserir.push({ title: this.dFAPI[0][i][2], dbid: this.dFAPI[0][i][1], value: stringToInt});
          }else{
            this.listaobjPrincipalInserir.push({ title: this.dFAPI[0][i][2], dbid: this.dFAPI[0][i][1], value: this.dFAPI[0][i][0]});
          }

          //TYPEAHEAD
          if(this.dFAPI[0][i][4]=="51"){
            for(var j=0; j<this.dFAPI[0][i][6].length; j++){
              this.options.push(this.dFAPI[0][i][6][j]);
            }
            console.log("Resultado final: ", this.options)
          }

        }
        console.log("this.listaobjPrincipalInserir FINAL: ", this.listaobjPrincipalInserir);
      }else{
          //console.log("Array vazio");
      }

      if(this.array[0].dFASI != null && this.array[0].dFASI != "null"){
        var str = this.array[0].dFASI.split(';').toString();
        str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
        var array = JSON.parse("[" + str + "]");
        this.dFASI.push(array);
        //console.log("dFASI NO DETAILS: ",this.dFASI[0]);
        for(var i=0; i<this.dFASI[0].length; i++){
          this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: this.dFASI[0][i][0]});
        }
        console.log("this.listaobjSecundarioInserir FINAL: ", this.listaobjSecundarioInserir);
      }else{
          //console.log("Array vazio");
      }
    }

    if(this.destino == 'VER'){
      //Se for falso nao navega para novo componente
      if(this.ondeVouBool == false){

        //console.log("this.dados.array[0].dFAPV: ", this.array[0].dFAPV);
        if(this.array[0].dFAPV != null && this.array[0].dFAPV != "null"){
          //dFAPV
          //console.log("antes do split: ",this.array[0].dFAPV);
          var str = this.array[0].dFAPV.split(';').toString();
          //console.log("strnavirgula: ",str);
          //ADICIONEI POIS DÁ ERRO COM /n
          //console.log ("antes do replace",str);
          str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
          //replace que interfere com \r e \n
          //.replace(/\\/g, "\\\\");
          //console.log ("depois do replace",str);
          var array = JSON.parse("[" + str + "]");
          this.dFAPV.push(array);
          console.log("dFAPV NO DETAILS: ",this.dFAPV[0]);

          //listaobjPrimarioVer
          for(var i=0; i<this.dFAPV[0].length; i++){
            if(this.dFAPV[0][i][4]==8){
              var stringToInt = +this.dFAPV[0][i][0];
              //console.log("ATENCAO QUE ESTE TEM STRING E VAI PARA INT:::::: ", stringToInt);
              this.listaobjPrimarioVer.push({ title: this.dFAPV[0][i][2], dbid: this.dFAPV[0][i][1], value: stringToInt});
            }else if(this.dFAPV[0][i][4]==11 && this.dFAPV[0][i][1]=='cor_plataforma'){ //COR do TEMA
              this.listaobjPrimarioVer.push({ title: this.dFAPV[0][i][2], dbid: this.dFAPV[0][i][1], value: localStorage.getItem('platformColour')});
            }else{
              this.listaobjPrimarioVer.push({ title: this.dFAPV[0][i][2], dbid: this.dFAPV[0][i][1], value: this.dFAPV[0][i][0]});
            }
          }

          console.log("this.listaobjPrimarioVer FINAL: ", this.listaobjPrimarioVer);
        }else{
            //console.log("Array vazio");
        }

        //console.log("this.dados.array[0].dFASV: ", this.array[0].dFASV);
        if(this.array[0].dFASV != null && this.array[0].dFASV != "null"){
          //dFASV
          var str = this.array[0].dFASV.split(';').toString();
          //ADICIONEI POIS DÁ ERRO COM /n
          str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
          //replace que interfere com \r e \n
          //.replace(/\\/g, "\\\\");
          //console.log("STR 700: ", str)
          var array = JSON.parse("[" + str + "]");
          this.dFASV.push(array);
          console.log("dFASV NO DETAILS: ",this.dFASV[0][0]);

          //listaobjSecundarioVer
          for(var i=0; i<this.dFASV[0][0].length; i++){
            var listaobjteste1=[];
            listaobjteste1.length = 0;
            for(var o=0; o<this.dFASV[0][0][i].length; o++){
              listaobjteste1.push({ title: this.dFASV[0][0][i][o][2], dbid: this.dFASV[0][0][i][o][1], value: this.dFASV[0][0][i][o][0]});
            }
            this.listaobjSecundarioVer.push(listaobjteste1);

          }
          console.log("this.listaobjSecundarioVer FINAL: ", this.listaobjSecundarioVer);
        }else{
            //console.log("Array vazio");
        }

        //console.log("this.dados.array[0].dFAPI: ", this.array[0].dFAPI);
        if(this.array[0].dFAPI != null && this.array[0].dFAPI != "null"){
          //dFAPI
          var str = this.array[0].dFAPI.split(';').toString();
          str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
          var array = JSON.parse("[" + str + "]");
          this.dFAPI.push(array);
          console.log("dFAPI NO DETAILS: ",this.dFAPI[0]);

          //listaobjSecundarioInserir
          for(var i=0; i<this.dFAPI[0].length; i++){
            if (this.dFAPI[0][i][0]=="99_IDP"){
              this.listaobjPrincipalInserir.push({ title: this.dFAPI[0][i][2], dbid: this.dFAPI[0][i][1], value: this.dados.ID});
            }else if(this.dFAPI[0][i][4] == 8){
              var stringToInt = +this.dFAPI[0][i][0];
              //console.log("ATENCAO QUE ESTE TEM STRING E VAI PARA INT:::::: ", stringToInt);
              this.listaobjPrincipalInserir.push({ title: this.dFAPI[0][i][2], dbid: this.dFAPI[0][i][1], value: stringToInt});
            }else{
              this.listaobjPrincipalInserir.push({ title: this.dFAPI[0][i][2], dbid: this.dFAPI[0][i][1], value: this.dFAPI[0][i][0]});
            }
          }
          console.log("this.listaobjPrincipalInserir FINAL: ", this.listaobjPrincipalInserir);
        }else{
            //console.log("Array vazio");
        }

        //console.log("this.dados.array[0].dFASI: ", this.array[0].dFASI);
        if(this.array[0].dFASI != null && this.array[0].dFASI != "null"){
          //dFASI
          var str = this.array[0].dFASI.split(';').toString();
          str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
          var array = JSON.parse("[" + str + "]");
          this.dFASI.push(array);
          //console.log("dFASI NO DETAILS: ",this.dFASI[0]);

          //listaobjSecundarioInserir
          for(var i=0; i<this.dFASI[0].length; i++){
            if (this.dFASI[0][i][0]=="99_IDP"){
              this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: this.dados.ID});
            }else if(this.dFASI[0][i][4]==8){
              var stringToInt = +this.dFASI[0][i][0];
              //console.log("ATENCAO QUE ESTE TEM STRING E VAI PARA INT:::::: ", stringToInt);
              this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: stringToInt});
            }else{
              this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: this.dFASI[0][i][0]});
            }

          }
          console.log("this.listaobjSecundarioInserir FINAL: ", this.listaobjSecundarioInserir);
        }else{
            //console.log("Array vazio");
        }
      }else{
        //Se for true navega para caminho definido em seletor
        this.router.navigateByUrl(this.dados.ondeVou);
        //fecha este dialogRef
        this.dialogRef.close();
      }
    }
  }


  //
  // updateNgModel($event, val) {
  //   console.log("Vai fazer refresh!!!");
  //   this.listaobjPrimarioVer[val].value = $event;
  // }
  //
  // updateNgModelSI($event, val){
  //   console.log("ESTOU AQUIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII");
  //   console.log("OLHA O EVENTO:::", $event);
  //   console.log("Vai fazer refresh!!!");
  //   console.log("this.listaobjSecundarioInserir[val].dbid: ", this.listaobjSecundarioInserir[val].dbid, "this.listaobjSecundarioInserir[val].value;: ", this.listaobjSecundarioInserir[val].value);
  //
  //   this.listaobjSecundarioInserir[val].value = $event;
  // }

//------------------------------------------------------------------------------------------- FIM Função que esta no constructor responsavel por inserir data quando dialog é aberto
  contControlo = 0;
  inserirComentario(){
    console.log("ATENÇÂO: ", this.listaobjSecundarioInserir);
    console.log("this.listaobjSecundarioInserir[0].value: ", this.listaobjSecundarioInserir[0].value);
    console.log("this.listaobjSecundarioInserir[2].value: ", this.listaobjSecundarioInserir[2].value);

    //HARDCODED
    if(this.listaobjSecundarioInserir[0].value == "" || this.listaobjSecundarioInserir[1].value == "" || this.listaobjSecundarioInserir[2].value == ""){
      this.apiService.showConfirmation("Alerta","Campos vazio. Insira valor corretos!","warning", "","OK",false);
      this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
        if(borrower == true){
          //sempre ncessario
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        }else if(borrower == false){
          //sempre ncessario
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        }
      });
    }else if(this.contControlo < 1){
      this.body = new HttpParams();
      for (var i = 0; i < this.listaobjSecundarioInserir.length; i++) {
        console.log("OLHA: ", this.listaobjSecundarioInserir[i]);
        //adicionado pois \ e "" não caracteres especiais e dava erro.
        // if(this.listaobjSecundarioInserir[i].value.includes('\\') || this.listaobjSecundarioInserir[i].value.includes('"') ){
        //     this.apiService.showConfirmation('Caracteres proibidos', 'Não pode usar os caracteres \\ e "', 'error');
        //     this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
        //       if(borrower == true){
        //         //sempre ncessario
        //         this.dialogSubscribe.unsubscribe();
        //         this.apiService.changeValue(null);
        //       }else if(borrower == false){
        //         //sempre ncessario
        //         this.dialogSubscribe.unsubscribe();
        //         this.apiService.changeValue(null);
        //       }
        //     });
        //     return false;
        // }else{
          this.body = this.body.append(this.listaobjSecundarioInserir[i].dbid, this.listaobjSecundarioInserir[i].value);
        //}
      };

      //HARDCODED
      if (this.apiService.getRestServer() == 'https://psuporte.werk.pt/ipaapi/') {
        var path = this.rootUrl+this.uri_gravar_secundario+'?token='+this.apiService.getToken()+'&tecnico_id='+this.apiService.getUserID()+'&utilizador_id='+this.apiService.getUserID()+'&pedido_id='+this.dados.ID+'&'+this.body.toString()+'&nvl=2';
      }else{
        //pedido_id é utilizado no MCDT??
        var path = this.rootUrl+this.uri_gravar_secundario+'?token='+this.apiService.getToken()+'&'+this.body.toString()+'&pedido_id='+this.dados.ID+'&nvl=2';
      }

      this.getPOST(path,2);
      this.contControlo++;
    }else{
      console.log("Só uma de cada vez ;)");
    }
  }

  inserirNovo(){
    //Parametros dinamicos
    this.body = new HttpParams();
		for (var i = 0; i < this.listaobjPrincipalInserir.length; i++) {
      //adicionado pois \ e "" não caracteres especiais e dava erro.
      // if(this.listaobjPrincipalInserir[i].value.includes('\\') || this.listaobjPrincipalInserir[i].value.includes('"') ){
      //     this.apiService.showConfirmation('Caracteres proibidos', 'Não pode usar os caracteres \\ e "', 'error');
      //     this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
      //       if(borrower == true){
      //         //sempre ncessario
      //         this.dialogSubscribe.unsubscribe();
      //         this.apiService.changeValue(null);
      //       }else if(borrower == false){
      //         //sempre ncessario
      //         this.dialogSubscribe.unsubscribe();
      //         this.apiService.changeValue(null);
      //       }
      //     });
      //     return false;
      // }else{
        //Não tem caracteres problematicos logo avança
        this.body = this.body.append(this.listaobjPrincipalInserir[i].dbid, this.listaobjPrincipalInserir[i].value);
      //}
		};

    //HARDCODED
    if (this.apiService.getRestServer() == 'https://psuporte.werk.pt/ipaapi/'){
      var path = this.rootUrl+this.uri_gravar+'?token='+this.apiService.getToken()+'&criador_id='+this.apiService.getUserID()+'&tecnico_id='+this.apiService.getUserID()+'&'+this.body.toString()+'&nvl=1';
    }else{
      var path = this.rootUrl+this.uri_gravar+'?token='+this.apiService.getToken()+'&'+this.body.toString()+'&nvl=1';
    }

    this.getPOST(path);
  }

  fechar(){
    //ao fechar dialog não reabre. 1 = fechar e abrir novamente dialog | 2 = fechar e não abrir novamente dialog (necessariio pois precisa de fazer request do que inseriu)
    localStorage.setItem("dialog", "0");
  }

  getPOST(path, nivel=1){
    const headers = new HttpHeaders({});
    //Headers
    headers.append('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token');
    headers.append('Access-Control-Allow-Methods', 'POST');

    //chama spinner e injeta frase que queros mostrar
    this.spinner.show("Atualização em curso, aguarde!");
    return this.http.post(path+'&form_id='+this.id_formulario, { headers: headers })
    .subscribe(
      data => {
        this.result = data;
        console.log("Result: ",this.result);
        this.spinner.hide();
        if(nivel == 1){
          var mostraOuNao = this.result.mensagem.substring(0, 4);
          var mensagemSemSHOW = this.result.mensagem.substring(4);
          if(mostraOuNao == 'SHOW'){
            if(this.result.status){
              this.apiService.showConfirmation(this.result.titulo,mensagemSemSHOW, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer, this.result.botaoConfirmar);
              console.log("AQUI");
              //muda tema
              if(this.mudaCor){
                console.log("NO MUDA COR");
                console.log("this.mudaCor: ", this.mudaCor);
                document.documentElement.style.setProperty('--background', this.mudaCor);
                document.documentElement.style.setProperty('--backgroundSecundary', this.apiService.adjustColor(this.mudaCor,75));
              }
              this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe(
                (borrower) => {
                  if(borrower == true){
                      //console.log("ok");

                      //Aqui não precisa pois fica logo atualizado no Ngmodel
                      // localStorage.setItem("dialog", "1");
                      // this.dialogRef.close();
                      //console.log("Estou aqui");

                      //sempre ncessario
                      this.dialogSubscribe.unsubscribe();
                      this.apiService.changeValue(null);
                  }else if(borrower == false){

                      //console.log("não ok");
                      localStorage.setItem("dialog", "0");
                      this.dialogRef.close();

                      //sempre ncessario
                      this.dialogSubscribe.unsubscribe();
                      this.apiService.changeValue(null);
                  }
              });
            }
          }

        }else{
          if(this.result.status){
            this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer, this.result.botaoConfirmar);
            this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe(
              (borrower) => {
                if(borrower == true){
                    //console.log("ok");
                    //Para não abrir novamente
                    localStorage.setItem("dialog", "1");
                    this.dialogRef.close();
                    //console.log("Estou aqui");

                    //sempre ncessario
                    this.dialogSubscribe.unsubscribe();
                    this.apiService.changeValue(null);
                }else if(borrower == false){

                    //console.log("não ok");
                    //Assim fecha
                    localStorage.setItem("dialog", "0");
                    this.dialogRef.close();

                    //sempre ncessario
                    this.dialogSubscribe.unsubscribe();
                    this.apiService.changeValue(null);
                }
            });
          }
        }
      },
      erro => {
        console.log(erro);
        this.spinner.hide();
        this.apiService.showError("ANERR0004");
      });
  }
}
