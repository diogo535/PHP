import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';
//Service
import { APIService } from '../../../service/api.service'
//HTTP
import { HttpClient,HttpHeaders } from '@angular/common/http';
//Forms
import { Router,RouterEvent, NavigationStart } from '@angular/router';
import { Subscription } from 'rxjs';

import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css']
})
export class PasswordComponent implements OnInit {
  passwordAtual:string;
  passwordNova:string;
  passwordNova2:string;
  hide1:boolean=true;
  hide2:boolean=true;
  hide3:boolean=true;
  header:string = "Alterar palavra chave";
  result:any;
  listaobj = [];
  rootUrl:string;
  name:string;
  routerSubscription: Subscription;

  dialogSubscribe: Subscription;

  teste:string;

  constructor(public apiService: APIService, private router: Router, private http: HttpClient, public dialogRef: MatDialogRef<PasswordComponent>) {
    this.rootUrl = this.apiService.getRestServer();
    this.name = this.apiService.getName();
    this.teste = this.apiService.GETarraylinguas(9);
    console.log("Encomenda do login: ",this.teste);
    console.log("Encomenda do login direto: ",this.apiService.linguas[9]);

  }

  ngOnInit() {
   this.routerSubscription = this.router.events.pipe(
       filter((event: RouterEvent) => event instanceof NavigationStart),
       filter(() => !!this.dialogRef)
     )
     .subscribe(() => {
       this.dialogRef.close();
     });
     console.log("ESTOU NO COMPONENTE PASSWORD!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
   }

  password(){
    if(this.passwordNova == this.passwordNova2){
      if(this.passwordAtual != undefined && this.passwordNova != undefined){
        this.mudarPass();
      }else{
        //success	error	warning	info	question
        this.apiService.showConfirmation("Informação","Preencha os campos.", "info", "", "OK", false);
        this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
          if(borrower == true){
            //sempre necessario
            this.dialogSubscribe.unsubscribe();
            this.apiService.changeValue(null);
          }else if(borrower == false){
            //sempre necessario
            this.dialogSubscribe.unsubscribe();
            this.apiService.changeValue(null);
          }
        });
      }
    }else{
      //success	error	warning	info	question
      this.apiService.showConfirmation("Informação","Palavras chave novas não coincidem!", "info", "", "OK", false);
      this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
        if(borrower == true){
          //sempre necessario
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        }else if(borrower == false){
          //sempre necessario
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        }
      });
    }
  }

  mudarPass(){
    const headers = new HttpHeaders({});
    headers.append('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token');
    headers.append('Access-Control-Allow-Methods', 'POST');

    return this.http.post(this.rootUrl+'change_password?token='+this.apiService.getToken()+'&pswdN='+ this.passwordNova2 + '&pswd=' + this.passwordAtual, { headers: headers })
    .subscribe(
      data => {
        this.result = data;

        if(this.result.status == 'ok' || this.result.status == 'OK' || this.result.status == 'Ok'){

          this.apiService.showConfirmation(this.result.titulo, this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk,this.result.botaoCancelar, this.result.timer);
          this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
            if(borrower == true){
              this.dialogRef.close();
              //Naveva para login
              this.router.navigate(['/login']);

              //sempre necessario
              this.dialogSubscribe.unsubscribe();
              this.apiService.changeValue(null);
            }else if (borrower == false){

              //sempre necessario
              this.dialogSubscribe.unsubscribe();
              this.apiService.changeValue(null);
            }
          });
        }else if(this.result.status == 'error') {
          this.apiService.showConfirmation(this.result.titulo, this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk,this.result.botaoCancelar, this.result.timer);
          this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
            if(borrower == true){

              //sempre necessario
              this.dialogSubscribe.unsubscribe();
              this.apiService.changeValue(null);
            }else if (borrower == false){

              //sempre necessario
              this.dialogSubscribe.unsubscribe();
              this.apiService.changeValue(null);
            }
          });
        }

      },
      erro => {
        console.log(erro);
        this.apiService.showError("ANERR0001");
      }
    );
  }


  iconChange(value:any){
    switch(value){
      case 1:
        this.hide1 = !this.hide1;
        break;
      case 2:
        this.hide2 = !this.hide2;
        break;
      case 3:
        this.hide3 = !this.hide3;
        break;
      default:
        break;
    }
  }

}
