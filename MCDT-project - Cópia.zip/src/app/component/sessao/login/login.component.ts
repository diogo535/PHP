import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { APIService } from './../../../service/api.service';
import { NavbarComponent } from '../../navbar/navbar.component';
import { AppComponent } from '../../../app.component';

import { Subscription } from 'rxjs';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent  implements OnInit {

  hide = true;
  rootUrl:string;
  result:any;
  username:string;
  password:string;
  header:string;

  dialogSubscribe: Subscription;

  linguas = [
    {value: 'ly', viewValue: 'العربية'},
    {value: 'pt', viewValue: 'Português'},
    {value: 'en', viewValue: 'English'}
  ];

  constructor(private http: HttpClient, private apiService: APIService, private navbar: NavbarComponent, private app:AppComponent) {
    this.rootUrl = this.apiService.getRestServer();
    this.header = this.apiService.getLoginHeader();
    this.app.navbarEsconde(1);
  }

  ngOnInit() {
    window.localStorage.clear();
  }

  //Funcao para chamar funcao login()
  keyDownFunction(event:any) {
    if(event.keyCode == 13) {
      this.login();
    }
  }

  login() : void {
    if(this.username != null || this.password != null) {
      const body = new HttpParams().set(`us`, this.username).set(`ps`, this.password);
      const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
      this.http.post(this.rootUrl + 'login?'+body.toString(), { headers: headers, observe: 'error' })
      .subscribe(data =>
        {
          this.result = data;
          if(this.result.status == "error"){
            //success	error	warning	info	question
            this.apiService.showConfirmation(this.result.titulo, this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar);
            this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
              if(borrower == true){
                //sempre necessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
              }else if(borrower == false){
                //sempre necessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
              }
            });
          }else if(this.result.status == "ok"|| this.result.status == "Ok" || this.result.status == "OK"){
              //dinamicamente envia tudo para localStorage que vem no array ls
              Object.keys(this.result.ls).forEach(key => {
                  localStorage.setItem(key, this.result.ls[key]);
              });
              //Mostra a navbar, login esconde sempre a navbar
              this.navbar.loadDataNavBar();
              this.app.navbarMostra(1);
              //aplica tema com cor do utilizador
              this.app.mudaCor();
              //array linguas que vai distribuir por todos os componentes
              this.apiService.SETarraylinguas(this.username);
          }
        }, error => {
          console.log(error);
          this.apiService.showError("ANERR0015");
        });
    }else{
      this.apiService.showError("ANERR0003");
    }
  }
}
