import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient,HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { APIService } from '../../../service/api.service';
import { DialogComponent } from './dialog/dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { AppComponent } from '../../../app.component';

import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
  rootUrl:string;
  result;

  //Valida
  AUTH:boolean = false;
  hide = true;
  userValida: string;
  passValida: string;

  dialogSubscribe: Subscription;

  constructor(private router: Router, private http: HttpClient, private apiService: APIService, public dialog: MatDialog, private app:AppComponent) {

    this.rootUrl = this.apiService.getRestServer();

    this.apiService.showConfirmation("Zona técnica","Pretende continuar?", "warning", "NÃO","SIM",true);

    this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe(
      (borrower) => {
        if(borrower == true){
          //passa logo
          //this.AUTH = true;

          // this.app.navbarMostra(1);
          // this.router.navigateByUrl("/index");

          //sempre necessario
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        }else if(borrower == false){
          //passa logo
          //this.AUTH = true;

          this.app.navbarMostra(1);
          this.router.navigateByUrl("/index");

          //sempre necessario
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        }

    });


  }

  ngOnInit(){
    this.app.navbarEsconde(1);
  }


  keyDownFunction(event) {
    if(event.keyCode == 13) {
      this.validar();
    }
  }

  validar() : void {

    if(this.userValida != null || this.passValida != null) {
      const body = new HttpParams().set(`us`, this.userValida).set(`ps`, this.passValida);
      const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
      this.http.post(this.rootUrl + 'tecnicos?'+body.toString()+"&token="+this.apiService.getToken(), { headers: headers, observe: 'error' })
      .subscribe(data =>
        {
          this.result = data;

          if(this.result.status == "ok" || this.result.status == "Ok" || this.result.status == "OK"){
    				this.AUTH = true;
    			}
    			if(this.result.status == "error"){

          }

        }, error => {
          this.apiService.showError("ANERR0020");
        });
    }else{

    }
  }


}
