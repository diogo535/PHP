import { Component, OnInit, Inject } from '@angular/core';
import { APIService } from '../../../../service/api.service'
//HTTP
import { HttpClient,HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent {

  //Path com caminho base do service
  path = this.service.rootUrl;
  //Path que vai sendo atualizado ao longo dos processos
  path_alterado:string;

  //Variavel global para criacao de dynamicFields definidos no HTML
  dynamicFields = [];

  //nova_listaobj:any;
  listaobj=[];

  //Altera vista nos componente HTML
  bool_estado:boolean;

  constructor(private service: APIService, private http: HttpClient, public dialogRef: MatDialogRef<DialogComponent>, @Inject(MAT_DIALOG_DATA) public data: any) {
    switch(this.data.angular_path){
      case 'cliente':
        this.path_alterado = this.path+'/cliente/'+this.data.path;
        break;
      case 'user':
        this.path_alterado = this.path+'/user/'+this.data.path;
        break;
      default:
        break;
    }
    console.log("PATH ONDE VAI: ",this.path_alterado);
    this.loadData();
    //this.dados = data;

  }

  loadData() {
    this.http.get(this.path_alterado)
		.subscribe(data =>
			{
        var resultArray = Object.keys(data).map((index) => {
          for(var dat in data[index]){
              this.listaobj.push({ title: dat, value: data[index][dat]});
          }
        });

        console.log(this.listaobj);
        if(this.listaobj.length != 0){
          switch(this.data.angular_path){
            case 'cliente':
              this.dynamicFields = [[1,2],[2,2],[3,2],[4,2],[5,2],[6,4],[7,2],[8,2],[9,2],[10,2],[11,2],[12,2],[13,2],[14,2],[15,2],[16,2],[17,2],[18,2],[19,2],[20,2],[21,4]];
              break;
            case 'user':
              this.dynamicFields = [[1,2],[2,2],[3,2],[4,2]];
              break;
            default:
              break;
            }
          }else{
            alert("User esta inativo ou é inexistente");
            this.dialogRef.close();
        }
			}, err => {
        alert("User esta inativo ou é inexistente");
        this.dialogRef.close();
				console.log(err);
			}
		);
  }

  //Função alterna entre editavel ou não-editavel
  estado() {
    //Em casa click altera o estado entre TRUE or FALSE
    this.bool_estado = !this.bool_estado;
    console.log(this.listaobj);
  }

  //Funcao guardar alteraçoes DINAMICA (ALTERAR FUNCOES POST E URL'S para o necessario)
  guardar() {

    //novo array criando na funcao de controlo
    const nova_listaobj = [];

    //Faz array novo com tudo o que foi inserido no dialog
    for(var i = 0; i < this.listaobj.length; i++){
      nova_listaobj.push({ title: this.listaobj[i].title, value: this.listaobj[i].value});
    }

    //Atribui o novo array (em cima populado) ao array criado globalmente
    this.listaobj = nova_listaobj.slice();

    //Logica para que POST usar no update, consoante o que se altera (cliente, advogado, processo, dossier)
    switch(this.data.angular_path) {
       case 'cliente': {
         this.path_alterado = this.path+`/update/`+this.data.angular_path+'/'+this.listaobj[0].value;
         this.POSTCliente(this.path_alterado);
         break;
       }
       case 'user': {
         this.path_alterado = this.path+`/update/`+this.data.angular_path+'/'+this.listaobj[0].value;
         this.POSTUser(this.path_alterado);
         break;
       }
       default: {
         break;
       }
    }

    //Funcao para voltar a mostrar botoes antes da edicao
    this.estado();
  }

//----------------------------------------------------------------------------------------- METOODOS POST -------------------------------------------------------------------------------
  //CLIENTE
  POSTCliente(path) {

    const body = new HttpParams().set(`Nome`, this.listaobj[1].value).set(`Abreviatura`, this.listaobj[2].value).set(`Titulo`, this.listaobj[3].value).set(`NIF`, this.listaobj[4].value).set(`CC`, this.listaobj[5].value).set(`CCValidade`, this.listaobj[6].value).set(`Morada`, this.listaobj[7].value).set(`Localidade`, this.listaobj[8].value).set(`CodPostal`, this.listaobj[9].value).set(`Telefone`, this.listaobj[10].value).set(`Fax`, this.listaobj[11].value).set(`Contacto1`, this.listaobj[12].value).set(`Email1`, this.listaobj[13].value).set(`Telemovel1`, this.listaobj[14].value).set(`Contacto2`, this.listaobj[15].value).set(`Email2`, this.listaobj[16].value).set(`Telemovel2`, this.listaobj[17].value).set(`Contacto3`, this.listaobj[18].value).set(`Email3`, this.listaobj[19].value).set(`Telemovel3`, this.listaobj[20].value).set(`DataCriacao`, this.listaobj[21].value);

    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });

    console.log(body.toString());

    return this.http.post(path, body.toString(), { headers: headers })
    .subscribe(data =>
      {
        console.log(data);
        this.dialogRef.close();
      }, err => {
        console.log("Falhou - Angular side!");
      }
    );
  }

  //USER
  POSTUser(path) {
    const body = new HttpParams().set(`username`, this.listaobj[1].value).set(`first_name`, this.listaobj[2].value).set(`last_name`, this.listaobj[3].value).set(`email`, this.listaobj[4].value);
    const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });

    console.log(body.toString());

    return this.http.post(path, body.toString(), { headers: headers })
    .subscribe(data =>
      {
        console.log(data);
        this.dialogRef.close();
      }, err => {
        console.log("Falhou - Angular side!");
      }
    );
  }
}
