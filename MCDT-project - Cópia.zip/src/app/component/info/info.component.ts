import { Component, OnInit, Input, Injectable, ViewChild, Inject, NgModule, SimpleChanges, ElementRef } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
import { FormBuilder, FormGroup,FormControl } from '@angular/forms';
//Service
import { APIService } from '../../service/api.service'
// import { LoaderService } from '../../loader/loader.service';
import { SpinnerService } from '../../spinner/spinner.service';
import { UploadService } from '../../service/upload.service';
// Router
import { Router } from '@angular/router';

@Component({
  selector: 'app-info',
  templateUrl: './info.component.html',
  styleUrls: ['./info.component.css']
})
export class InfoComponent implements OnInit {

  //Root que vem do API SERVICE GLOBAL
  rootUrl:string;
  dConfig=[];
  dynamicClass="";
  listaobjPrincipalInserir=[];
  //Array que recebe dos dialog-open nos componentes
  dados:any;
  //Recebe array do RestAPI com boolean e msg
  result: any;
  //Subscribe do Dialog
  dialogSubscribe: Subscription;
  //Arrays usados
  par=[];
  impar=[];
  //
  bool_alterado:boolean;

  //fazer depois
  uri_consultar_info=""
  row_id=""
  form_id=""

  //UPLOAD FICHEIROS
  form: FormGroup;

  //Tabela 60
  id_formulario:string;
  descricao:string;
  tipo_formulario:number;
  angular_path:string;
  displayedColumns=[];
  displayedColumnsName=[];
  ondeVou:string;
  componente_angular:string;

  uri_listar:string;
  uri_inserir:string;
  uri_consultar:string;
  uri_gravar_secundario:string;
  uri_gravar:string;
  uri_apagar:string;
  uri_apagar_secundario:string;



  constructor(
      //UPLOAD FILES
      private uploadService: UploadService,
      private formBuilder: FormBuilder,
      private http: HttpClient,
      private apiService: APIService,
  //      private loader:LoaderService,
  //      private router: Router,
      private spinner:SpinnerService,
      private router: Router) {


    // PARAMETROS QUANDO NAVEGA - mocky deixou funcionar apartir daqui
    console.log(this.router.getCurrentNavigation().extras.state); // should log out 'bar'
    this.uri_consultar_info=this.router.getCurrentNavigation().extras.state.uri_consultar
    this.row_id=this.router.getCurrentNavigation().extras.state.row_id
    this.form_id=this.router.getCurrentNavigation().extras.state.form_id

    //-- Inserimos esta parte para receber dados da tabela anterior e entrar para um info com base na info da tabela anterior.

    this.rootUrl = this.apiService.getRestServer();

    console.log("---- this.uri_consultar_info ----", this.uri_consultar_info);

    //this.http.get("https://www.mocky.io/v2/5cb0780c3100008400e13498").subscribe(
    this.http.get(this.apiService.getRestServer()+this.uri_consultar_info+'?token='+this.apiService.getToken()+'&form_id='+this.form_id+'&row_id='+this.row_id+'&assistente_id='+this.apiService.getUserID()).subscribe(
      data => {

        this.result = data;
        console.log(this.result);

        var str = this.result[0].dConfig.split(';').toString();
        str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
        var array = JSON.parse("[" + str + "]");
        this.dConfig.push(array);
        //console.log("dConfig 1",this.dConfig[0]);
        console.log("dConfig 2",this.dConfig[0][0]);
        //console.log("dConfig 3",this.dConfig[0][0][0]);
        //console.log("dConfig 4",this.dConfig[0][0][0][0]);

        //TABELA - TODO só permite uma tabela de cada vez
        for(var y=0; y<this.dConfig[0][0][0].length; y++){
          if(this.dConfig[0][0][0][y][0][4] == 60){
            console.log("TEM DO TIPO 60!!!!!")
            this.uri_listar = this.dConfig[0][0][0][y][0][8][0].uri_listar;
            this.descricao = this.dConfig[0][0][0][y][0][8][0].descricao;
            this.id_formulario = this.dConfig[0][0][0][y][0][8][0].id_formulario;
            this.tipo_formulario = this.dConfig[0][0][0][y][0][8][0].tipo_formulario;

            this.angular_path = this.dConfig[0][0][0][y][0][8][0].angular_path;
            this.ondeVou = this.dConfig[0][0][0][y][0][8][0].ondeVou;
            this.componente_angular = this.dConfig[0][0][0][y][0][8][0].componente_angular;
            this.uri_inserir = this.dConfig[0][0][0][y][0][8][0].uri_inserir;
            this.uri_consultar = this.dConfig[0][0][0][y][0][8][0].uri_consultar;
            this.uri_gravar = this.dConfig[0][0][0][y][0][8][0].uri_gravar;
            this.uri_gravar_secundario = this.dConfig[0][0][0][y][0][8][0].uri_gravar_secundario;
            this.uri_apagar = this.dConfig[0][0][0][y][0][8][0].uri_apagar;
            this.uri_apagar_secundario = this.dConfig[0][0][0][y][0][8][0].uri_apagar_secundario;

            this.displayedColumns.push(this.dConfig[0][0][0][y][0][8][0].displayedColumns[0])
            this.displayedColumnsName.push(this.dConfig[0][0][0][y][0][8][0].displayedColumnsName[0])
          }
        }

        //PAR
        this.listaobjPrincipalInserir=[];
        for(var z=0; z<this.dConfig[0][0].length; z++){
          var temp=[];
          for (var i = 0; i < this.dConfig[0][0][z].length; i++) {
              if(i % 2 === 0) {
                temp.push(this.dConfig[0][0][z][i]);
              }
          }
          this.par.push(temp);
          //IMPAR
          var temp=[];
          var temp1=[];
          for (var i = 0; i < this.dConfig[0][0][z].length; i++) {

              if(i % 2 !== 0) {
                temp.push(this.dConfig[0][0][z][i]);

                for(var t=0; t<this.dConfig[0][0][z][i].length; t++){
                  if (this.dConfig[0][0][z][i][t][0]=="99_IDP"){
                    temp1.push({ index: temp.length-1 , title: this.dConfig[0][0][z][i][t][2], dbid: this.dConfig[0][0][z][i][t][1], value: this.dados.ID});
                  }else if(this.dConfig[0][0][z][i][t][4] == 8){
                    var stringToInt = +this.dConfig[0][0][z][i][t][0];
                    temp1.push({ index: temp.length-1 , title: this.dConfig[0][0][z][i][t][2], dbid: this.dConfig[0][0][z][i][t][1], value: stringToInt});
                  }else{
                    temp1.push({ index: temp.length-1 , title: this.dConfig[0][0][z][i][t][2], dbid: this.dConfig[0][0][z][i][t][1], value: this.dConfig[0][0][z][i][t][0]});
                  }
                }

              }
          }
          this.impar.push(temp);
          this.listaobjPrincipalInserir.push(temp1);
        }

        console.log("ARRAY par: ", this.par);
        console.log("ARRAY impar: ", this.impar);
        console.log("this.listaobjPrincipalInserir: ",  this.listaobjPrincipalInserir);

      }, erro => {
        console.log(erro);
      }
    );
  }

  ngOnInit() {
    //UPLOAD FICHEIROS
    this.form = this.formBuilder.group({
       file: ['']
     });
   }

   //Não repete inputs varias vezes
   fazSoUmaVez(indexDaLista, campo, repeticoes){
     if(repeticoes < 1){
       return true;
     }else{
       return false;
     }
   }

   //consoante lengnt do array faz boostrap
   classDiv(array){
     var num;
     num = array.length;
     //console.log("ESTOU AQUI DENTRO DO CLASS DIV: ", num);
     if(num == 1){
       this.dynamicClass="col-lg-12";
     }
     if(num == 2){
       this.dynamicClass="col-lg-6";
     }
     if(num == 3){
       this.dynamicClass="col-lg-4";
     }
     if(num == 4){
       this.dynamicClass="col-lg-3";
     }

     //console.log("this.dynamicClass: ", this.dynamicClass);
     return this.dynamicClass;
   }




   //--------------------------- INICIO UPLOAD FICHEIROS
      nameFile:string;
      btnShow:boolean;

       onFileSelect(event) {
        if (event.target.files.length > 0) {
          const file = event.target.files[0];
          this.form.get('file').setValue(file);
          this.nameFile = file.name;
          this.btnShow = true;
        }
       }

       //FALTA ARGUMENTOS
       onSubmit() {
        // const formData = new FormData();
        // formData.append('file', this.form.get('file').value);
        //
        // //chama spinner e injeta frase que queros mostrar
        // this.spinner.show("Aguarde, a fazer upload para a nuvem!");
        // this.uploadService.uploadFile(formData).subscribe(
        //   (res) => {
        //     this.spinner.hide()
        //     this.result = res;
        //
        //     if(this.result){
        //       this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer,this.result.botaoConfirmar);
        //       this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
        //         if(borrower == true){
        //             this.reset();
        //             //sempre ncessario
        //             this.dialogSubscribe.unsubscribe();
        //             this.apiService.changeValue(null);
        //         }else if(borrower == false){
        //           console.log("lá vai ele repetir");
        //           //sempre ncessario
        //           this.dialogSubscribe.unsubscribe();
        //           this.apiService.changeValue(null);
        //         }
        //       });
        //     }
        //   },
        //   (err) => {
        //     console.log(err);
        //   }
        // );
       }

      reset() {
        this.btnShow = false;
        this.nameFile = "";
      }


   //--------------------------- FIM UPLOAD FICHEIROS


  //-------------------------------- INICIO CAMPOS EDITAVEIS

  estado(estado, val1,val2, dbid1=0,value1=0,dbid2=0,value2=0,nivel=0) {
    // Estado = 0 vimos do edit. carregamos pela primeira vez na caneta
    // Estado = 1 cancelamos a edição
    // Estado = 2 confirmamos a edição
    // val2 = -1 se estivermos em primário ou então estamos em linhas e é preciso colocar o on_in no ipt
    console.log("INFO::::: ",estado, dbid1,value1,dbid2,value2,nivel);

    if(val2 != -1){
        val1=val1+"_"+val2;
    }
    //console.log("dbid1=",dbid1,"value1=",value1,"dbid2=",dbid2,"value2=",value2,"nivel=",nivel);
    var elementReference = <HTMLInputElement> document.getElementById("ipt"+val1);
    //console.log("ipt atual: ", "ipt"+val1);
    var elementReference1 = <HTMLInputElement> document.getElementById("icnEDIT"+val1);
    //console.log("icon atual: ", "icnEDIT"+val1);
    var elementReference2 = <HTMLInputElement> document.getElementById("icnCHECK"+val1);
    //console.log("icon atual: ", "icnCHECK"+val1);
    var elementReference3 = <HTMLInputElement> document.getElementById("icnCANCEL"+val1);
    //console.log("icon atual: ", "icnCANCEL"+val1);

    if(estado>0){

      this.bool_alterado = true;
      elementReference.disabled = true;
      elementReference1.innerHTML = "edit";
      elementReference2.innerHTML = "";
      elementReference3.innerHTML = "";

      if (estado==2){
        console.log("UPDATE estado = 0: ",dbid1,value1,dbid2,value2,nivel);
        //this.updateField(dbid1,value1,dbid2,value2,nivel);

      }

    }else if(estado<0){
      this.bool_alterado = !this.bool_alterado;
      elementReference1.innerHTML == "edit" ? elementReference1.innerHTML = "" : elementReference1.innerHTML = "edit";
      elementReference3.innerHTML == "cancel" ? elementReference3.innerHTML = "" : elementReference3.innerHTML = "cancel";
      if (estado==-2){
        console.log("UPDATE estado < 0: ",dbid1,value1,dbid2,value2,nivel);
        //this.updateField(dbid1,value1,dbid2,value2,nivel);
      }
    }else{//vai para 0
      this.bool_alterado = true;
      elementReference.disabled = false;
      elementReference1.innerHTML = "";
      elementReference2.innerHTML = "check_circle";
      elementReference3.innerHTML = "cancel";
    }
  }
  //-------------------------------- FIM CAMPOS EDITAVEIS
}
