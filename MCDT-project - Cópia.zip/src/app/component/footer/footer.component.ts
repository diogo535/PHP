import { Component, OnInit } from '@angular/core';
import { APIService } from '../../service/api.service';

import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  dialogSubscribe: Subscription;
  fullYear: number;

  constructor(private apiService:APIService) { }

  ngOnInit() {
    var date = new Date();
    this.fullYear = date.getFullYear();
  }

  vaiSugestoes(){
    this.apiService.showConfirmation("Sugestões","Caso tenha alguma sugestão para melhoria de alguma das funcionalidades existentes ou para uma nova funcionalidade, entre em contacto connosco através do email mcdt@werk.pt ou pelo telefone +351 211 570 970.","info","","OK", false);
    this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
      if(borrower == true){
        //sempre ncessario
        this.dialogSubscribe.unsubscribe();
        this.apiService.changeValue(null);
      }
    });
  }

}
