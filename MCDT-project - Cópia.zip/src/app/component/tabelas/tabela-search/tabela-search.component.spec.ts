import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabelaSearchComponent } from './tabela-search.component';

describe('TabelaSearchComponent', () => {
  let component: TabelaSearchComponent;
  let fixture: ComponentFixture<TabelaSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabelaSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabelaSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
