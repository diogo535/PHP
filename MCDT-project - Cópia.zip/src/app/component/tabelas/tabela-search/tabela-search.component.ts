//Componente
import { Component, OnInit, Input, Output, EventEmitter  } from '@angular/core';
import { APIService } from '../../../service/api.service'
//Tabela
import { MatTableDataSource, MatSort } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import { ViewChild, Inject } from '@angular/core';
import { HttpClient,HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { MatButtonModule, MatTableModule, MatSortModule, MatPaginatorModule, MatIconModule, MatCardModule, MatFormFieldModule, MatInputModule,  MatPaginator, MatMenuModule, MatDialogModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormControl, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-tabela-search',
  templateUrl: './tabela-search.component.html',
  styleUrls: ['./tabela-search.component.css']
})

export class TabelaSearchComponent implements OnInit {

  //Inputs defenidos quando se chama a tabela
	@Input() path: string="test-local";
	@Input() displayedColumns: any[]=[];
  @Input() angular_path='';
  @Input() pathTitle='';
  //OUTPUT details.component CLIENTE
  @Output() IDSearchCliente = new EventEmitter<string>();
  @Output() NumeroSearchCliente = new EventEmitter<string>();
  @Output() NomeSearchCliente = new EventEmitter<string>();
  //OUTPUT details.component ADVOGADOS
  @Output() IDSearchAdvogado = new EventEmitter<string>();
  @Output() NomeSearchAdvogado = new EventEmitter<string>();
  //COMPONENTES TABELA
  dataSource = new MatTableDataSource();
  //Se der erro meter a true ou false, angular 7 necessariio
	@ViewChild(MatSort, {static: true}) sort: MatSort;
	@ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

  displayedColumns_controlo=[];
  list = [];
  toppingList:any;
  ivo = [];

	constructor(private apiService: APIService, private http: HttpClient) {

  }

	ngAfterViewInit() {
	    this.dataSource.sort = this.sort;
	    this.dataSource.paginator = this.paginator;
  }

	ngOnInit(){
    this.loadData();
    //Funcao para descontruir URL do RestServer PATHTILE em array
    this.fazEssa();
    //Faz copia do que inicialmente esta default no displayedColumns para depois repor
    this.displayedColumns_controlo = this.displayedColumns;
    //console.log(this.displayedColumns_controlo);
	}

	applyFilter(filterValue: string) {
	    filterValue = filterValue.trim();
	    filterValue = filterValue.toLowerCase();
	    this.dataSource.filter = filterValue;
  }

  //Funcao para descontruir URL do RestServer PATHTILE em array
    fazEssa(){
      this.http.get(this.pathTitle).subscribe(res => {
        var resultArray = Object.keys(res).map((index) => {
          for(var dat in res[index]){
            this.ivo.push(dat);
          }
        });
      });
      //console.log("Array de campos" + this.ivo);
      this.toppingList = this.ivo;
    }

  //Funcao responsavel por fazer array dos campos personalizados para a tabela
   onEnter(entry) {
      this.list.push(entry);

      //INICIO Verifica e apaga se houver duplicados
      var newArr = this.list;
      var h,i,j;

      for(h = 0; h < this.list.length; h++) {
          var curItem = this.list[h];
          var foundCount = 0;
          // search array for item
          for(i = 0; i < this.list.length; i++) {
              if (this.list[i] == this.list[h])
                  foundCount++;
          }
          if(foundCount > 1) {
              // remove repeated item from new array
              for(j = 0; j < newArr.length; j++) {
                  if(newArr[j] == curItem) {
                      newArr.splice(j, 1);
                      j--;
                  }
              }
          }
      }
      //FIM Verifica e apaga se houver duplicados

      //Se array estiver fazio altera para DEFAULT
      if(newArr.length == 0){
        //console.log("Vazio");
        //console.log(this.displayedColumns_controlo);
        this.displayedColumns = this.displayedColumns_controlo;
      }else{
        //console.log("Tem material");
        this.displayedColumns = newArr;
        //console.log(newArr);
      }
    }

  vamosla(data) {
    //console.log(this.angular_path);
    switch(this.angular_path){
      case "cliente":
        //console.log("funcao deu " + data.ClienteID + " e "+ data.Nome);
        this.IDSearchCliente.emit(data.ClienteID);
        this.NumeroSearchCliente.emit(data.NumeroCliente);
        this.NomeSearchCliente.emit(data.NomeCliente);
        break;

      case "advogado":
        //console.log("funcao deu " + data.AdvogadoID + " e "+ data.Nome);
        this.IDSearchAdvogado.emit(data.AdvogadoID);
        this.NomeSearchAdvogado.emit(data.NomeAdvogado);
        break;

      default:
        break;
    }
  }


  //Funcao LoadData chamada em ngOnInit
  public loadData() {
    this.apiService.getData(this.path).subscribe(value => {
			this.dataSource = new MatTableDataSource(value);
			this.dataSource.sort = this.sort;
			this.dataSource.paginator = this.paginator;
		},
		erro => {console.error("Erro a receber os tickets!", erro),
		this.dataSource=new MatTableDataSource();
		});
  }

}
