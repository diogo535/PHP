  //Base
import { Component, OnInit, Input, Injectable, ViewChild, Inject, NgModule, SimpleChanges, ElementRef } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { BehaviorSubject ,  Observable, Subscription } from 'rxjs';
import { BrowserModule } from '@angular/platform-browser';
//Service
import { APIService } from '../../../service/api.service'
import { LoaderService } from '../../../loader/loader.service';
import { SpinnerService } from '../../../spinner/spinner.service';
//Tabela
import { CdkTableModule } from '@angular/cdk/table';
import { MatTableDataSource, MatSort,MatButtonModule, MatTableModule, MatSortModule, MatPaginatorModule, MatIconModule, MatCardModule, MatFormFieldModule, MatInputModule,  MatPaginator, MatMenuModule, MatDialogModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//HTTP
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
//Forms
import { ReactiveFormsModule, FormControl, Validators, FormGroup, FormsModule } from '@angular/forms';
//Componentes
import { DetailsComponent } from '../../details/details.component';
import { DetailstepperComponent } from '../../detailstepper/details.component';
//Dialog
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';
//Router
import { Router } from '@angular/router';
//Download
import * as fileSaver from 'file-saver';
import * as FileSaver from 'file-saver';
//PDF
import jsPDF from 'jspdf';
import 'jspdf-autotable';

@Component({
  selector: 'app-tabela',
  templateUrl: './tabela.component.html',
  styleUrls: ['./tabela.component.css']
})

@Injectable()
export class TabelaComponent implements OnInit {

  //Root que vem do API SERVICE GLOBAL
  rootUrl:string;
  result:any;
  @Input() displayedColumnsName=[];
  @Input() displayedColumns=[];
  @Input() angular_path='';
  @Input() ondeVou='';
  @Input() componente_angular='';
  @Input() id_formulario='';
  @Input() descricao='';
  @Input() tipo_formulario=0;
  @Input() uri_listar='';
  @Input() uri_consultar='';
  @Input() uri_inserir='';
  @Input() uri_gravar='';
  @Input() uri_gravar_secundario='';
  @Input() uri_apagar='';
  @Input() uri_apagar_secundario='';

  contentTable:any;
  nivelPesquisa:boolean;
  path="";

  //Para campos personalizados da tabela
  displayedColumns_controlo=[];
  list = [];
  toppingList = ['nome','morada','localidade','telefone','telemovel','email'];

  //Tabela
  dataSource = new MatTableDataSource();

  //angular 7 necessariio
  @ViewChild(MatSort, {static: false}) sort: MatSort;
  @ViewChild(MatPaginator, {static: false}) paginator: MatPaginator;
  //Pequisa com campos personalizados
  pesquisaName = '';
  pesquisaValue = 'empty';
  key: string;
  pesquisaBool:boolean;
  //
  dataTitlePrimario=[];
  dataTitleSecundario=[];
  //options
  optionsArray = [];
  //
  tickets = [];
  array=[];
  cont:number = 0;
  arrayPesquisa=[];
  arrayPesquisaNomes=[];

  //Array global para controlar dados que veem da tabela
  listaobj = [];

  //Subscribe do Dialog
  dialogSubscribe: Subscription;

  keywordSearch:string;

  //dropdown limitada dos campos da tabelas
  //Dropdown pesquisaLimitada
  formControlObj: FormControl;

  //usado em action61 no href
  token='';

  nivelPesq=-1;


	constructor(private apiService: APIService, public dialog: MatDialog, private http: HttpClient, private loader:LoaderService, private router: Router, private spinner:SpinnerService) {
    this.rootUrl = this.apiService.getRestServer();

    //inicializa Form
    this.formControlObj = new FormControl();
  }

	ngOnInit(){
    //usado em href do action61
    this.token = this.apiService.getToken();
    this.displayedColumns_controlo = this.displayedColumns;

    //chamada HTTP para dados para construir tabela
    this.loadData();

    // para criar PDF na funcao print() com colunas dinamicas da tabela
    for(var i=0; i<this.displayedColumnsName[0].length; i++){
      this.arrayPesquisa.push({value: this.displayedColumns[0][i], viewValue: this.displayedColumnsName[0][i]})
    }


	}

  async ngAfterViewInit() {
      var responseData = await this.loadData();
      if (!responseData) {
          this.dataSource.sort = this.sort;
          this.dataSource.paginator = this.paginator;
      }
  }

  //Carrega dados para a tabela
  loadData(id_formulario=null): Promise<any[]> {
    this.loader.show();
    var path = this.apiService.getRestServer()+this.uri_listar+'?token='+this.apiService.getToken()+'&form_id='+this.id_formulario;
    return this.http.get(path)
      .toPromise()
      .then(value => JSON.parse(JSON.stringify(value)))
      .then(value => {
        //mostra erro
        if(value.status=='error'){
          //console.log(value);
          this.apiService.showConfirmation(value.titulo, value.mensagem, value.tipoAlerta, value.textoBotaoCancelar, value.textoBotaoOk, value.botaoCancelar, value.timer, value.botaoConfirmar);
        }

        this.loader.hide();

        //para a criacao do PDF no print()
        this.dataSource = new MatTableDataSource(value);

        //construi objecto dinamico com todos os campos da tabela da NOVA PESQUISA/DROPDOWN
        var cont=0;
        for(var i in value){
          var size = Object.keys(value[i]).length;
          for(var j in value[i]){
            if(cont < size){
              this.filteredValues[j]='';
              cont++;
            }
          }
        }

        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;

        return value;
      })
  }

  //Funcao quando se carrega numa linha da tabela
  processData(data, uri_consultar=null, id_formulario=null, contNovo=false, ondeVou=null, uri_gravar=null, uri_gravar_secundario=null, campo_action=null){

    var ID_row;

    // if(campo_action == 'action01' || campo_action == 'action02' ){
    //   return 1;
    // }
    if(data == null){
      ID_row = localStorage.getItem("pedido_id");
    }else{
      ID_row = data.id;
      localStorage.setItem("pedido_id", data.id);
    }

    if(uri_consultar != null){
      this.uri_consultar = uri_consultar;
    }

    if(id_formulario != null){
      this.id_formulario = id_formulario;
    }

    if(ondeVou != undefined){
      //undefined não deixa passar null
      this.ondeVou = ondeVou;
    }else if(ondeVou == null){
      this.ondeVou = null;
    }

    if(uri_gravar != null){
      this.uri_gravar = uri_gravar;
    }

    if(uri_gravar_secundario != null){
      this.uri_gravar_secundario = uri_gravar_secundario;
    }

    if(this.cont < 1 || contNovo == true){
      //mostra barra de progresso
      this.loader.show();
      //console.log(this.rootUrl+this.uri_consultar+'?pedidoid='+ID_row+'&token='+this.apiService.getToken()+'&form_id='+this.id_formulario);
      this.http.get(this.rootUrl+this.uri_consultar+'?pedidoid='+ID_row+'&token='+this.apiService.getToken()+'&form_id='+this.id_formulario).subscribe(
        res => {
          //tirar barra de progresso
          this.loader.hide();

          switch (this.componente_angular) {
            //necessario pois formularios do tipo 1 tem componente_angular do que vão chamar (novo) e linhas são sempre DetailsComponent
            case 'DetailstepperComponent':
            case 'DetailsComponent':
              const dialogRef = this.dialog.open(DetailsComponent, {
                  width: '80%',
                  height: '80%',
                  autoFocus: false,
                  disableClose: true,
                  data: {
                    //Array normal
                    array: res,
                    //Para verificar como proceder em details
                    destino:'VER',
                    //Para saber se navega para novo component ou mantem no mesmo
                    ondeVou: this.ondeVou,
                    //Passa ID da row do pedido para DIALOG
                    ID: ID_row,
                    //Para RestServer KEYWORD do link (IMPORTANTE) e saber que funcao chamar a inserir
                    info: this.angular_path,
                    //Passa id do formaulario que vem no config_component
                    id_formulario: this.id_formulario,
                    //passa valor da uri_gravar que vem no config_component
                    uri_gravar: this.uri_gravar,
                    //passa valor da uri_gravar_secundario que vem no config_component
                    uri_gravar_secundario: this.uri_gravar_secundario,
                    //caminho para apagar pedidos
                    uri_apagar: this.uri_apagar,
                    //Caminho para apagar linhas
                    uri_apagar_secundario: this.uri_apagar_secundario
                  }
              });

              // Quando fecha dialog chama load para atualizar
              dialogRef.afterClosed().subscribe(() => {
                console.log("ESTOU AQUI!!!");

                //mete cont que faz controlo das vezes que carregamos para abrir dialog
                this.cont = 0;

                //Conficao para verificar local storage
                if(localStorage.getItem("dialog") == "1"){
                  //chama esta funcao caso utilizador escolher continuar a inserir no dialog
                  this.processData(null,uri_consultar, id_formulario, contNovo, ondeVou, uri_gravar, uri_gravar_secundario);
                  //uri_consultar=null, id_formulario=null, contNovo=false, ondeVou=null, uri_gravar=null, uri_gravar_secundario=null
                }else{
                  localStorage.setItem("dialog", "0");
                  //HARDCODED - METER SEMPRE QUE TEM NOVOS!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                  if (this.apiService.getRestServer() == 'https://psuporte.werk.pt/ipaapi/') {
                    if (this.router.url === '/pedidosabertos'){
                      this.loadData();
                    }
                  }else{
                    if (this.router.url === '/requisicoes' || this.router.url === '/formularios' || this.router.url === '/ccf' || this.router.url === '/entidades'){
                      this.loadData();
                    }
                  }

                }
              });
              break;
            //caso seja para navegar para InfoComponent
            case 'InfoComponent':
              this.router.navigate(['infocomponentetestes'], { state: { uri_consultar: this.uri_consultar, row_id: data.id, form_id: this.id_formulario } });
              break;

            default:
              break;
          }


        },
        erro => {
          this.loader.hide();
          //erro sem resposta
          this.apiService.showError("ANERR0013");
        }
      );
    }
    this.cont++;
  }

  //Botão novo registo da tabela
  addNew(){
    //controlo de clicks
    this.cont++;

    //logica do controlo de clicks
    if(this.cont > 1){
      //console.log("Só podes entrar 1x........");
    }else{

      //mostra barra de progresso
      this.loader.show();

      //console.log(this.rootUrl+this.uri_inserir+'?token='+this.apiService.getToken()+'&form_id='+this.id_formulario);
      this.http.get(this.rootUrl+this.uri_inserir+'?token='+this.apiService.getToken()+'&form_id='+this.id_formulario).subscribe(
        res => {
          //console.log("Resposta do pedido: ",res);

          //tirar barra de progresso
          this.loader.hide();

          //logica consoante vem true ou false (vai para DetailstepperComponent OU DetailsComponent)
          //console.log("PARA QUAL VOU???????");
          if (res[0].steps != "null") {
            console.log("VOU PARA O DetailstepperComponent");
            const dialogRef = this.dialog.open(DetailstepperComponent, {
              width: '80%',
              height: '80%',
              autoFocus: false,
              disableClose: true,
              data: {
                //Array normal
                array: res,
                //Para verificar como proceder em details HARDCODED
                destino:'NOVO',
                //Para saber se navega para novo component ou mantem no mesmo HARCODED
                ondeVou: 'null',
                //Para RestServer KEYWORD do link (IMPORTANTE) e saber que funcao chamar a inserir
                // info: this.angular_path,
                //Passa id do formaulario que vem no config_component
                id_formulario: this.id_formulario,
                // //passa valor da uri_inserir que vem no config_component
                // uri_inserir: this.uri_inserir,
                // //passa valor da uri_gravar que vem no config_component
                // uri_gravar: this.uri_gravar
              }
            });
            // Quando fecha dialog chama load para atualizar
            dialogRef.afterClosed().subscribe(() => {
              //mete cont que faz controlo das vezes que carregamos para abrir dialog
              this.cont = 0;
              //faz refresh dos dados a tabela
              this.loadData();
              //Conficao para verificar local storage
              if(localStorage.getItem("dialog") == "1"){
                //chama esta funcao caso utilizador escolher continuar a inserir no dialog
                this.processData(null);
              }else{
                localStorage.setItem("dialog", "0");
              }
            });
          }else if (res[0].steps == "null"){
            console.log("VOU PARA O DetailsComponent");
            const dialogRef = this.dialog.open(DetailsComponent, {
              width: '80%',
              height: '80%',
              autoFocus: false,
              disableClose: true,
              data: {
                //Array normal
                array: res,
                //Para verificar como proceder em details HARDCODED
                destino:'NOVO',
                //Para saber se navega para novo component ou mantem no mesmo HARCODED
                ondeVou: 'null',
                //Para RestServer KEYWORD do link (IMPORTANTE) e saber que funcao chamar a inserir
                //info: this.angular_path,
                //Passa id do formaulario que vem no config_component
                id_formulario: this.id_formulario,
                // //passa valor da uri_inserir que vem no config_component
                // uri_inserir: this.uri_inserir,
                // //passa valor da uri_gravar que vem no config_component
                // uri_gravar: this.uri_gravar
              }
            });
          // Quando fecha dialog chama load para atualizar
          dialogRef.afterClosed().subscribe(() => {
            //mete cont que faz controlo das vezes que carregamos para abrir dialog
            this.cont = 0;
            //faz refresh dos dados a tabela
            this.loadData();

          });

        }

      },
    erro => {
      this.loader.hide();

      this.apiService.showError("ANERR0014");
    }
    );
  }
}

  //Descarregar XML TENHO QUE ALTERAR
  xml(id){
  //   console.log("ID: ", id);
  //   //this.http.get(this.rootUrl+'TESTEEEEEEEEEEEEEEE'+'?pedidoid='+id+'&token='+this.apiService.getToken()+'&form_id='+this.id_formulario).subscribe(
  //   this.http.get("http://localhost/XML/RestServer/example/teste").subscribe(
  //     res => {
  //       this.result = res;
  //       var elementReference = <HTMLAnchorElement> document.getElementById("xml_download");
  //       elementReference.href=this.result.dados.link;
  //       elementReference.click();
  //     },
  //     erro => {
  //       this.apiService.showError("ANERR0052");
  //     }
  //   );
  }

  //FUNCIONALIDADE BETA: Carregar ficheiros
  attachFile(id, values){
    // arrayValues=[];
    // arrayValues.push(values.split("##"));
    // console.log("VALORES: ", arrayValues);



    // this.http.get(this.rootUrl+this.attach_file+'?token='+this.apiService.getToken()+'&pedidoid='+id).subscribe(
    //   res => {
    //     //console.log("Resposta do pedido: ",res);
    //
    //     //tirar barra de progresso
    //     this.loader.hide();
    //
    //     const dialogRef = this.dialog.open(DetailsComponent, {
    //       width: '80%',
    //       height: '80%',
    //       autoFocus: false,
    //       disableClose: true,
    //       data: {
    //         //Array normal
    //         array: res,
    //         //Para verificar como proceder em details HARDCODED
    //         destino:'NOVO',
    //         //Para saber se navega para novo component ou mantem no mesmo HARCODED
    //         ondeVou: 'null',
    //         //Para RestServer KEYWORD do link (IMPORTANTE) e saber que funcao chamar a inserir
    //         // info: this.angular_path,
    //         //Passa id do formaulario que vem no config_component
    //         id_formulario: this.id_formulario,
    //         // //passa valor da uri_inserir que vem no config_component
    //         // uri_inserir: this.uri_inserir,
    //         // //passa valor da uri_gravar que vem no config_component
    //         // uri_gravar: this.uri_gravar
    //       }
    //     });
    //     // Quando fecha dialog chama load para atualizar
    //     dialogRef.afterClosed().subscribe(() => {
    //       //mete cont que faz controlo das vezes que carregamos para abrir dialog
    //       this.cont = 0;
    //       //faz refresh dos dados a tabela
    //       this.loadData();
    //       //Conficao para verificar local storage
    //       if(localStorage.getItem("dialog") == "1"){
    //         //chama esta funcao caso utilizador escolher continuar a inserir no dialog
    //         this.processData(null);
    //       }else{
    //         localStorage.setItem("dialog", "0");
    //       }
    //     });
    //   },
    //   erro => {
    //         this.loader.hide();
    //         this.dataSource=new MatTableDataSource();
    //         this.apiService.showError("ANERR0007");
    //   });
    }

  //Funcao para PDF
  print(){
    let doc = new jsPDF();
    this.contentTable = this.dataSource.filteredData;
    console.log("VALOR: ", this.contentTable);

    //caso tabela não tenha dados
    if(this.contentTable.length > 0){
      var displayedColumnsNameList = new Array();
      for (var i = 0; i < this.displayedColumnsName[0].length; i++){
         displayedColumnsNameList.push(this.displayedColumnsName[0][i]);
      }

      var contentTableListALL = new Array();
      for (var i = 0; i < this.contentTable.length; i++){
        var contentTableList = new Array();
        for (var x = 0; x < this.displayedColumns.length; x++){
          for (var y = 0; y < this.displayedColumns[x].length; y++){
            //console.log(this.displayedColumns[x][y]);
            contentTableList.push(this.contentTable[i][this.displayedColumns[x][y]]);
          }
        }
        contentTableListALL.push(contentTableList);
      }

      doc.autoTable({
        head: [displayedColumnsNameList], //[['Cabeçalho','', 'Cabeçalho2', 'Cabeçalho3']],
        body: contentTableListALL //[["linha1", "linha1", "linha1"], ["linha2", "linha2", "linha2"]]
      });
      doc.save('tabela.pdf')
    }else{
      this.apiService.showConfirmation('Tabela sem valores', 'Não existem dados carregados para impressão.','info','','OK', false);
    }
  }


  //***************************************************************************************************************************************************************************************
  // INICIO NOVA PESQUISA/DROPDOWN PESQUISA POR VARIOS CAMPOS-----------------------------------------------------------------------------------------------------------------------
  //***************************************************************************************************************************************************************************************
  filteredValues = {};
  //calcular tipo % para cada input ocupar dinamicamente
  finalVal=97;
  sizeDinamic(val) {
    if(val != undefined){
      if(val == 0 || val == 1){
        this.finalVal = 97;
      }else{
        this.finalVal = 97/val;
      }
      //console.log("VAL COM QUE VOU TRABALHAR::: ", val);
      //const styles = {'width' : finalVal};
      //console.log("Valor dinamico: ", styles);
    }
    //return styles;
  }

  //quando dropdown estiver limitada a 5 campos para caso selecione -1 volte a mostrar todos com os devidos selecionados anteriormente
  onEnterSearchLimitado(event, value, viewValue){
    if (event.isUserInput) {
      var restoDoDicinarioLimitado=[];

      for(var i=0; i<this.arrayPesquisaLimitado.length; i++){
        if(this.arrayPesquisaLimitado[i].value == value){


          for(var t=i+1; t<this.arrayPesquisaLimitado.length; t++){
            console.log("indice do que vamos continuar: ", t);
            restoDoDicinarioLimitado.push({value:this.arrayPesquisaLimitado[t].value, viewValue:this.arrayPesquisaLimitado[t].viewValue, ngModel:this.arrayPesquisaLimitado[t].ngModel});
          }

          //splice apaga tudo para abaixo apartir do indice que tem
          this.arrayPesquisaLimitado.splice(i);
        }
      }

      //vai fazer merge do dicionario temporario com registos que splice apagou com dicionario final.
      if(restoDoDicinarioLimitado){
        for(var x=0; x<restoDoDicinarioLimitado.length; x++){
          this.arrayPesquisaLimitado.push({value:restoDoDicinarioLimitado[x].value, viewValue:restoDoDicinarioLimitado[x].viewValue, ngModel:restoDoDicinarioLimitado[x].ngModel});
        }
      }
      console.log("arrayPesquisaLimitado: ", this.arrayPesquisaLimitado);

      if(this.arrayPesquisaLimitado.length < 5){
        //leva quarto parametro porque tem default values e por isso automaticamente preenche os checkbox dos restantes
        this.onEnterSearch(event, value, viewValue, 1);
      }
    }

  }

  //usado pelo automatismo do mat-options em que os seleciona sozinhos
  compare(c1, c2: {value: string}) {
    return c1 === c2.value;
  }

  listaPesquisa = [];
  arrayPesquisaLimitado = [];

  onEnterSearch(event, value, viewValue, defaultValues=null){
    //limpa valores que vai aparecer no placeholder da pesquisa na tabelas
    if (event.isUserInput) {
      if(this.listaPesquisa.length == 0){
        this.listaPesquisa.push({value:value, viewValue:viewValue, ngModel:''});
      }else{
        var meteOuNao:boolean=null;
        var restoDoDicinario=[];
        for(var i=0; i<this.listaPesquisa.length; i++){
          if(this.listaPesquisa[i].value == value){
            console.log("Vai retirar");
            console.log("indice do que vamos apagar: ", i);


            for(var t=i+1; t<this.listaPesquisa.length; t++){
              console.log("indice do que vamos continuar: ", t);
              restoDoDicinario.push({value:this.listaPesquisa[t].value, viewValue:this.listaPesquisa[t].viewValue, ngModel:this.listaPesquisa[t].ngModel});
            }

            //splice apaga tudo para abaixo apartir do indice que tem, enfim
            this.listaPesquisa.splice(i);

            meteOuNao=false;

            //vai limpar o valor retirado do dicionario e voltar a correr a pesquisa aos campos disponiveis
            this.filteredValues[value]="";
            this.applyFilter(1);
          }else{
            meteOuNao=true;
            console.log("Vai meter");
          }
        }

        //faz focus para o ultimo input da pesquisa
        // var val = this.listaPesquisa.length-1;
        // console.log("tamanho:",this.listaPesquisa.length);
        // console.log("onEnterSearch - O QUE VAI FAZER FOCUS: ", "inp"+val);
        // var elementReference = <HTMLInputElement> document.getElementById("inp"+val);
        // console.log("elementReference: ", elementReference);
        // if(<HTMLInputElement> document.getElementById("inp-1")){
        //   console.log("NO INP-1!!!");
        //   var elementReference = <HTMLInputElement> document.getElementById("inp");
        //   elementReference.focus();
        // }else{
        //   elementReference.focus();
        // }

      }
      if(meteOuNao){
        this.listaPesquisa.push({value:value, viewValue:viewValue, ngModel:''});
      }

      //vai fazer merge do dicionario temporario com registos que splice apagou com dicionario final.
      if(restoDoDicinario){
        for(var x=0; x<restoDoDicinario.length; x++){
          this.listaPesquisa.push({value:restoDoDicinario[x].value, viewValue:restoDoDicinario[x].viewValue, ngModel:restoDoDicinario[x].ngModel});
        }
      }


      console.log("this.listaPesquisa: ", this.listaPesquisa);

      //Caso não tenha parametros da dropdown selecionados
      if(this.listaPesquisa.length == 5){
        //esvazia array
        this.arrayPesquisaLimitado=[];
        //criacao de um array limitado quando mais de 5 elementos.
        for(var i=0; i<this.listaPesquisa.length; i++){
          this.arrayPesquisaLimitado.push({value:this.listaPesquisa[i].value, viewValue:this.listaPesquisa[i].viewValue});
        }

        console.log("VAI METER CAMPOS PERSONALIZADOS SELECIONADOS!!!!", this.arrayPesquisaLimitado);
        //Faz com que arrayPesquisaLimitado fique selecionado
        this.formControlObj = new FormControl(this.arrayPesquisaLimitado);

        //Msg a infomar que só pode escolher 5 campos personalizados
        this.apiService.showConfirmation('Campos personalizados excedidos', 'Não pode usar mais que 5 campos para pesquisa personalizada.', 'warning', '', 'OK', false);
        this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
          if(borrower == true){
            //sempre ncessario
            this.dialogSubscribe.unsubscribe();
            this.apiService.changeValue(null);
          }else if(borrower == false){
            //sempre ncessario
            this.dialogSubscribe.unsubscribe();
            this.apiService.changeValue(null);
          }
        });

      }else if(this.listaPesquisa.length == 0){
        this.pesquisaName="";
        this.pesquisaValue="empty";
      }else{
        //placeholder do campo pesquisa da tabela dinamico consoante dropdown
        this.pesquisaName='';
        var cont=0
        for(var i=0; i<this.listaPesquisa.length; i++){
          if(cont == 0){
            this.pesquisaName+=this.listaPesquisa[i];
          }else{
            this.pesquisaName+=','+this.listaPesquisa[i];
          }
          cont++;
        }
        this.pesquisaValue = value;
      }

      //Funcao que construi width dinamicamente dos inputs para pesquisa personalizada
      console.log("VAI FAZER DINAMICO: ", this.listaPesquisa.length);
      this.sizeDinamic(this.listaPesquisa.length);

      //tem defaul values por isso automaticamente preenche
      if(defaultValues != null){
        console.log("TEM DEFAULT VALUE!!!!", this.arrayPesquisaLimitado);
        this.formControlObj = new FormControl(this.arrayPesquisaLimitado);

      }
    }
  }

  applyFilter(level, ngModel=undefined, value=undefined){
    //variavel global do ultimo nivel
    this.nivelPesq=level;
    let filter = {}

    //quando se fazia backspace até ficar em branco o input não aplicava
    if(ngModel != undefined && ngModel != null){
      if(ngModel.length==0){
        this.filteredValues[value]="";
      }
    }

    if(level == 0){
      console.log("NIVEL 0");
      console.log("this.keywordSearch.trim().toLowerCase(): ", this.keywordSearch.trim().toLowerCase());
      console.log("this.dataSource: ", this.dataSource);
      this.dataSource.filter = "";
      this.dataSource.filter = this.keywordSearch.trim().toLowerCase();
    }else{
      console.log("NIVEL 1!!");
      for(var i = 0; i < this.listaPesquisa.length; i++) {
        if(this.listaPesquisa[i].ngModel){
          this.filteredValues[this.listaPesquisa[i].value] = this.listaPesquisa[i].ngModel.trim().toLowerCase();
        }
      }
      console.log("this.filteredValues: ", this.filteredValues);
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      this.customFilterPredicate();

    }
  }

  boolFinal;
  customFilterPredicate() {
    this.dataSource.filterPredicate = (data) => {
      this.boolFinal = new Boolean;
      Object.entries(this.filteredValues).forEach(
        ([key, value]) => {
          if(value){
            this.boolFinal = this.boolFinal && data[key].toString().toLowerCase().trim().indexOf(this.filteredValues[key].toLowerCase()) !== -1;
          }
        }
      );
      return this.boolFinal;

    }
    console.log("this.filteredValues: ", JSON.stringify(this.filteredValues));
    this.dataSource.filter = JSON.stringify(this.filteredValues);
  }

  limpaPesquisaMulti(nivel=null, value=null){
    if(nivel == 0 ){
      this.dataSource.filter = '';
      this.loadData();
    }else{
      this.filteredValues[value]="";
      this.applyFilter(1);
    }
  }
  //***************************************************************************************************************************************************************************************
  // FIM NOVA PESQUISA/DROPDOWN PESQUISA POR VARIOS CAMPOS--------------------------------------------------------------------------------------------------------------------------
  //***************************************************************************************************************************************************************************************


}
