import { Component, OnInit, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { HttpClientModule, HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
//Dialog
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';
//Service
import { APIService } from '../../service/api.service';
import { LoaderService } from '../../loader/loader.service';
//Component
import { PasswordComponent } from '../sessao/password/password.component';
import { TabelaComponentRouting } from '../../routing/app-routing.module';
import { InfoComponent } from '../../component/info/info.component';
import { DetailsComponent } from '../details/details.component';
// Router
import { Router } from '@angular/router';
import { DetailstepperComponent } from '../detailstepper/details.component';

import { TabelaComponent } from '../tabelas/tabela/tabela.component';

import { AppComponent } from '../../app.component';

import { Subscription } from 'rxjs';


@Component({
  selector: 'navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})

export class NavbarComponent implements OnInit {
  navbarOpen = false;

  boolEstado = false;
  //Recebe array do RestAPI com boolean e msg
  result: any;
  brand: string;
  cont:number;
  navBarUrl:string;
  navBarDefArray=[];
  navBarArray=[];
  navBarArrayDropdown=[];
  name:string;
  rootUrl:string;

  dataRefresher: any;

  array=[];
  data: any

  cloneDiv:Node;

  dialogSubscribe: Subscription;

  // elementReference = <HTMLElement> document.getElementById("myDiv");

  toggleNavbar(estado:any) {
    if(estado){
      this.navbarOpen = false;
    }else{
      this.navbarOpen = !this.navbarOpen;
    }
  }



  //constructor(public dialog: MatDialog, private apiService: APIService, private router: Router, private httpClient: HttpClient, private loader:LoaderService, private tblComponent: TabelaComponent) {
  constructor(public dialog: MatDialog, private apiService: APIService, private router: Router, private httpClient: HttpClient, private loader:LoaderService, private tblComponent: TabelaComponent) {
    //para entrar em Admin
    this.cont = 0;
    //Para navbar dinamica
    this.navBarUrl = this.apiService.getNavBar();

    //necessario por causa do logout tirar a navbar(chama aqui e no login, 2 chamadas)
    this.loadDataNavBar();

    this.name = this.apiService.getName();
    this.brand = this.apiService.getBrandName();
    //Caminho da api que vem do servico
    this.rootUrl = this.apiService.getRestServer();
  }

  ngOnInit() {
  }

  ngAfterViewInit() {
  }

  loadDataNavBar() {

    if(this.apiService.getToken()){
      //console.log("ESTOU NO CONFIG NAVBAR!!!!!!!!!!");
      this.httpClient.get(this.navBarUrl+'?token='+this.apiService.getToken()).subscribe(
      //this.apiService.getData(this.navBarUrl+'?token='+this.apiService.getToken()).subscribe(
        data => {
          for(const i of Object.keys(data)){
            //condicao para ir apenas e só para o array os campos escolhidos na BD (0 = mostrar, 1 = não mostrar)
            if(data[i].tipo_formulario == 0){
              this.navBarArray.push(data[i]);
            }
            if(data[i].tipo_formulario == 50){
              this.navBarArrayDropdown.push(data[i]);
            }
            if(data[i].tipo_formulario == 51){
              this.navBarArrayDropdown.push(data[i])
            }

            //tipo_formulario -> 8 é definicoes empresa, 9 é definicoes gerais
            if(data[i].tipo_formulario == 8 || data[i].tipo_formulario == 9){
              this.navBarDefArray.push(data[i]);
            }

            //console.log("navBarArray",this.navBarArray);
            //console.log("OLHAA: ", this.navBarDefArray);

            //condicao para inserir routes semi-dinamico consoante componente que vem da BD HARDCODED
            //ATENCAO: não aparece o 51? é porque esta HARDCODED no html para não repetir do tipo steps
            switch (data[i].componente_angular) {
              case 'TabelaComponentRouting':
                this.router.config.unshift({path: data[i].angular_path, component: TabelaComponentRouting});
                break;
              case 'InfoComponent':
                this.router.config.unshift({path: data[i].angular_path, component: InfoComponent});
                break;
              default:
                break;
            }
          }
          //console.log("ROUTER:  ", this.router);
          //Navega para index
          this.router.navigate(['/index']);
        }, erro => {
           console.log(erro);
           //this.apiService.showError("ANERR0016");
        }
      );
    }

  }

  setComponentName(name:any){
    this.apiService.setComponent(name);
  }

  setFormID(id:any){
    this.apiService.setIDComponente(id);
  }

  encerrar(val:any){
    if(val == 1){
      this.apiService.showConfirmation("Terminar sessão",this.name+", pretende terminar a sua sessão?", "question", "Não", "Sim");
      this.dialogSubscribe = this.apiService.borrowerChanged.subscribe((val) => {
        if(val == true){
          //Naveva para login
          this.router.navigate(['/login']);

          //sempre necessario
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        } else if (val == false){

          //sempre necessario para limpar
          this.dialogSubscribe.unsubscribe();
          this.apiService.changeValue(null);
        }
      });
      val = 0;
    }else{
      console.log("TU NÃO ENTRAS");
    }

  }

  password(){
    const dialogRef = this.dialog.open(PasswordComponent, {
        width: 'auto',
        height: 'auto',
        disableClose: false,
    });
    // Quando fecha dialog chama load para atualizar
    dialogRef.afterClosed().subscribe(() => {
    });
    //this.apiService.passwordPrompt('Alterar password');
  }

  //Passagem secreta para admin
  admin(){
    this.cont = this.cont+1;
    if(this.cont == 10){
      this.cont = 0;
      this.router.navigate(['/admin']);
    }
  }

  //Row select da tabela
  vaiDialog(seletor:any, id_formulario:any, uri_consultar:any, ondeVou:any, uri_gravar:any, uri_gravar_secundario:any, idfilho:any){
    //mostra barra de progresso
    this.loader.show();
    this.httpClient.get(this.rootUrl+seletor+'?token='+this.apiService.getToken()+'&form_id='+id_formulario).subscribe(
      res => {
        //tirar barra de progresso
        this.loader.hide();
        //logica consoante vem true ou false (vai para DetailstepperComponent OU DetailsComponent)

        //HARDCODED PARA NÃO DAR ERRO DE STEPS
        // if(res.hasOwnProperty("steps") ){
        //   console.log("tem steps");
        // }else{
        //   var obj = {"steps" : "null"};
        //   res = Object.assign(res, obj);
        // }
        // console.log(res);
        // if(res[0].tipo_formulario == 8){
        //   if (res[0].angular_path){
        //     console.log("tem path angular");
        //     this.router.navigate(['/'+res[0].angular_path]);
        //   }
        // }

        console.log(res);



        if (res[0].steps != "null") {
          const dialogRef = this.dialog.open(DetailstepperComponent, {
            width: '80%',
            height: '80%',
            autoFocus: false,
            disableClose: true,
            data: {
              //Array normal
              array: res,
              //Para verificar como proceder em details HARDCODED
              destino:'NOVO',
              //Para saber se navega para novo component ou mantem no mesmo HARCODED
              ondeVou: 'null',
              //
              id_formulario: id_formulario
            }
          });
          // Quando fecha dialog chama load para atualizar
          dialogRef.afterClosed().subscribe(() => {
            console.log("MAS ESTOU AQUI?");
            //Conficao para verificar local storage
            if(localStorage.getItem("dialog") == "1"){
              //chama esta funcao caso utilizador escolher continuar a inserir no dialog
              this.tblComponent.processData(null, uri_consultar, idfilho, true, ondeVou, uri_gravar, uri_gravar_secundario);
            }else{
              localStorage.setItem("dialog", "0");
            }

            //HARDCODED
            if (this.router.url === '/requisicoes'){
              //this.tblComponent.loadData(idfilho);
              //Faz click no refresh (UNICA FORMA QUE ENCONTREIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!)
              //this.tblComponent.triggerFalseClick();
            }

          });
          //ALTEREI 08/04/2019 IH, estava sempre a dar erro de steps undefined
        }else if (res[0].steps == "null" || res[0].steps == undefined){
          console.log("Estou aqui neste e vou para ali");
          const dialogRef = this.dialog.open(DetailsComponent, {
            width: '80%',
            height: '80%',
            autoFocus: false,
            disableClose: true,
            data: {
              //Array normal
              array: res,
              //Para verificar como proceder em details HARDCODED
              destino:'NOVO',
              //Para saber se navega para novo component ou mantem no mesmo HARCODED
              ondeVou: 'null',
              //
              id_formulario: id_formulario
            }
          });
        // Quando fecha dialog chama load para atualizar
        dialogRef.afterClosed().subscribe(() => {
        });
      }
    },
    erro => {
      console.log(erro);
      this.loader.hide();
      this.apiService.showError("ANERR0012");
    }
  );
  }
}
