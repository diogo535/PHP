import { Component, Inject, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { Router,RouterEvent, NavigationStart } from '@angular/router';
import { MatStepper } from '@angular/material';
//Service
import { APIService } from '../../service/api.service'
import { LoaderService } from '../../loader/loader.service';
import { SpinnerService } from '../../spinner/spinner.service';
//
import { Subscription } from 'rxjs';

import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})

//COMPONENTE RESPONSAVÉL POR MOSTRAR/CRIAR - DIALOG
export class DetailstepperComponent implements OnInit {

  opcoesForm: FormGroup;

  ficheiro:File;

  //Root que vem do API SERVICE GLOBAL
  rootUrl:string;

  //Array que recebe dos dialog-open nos componentes
  dados:any;

  //
  local:string = null;

  //Variavel global para criacao de dynamicFields definidos no HTML
  dFAPI=[];
  dFASI=[];
  dFAPV=[];
  dFASV=[];
  dynamicFieldsArraySteps=[];

  selectedDefault="";


  listaobjPrimarioVer=[];
  listaobjSecundarioVer=[];
  listaobjPrincipalInserir=[];
  listaobjSecundarioInserir=[];

  controlo00=0;

  //Body para metodos POST
  body = new HttpParams();

  //Recebe array do RestAPI com boolean e msg
  result: any;

  //Para saber se abre dialog DETALHES ou component INFO
  ondeVouBool: boolean;

  //Arrays reponsaveis pelo display dinamico no HTML
  arrayPricipal = [];
  arraySecundario = [];
  listaClientesDropdown = [];
  optionField=[];
  dropFilhaArray=[];
  seasons: string[] = ['hard', 'coded', 'no', 'ts'];
  uri_gravar="";
  uri_gravar_secundario="";
  id_formulario="";

  array=[];

  destino="";

  element: HTMLElement;
  //Altera vista nos componente HTML
  bool_estado:number = 0;
  bool_alterado:boolean = true;

  isLinear=false;
  button1=true;
  stepantigo: number= -1;

  routerSubscription: Subscription;

  dialogSubscribe: Subscription;

  prefixoSOAP:string;
  //Se der erro meter a true ou false, angular 7 necessariio
  @ViewChild("stepper", { static: false }) stepper: MatStepper;
  //@ViewChild('stepper') private stepper: MatStepper;

  boolBtn25:boolean;


  //Mete data de hoje
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());

  //maximo de step
  maxSteps: number= 0;
  //numero real de steps
  steps: number = 0;

  //mostra mostraCCF
  mostraCCF: boolean = false;






  constructor(private cdRef:ChangeDetectorRef, private spinner:SpinnerService, private loader:LoaderService, private apiService: APIService, public dialogRef: MatDialogRef<DetailstepperComponent>, @Inject(MAT_DIALOG_DATA) public data: any, private http: HttpClient, public dialog: MatDialog, private router: Router) {
    //Caminho da api que vem do servico
    this.rootUrl = this.apiService.getRestServer();
    //Passa para Array criado globalmente DADOS DA ROW que vem do componente carregado
    this.dados = data;

    //Logica para controlar atribuição de variaveis ARRAY QUE VEM NO PEDIDO TEM PRIORIDADE

    this.destino = data.array[0].destino;
    console.log("destino - data.array: ", this.destino);
    if(this.destino == undefined){
      this.destino = this.dados.destino;
      console.log("destino - this.dados: ", this.destino);
    }

    //id_formulario vem do formulario e form_id vem dos pedidos a API
    this.id_formulario = data.array[0].form_id;
    console.log("id_formulario - data.array: ", this.id_formulario);
    if(this.id_formulario == undefined){
      this.id_formulario = this.dados.id_formulario;
      console.log("id_formulario - this.dados: ", this.id_formulario);
    }

    this.uri_gravar = data.array[0].uri_gravar;
    console.log("uri_gravar - data.array: ", this.uri_gravar);
    if(this.uri_gravar == undefined){
      this.uri_gravar = this.dados.uri_gravar;
      console.log("uri_gravar - this.dados: ", this.uri_gravar);
    }

    this.uri_gravar_secundario = data.array[0].uri_gravar_secundario;
    console.log("uri_gravar_secundario - data.array: ", this.uri_gravar_secundario);
    if(this.uri_gravar_secundario == undefined){
      this.uri_gravar_secundario = this.dados.uri_gravar_secundario;
      console.log("uri_gravar_secundario - this.dados: ", this.uri_gravar_secundario);
    }

    this.array = data.array;
    console.log("array: ", this.array);

    //ternario para verificar se pesquisa foi inserida no seletor da tabela
    console.log("data.ondeVou no DETAILS: ", data.ondeVou);
    if(data.ondeVou == 'null'){
      console.log("com plicas");
    }
    if(data.ondeVou == null){
      console.log("sem plicas");
    }
   data.ondeVou == 'null' || data.ondeVou == null ? this.ondeVouBool = false : this.ondeVouBool = true;
    console.log("ONDE VOU: ", this.ondeVouBool);

    //Funcão que verifica o que vem do componente (Se é para visualizar 'VER' ou para criar 'NOVO')
    this.MeteDados();

  } //FIM CONSTRUCTOR


  //Necessario pois quando sessao expirava por inatividade navegava para login mas dialog continuava aberto, assim fecha.
  ngOnInit() {
    //console.log("ESTOU NA NOVA LOGICA!!");
   this.routerSubscription = this.router.events.pipe(
       filter((event: RouterEvent) => event instanceof NavigationStart),
       filter(() => !!this.dialogRef)
     )
     .subscribe(() => {
       //console.log("QUER DIZER QUE VOU FECHAR!!!!");
       this.dialogRef.close();
     });

   }

   ngAfterViewInit(){
     //focus do primeiro input
     var elementReference = <HTMLInputElement> document.getElementById("ipt0");
     elementReference.focus();
     //para previnir erro de mudança de elemento
     this.cdRef.detectChanges();
   }

//--------------------------- INICIO UPLOAD IMAGEM em FASE DE DESENVOLVIMENTO
   // selectedFile: File;
   // onFileChanged(event) {
   //   this.selectedFile = event.target.files[0]
   // }
   //
   // onUpload() {
   //   // POST
   // }
//--------------------------- FIM UPLOAD IMAGEM em FASE DE DESENVOLVIMENTO



//--------------------------- INICO FUNCOES DE PREENCHIMENTO AUTOMATICOS DE INPUT ---------------------------
    inputsTipo24_25=[]

    calculaUri2Send(arraySplit,bdid){
      console.log("DEPOIS DE INSERIR this.listaobjPrincipalInserir: ", this.listaobjPrincipalInserir);

      var uri2Send="";
      var value="";
      var nivel=1;
      var ids="";

      for(var y=2;y<arraySplit.length;y++){
      console.log("arraysplit - ",y," - ", arraySplit[y], " - ", arraySplit[y].substring(0,1));
        if(arraySplit[y].substring(0,1) == 'P'){ // se estamos nas linhas e precisamos de um valor do cabeçalho, precisamos do primariover
          for(var i=0; i < this.listaobjPrimarioVer.length; i++){
            console.log("no PriVer - ",i,this.listaobjPrimarioVer[i].dbid);
            if(this.listaobjPrimarioVer[i].dbid == arraySplit[y].substring(1)){
              value = arraySplit[y].substring(1) + "=" + this.listaobjPrimarioVer[i].value;
              console.log("entrou no if do PriVer",value);
              break;
            }
          }
        } else if( arraySplit[y].substring(0,1) == 'S'){ // no caso de estarmos a trabalhar no secundário, nas linhas, os campos com S vem do que estamos a  inserir
          nivel=2;
          for(var i=0; i < this.listaobjSecundarioInserir.length; i++){
            console.log("no SecIns - ",i,this.listaobjSecundarioInserir[i].dbid);
            if(this.listaobjSecundarioInserir[i].dbid == arraySplit[y].substring(1)){
              value = arraySplit[y].substring(1)  + "=" + this.listaobjSecundarioInserir[i].value;
              console.log("entrou no if do SecIns",value);
              break;
            }
          }
        } else {  // no caso de estarmos a inserir cabeçalhos, temos o principal inserir. da basededados vem o campo sem P ou S
          console.log("Entrou no else. destino=",this.destino );
          var arraylocal=[];
            if (this.destino == 'VER'){
                arraylocal=this.listaobjPrimarioVer.slice();
            }else{
                arraylocal=this.listaobjPrincipalInserir.slice();
            }
            console.log("o arraylocal: ",arraylocal);
          for(var i=0; i <arraylocal.length ; i++){
            if( arraylocal[i].dbid == arraySplit[y]){
              //TIRA U no inicio do codigo local prescricao
              console.log("arraySplit[y]: ", arraySplit[y]);
              value = arraySplit[y] + "=" + arraylocal[i].value.substring(1);
              console.log("TEM QUE VIR AQUI!!!", arraylocal[i].value);
            }
          }

        }
        uri2Send+="&"+value;
      }
      console.log("Uri antes do ids=",uri2Send);
        ids="&id_form="+this.id_formulario+"&id_field="+bdid+"&nivel="+nivel;
        console.log("depois dos ids",ids);
      uri2Send= ids + uri2Send;
      console.log("Dentro do for",uri2Send);
        return uri2Send;
    }

    //funcao para forçar atualizar ngModel pois estamos a manipular os valores do input e não o ngModel
    updateNgModel($event, array, val){
      console.log("Vai atualizar NGMODEL!!!");
      array[val].value = $event;
    }

    vaieVem(val, bdid, nivel, nomeArray, on=null, bdid2, value2){
      console.log("------- listaobjPrimarioVer[in].value -----------", this.listaobjPrincipalInserir[val].value);
      console.log("BDID::::", bdid);
      //var num = val+2;
      var inputPai = <HTMLInputElement> document.getElementById("ipt"+val);
      if(inputPai == null){
        var inputPai = <HTMLInputElement> document.getElementById("inpt"+val);
      }
      console.log("inputPai.value: ", inputPai.value);
      console.log("inputPai ipt", val);

      //var arrayHash = "codigoMCDT#3#Ss1#Pid1";
      var arrayHash = "";

      if(nivel==1){

        console.log("this.destino: ", this.destino);
          if(this.destino == 'NOVO'){
            arrayHash = this.dFAPI[0][val][7];
          }else{
            arrayHash = this.dFAPI[0][val-1][7];
          }
          console.log("arrayHash: ", arrayHash);


          //logica para consoante nivel fazer dinamicamente diferentes tipos de input
          var arraySplit = arrayHash.split("#");
          console.log("arraySplit", arraySplit);
          for(var x=1; x < parseInt(arraySplit[1]); x++){
            //this.inputsTipo24_25[x] = <HTMLInputElement> document.getElementById("ipt"+(val+x));
            this.inputsTipo24_25[x] = nomeArray[val+x];
          }
          console.log("this.inputsTipo24_25 no nivel1: ", this.inputsTipo24_25);
      }else if(nivel==2){
          arrayHash = this.dFASI[0][val][7];

          //logica para consoante nivel fazer dinamicamente diferentes tipos de input
          var arraySplit = arrayHash.split("#");
          console.log("arraySplit", arraySplit);
          for(var x=1; x < parseInt(arraySplit[1]); x++){
            //this.inputsTipo24_25[x] = <HTMLInputElement> document.getElementById("inpt"+(val+x));
            this.inputsTipo24_25[x] = nomeArray[val+x];
          }
          console.log("this.inputsTipo24_25 no nivel2: ", this.inputsTipo24_25);

      }

      console.log("arrayHash: ", arrayHash);




      var uri2Send="";

      console.log("arraySplit[0]: ", arraySplit[0])
      switch(arraySplit[0]) {
         case 'codigoMCDT': {
            var res = inputPai.value.substring(4,5);
            if((inputPai.value.length == 5 && res != ".") || (this.listaobjSecundarioInserir[0].value.length == 6)){
              uri2Send=this.calculaUri2Send(arraySplit,bdid);
              console.log("uri2Send: ", uri2Send);
              this.codigoPesquisa(uri2Send);
            }else{
              //Limpa campos caso não cumpra requisitos
              for(var x=1; x<this.inputsTipo24_25.length; x++){
                this.inputsTipo24_25[x].value = "";
              }
            }
            break;
         }
         case "lostFocus": {


         }
         case "codigoLocal": {
            console.log("ENTROU NO CASE!!!");
            if(inputPai.value){
              uri2Send=this.calculaUri2Send(arraySplit,bdid);
              console.log("uri2Send: ", uri2Send);
              this.codigoPesquisa(uri2Send);
              //this.codigoPesquisa(uri2Send, bdid2, value2, nivel);
            }else{
              console.log("ENTROU NO ELSE!!!");
              //Limpa campos caso não cumpra requisitos
              for(var x=1; x<this.inputsTipo24_25.length; x++){
                this.inputsTipo24_25[x].value = "";
              }
            }
            break;
         }
         default: {
            break;
         }
      }
    }

  // codigoPesquisa(uri2send:any, bdid2=null, value2=null, nivel=null){
   codigoPesquisa(uri2send:any){
     const headers = new HttpHeaders({});
     headers.append('Access-Control-Allow-Headers', 'Content-Type');
     headers.append('Access-Control-Allow-Methods', 'get');
     headers.append('Access-Control-Allow-Origin', '*');

     this.http.get(this.apiService.rootUrl+"tbt_pesquisa?token="+this.apiService.getToken()+uri2send, {headers: headers})
     //+this.listaobjSecundarioInserir[0].dbid+"="+this.listaobjSecundarioInserir[0].value+"&"+this.listaobjPrimarioVer[3].dbid+"="+this.listaobjPrimarioVer[3].value, {headers: headers})
     .subscribe(
       res => {

         this.result = res;
         console.log("this.result: ", this.result);

         if(this.result.status == "error"){
           this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer);
           this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
              if(borrower == true){
                //Limpa campos caso não cumpra requisitos
                for(var x=1; x<this.inputsTipo24_25.length; x++){
                  this.inputsTipo24_25[x].value = "";
                }

                //sempre ncessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
              }else if(borrower == false){
                //sempre ncessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
              }
            });
         }else if(this.result.status == "OK" || this.result.status == "ok" || this.result.status == "Ok"){
           console.log("Estou no OK!!!!!!!!!!!!!!!!");
           console.log("this.result.length: ", Object.keys(this.result).length);
           for(var x=1; x < Object.keys(this.result).length; x++){
             var nome = "mensagem"+x;
             if(this.result[nome]){
                this.inputsTipo24_25[x].value = this.result[nome];
             }
           }

           // fazer update dos 25
           // if(bdid2 != null && value2!= null && nivel != null){
           //   //faz update
           //   for(var x=1; x<this.inputsTipo24_25.length; x++){
           //     //this.inputsTipo24_25[x].value = "";
           //     this.updateField(this.inputsTipo24_25[x].dbid,this.inputsTipo24_25[x].value,bdid2,value2,nivel);
           //     // console.log("O QUE VAI MANDAR PARA O UPDATE: ",this.inputsTipo24_25[x].dbid," - ", this.inputsTipo24_25[x].value," - ", dbid2," - ", value2," - ", nivel);
           //   }
           //
           // }
         }

     },
     erro => {
       console.log(erro);
       this.apiService.showError("ANERR0019");
       this.dialogRef.close();
     });
   }

//--------------------------- FIM FUNCOES DE PREENCHIMENTO AUTOMATICOS DE INPUT ---------------------------



    // vaieVem(){
    //
    //   if(this.listaobjPrincipalInserir[12].value){
    //     this.codigoPesquisaEFR();
    //   }else{
    //     console.log("Não deu!!!");
    //     this.listaobjPrincipalInserir[13].value = "";
    //     this.listaobjPrincipalInserir[14].value = "";
    //   }
    // }
    //
    // codigoPesquisaEFR(){
    //
    //   const headers = new HttpHeaders({});
    //   headers.append('Access-Control-Allow-Headers', 'Content-Type');
    //   headers.append('Access-Control-Allow-Methods', 'get');
    //   headers.append('Access-Control-Allow-Origin', '*');
    //
    //   var res = this.listaobjPrincipalInserir[12].value.substring(1);
    //   this.http.get(this.apiService.rootUrl+"efr_pesquisa?token="+this.apiService.getToken()+"&"+this.listaobjPrincipalInserir[12].dbid+"="+res, {headers: headers})
    //   .subscribe(
    //     res => {
    //
    //       this.result = res;
    //       console.log("this.result: ", this.result);
    //
    //       if(this.result.status == "error"){
    //         this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer);
    //         this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
    //            if(borrower == true){
    //              this.listaobjPrincipalInserir[12].value = "";
    //              this.listaobjPrincipalInserir[13].value = "";
    //              this.listaobjPrincipalInserir[14].value = "";
    //              console.log("this.listaobjPrincipalInserir DEPOIS DE LIMPAR: ", this.listaobjPrincipalInserir);
    //              //sempre ncessario
    //              this.dialogSubscribe.unsubscribe();
    //              this.apiService.changeValue(null);
    //            }else if(borrower == false){
    //              //sempre ncessario
    //              this.dialogSubscribe.unsubscribe();
    //              this.apiService.changeValue(null);
    //            }
    //          });
    //       }else if(this.result.status == "OK" || this.result.status == "ok" || this.result.status == "Ok"){
    //         this.listaobjPrincipalInserir[13].value = this.result.mensagem;
    //         this.listaobjPrincipalInserir[14].value = this.result.mensagem2;
    //         console.log("this.listaobjPrincipalInserir DEPOIS DE INSERIR: ", this.listaobjPrincipalInserir);
    //       }
    //
    //   },
    //   erro => {
    //
    //     this.apiService.showError("ANERR0051");
    //     this.dialogRef.close();
    //   });
    // }

   move(index:number) {
     this.stepper.selectedIndex = index;
   }

   verTamanho(val:any){
     // console.log("this.listaobjPrincipalInserir: ",this.listaobjPrincipalInserir);
     var res = this.listaobjPrincipalInserir[0].value.substring(1, 3);
     if(res == "04" && this.listaobjPrincipalInserir[0].value.length == 19){
       this.controlo00=0;
       //Logica para entrar só 1x e não saltar logo PARA IR PARA DROPWOWN
       if(res == "04" && this.controlo00 != 1){
         this.controlo00=1;
         //incrementa 2 valores para ir diretamente para dropdown
         var num = val+2;
         var elementReference11 = <HTMLInputElement> document.getElementById("ipt"+num);
         elementReference11.focus();
       }

       if(this.listaobjPrincipalInserir[2].value != ""){
         //ativa botão PROXIMO
         this.button1= false;
         this.prefixoSOAP = "04";
       }else{
         //desativa botão PROXIMO
         this.button1= true;
       }

     } else if(this.listaobjPrincipalInserir[0].value.length < 19){
       //desativa botão PROXIMO
       this.button1= true;
     }

     if(this.listaobjPrincipalInserir[0].value.length == 19 && res == "00"){
       //Logica para entrar só 1x e não saltar logo
       if(res == "00" && this.controlo00 != 1){
         this.controlo00=1;
         var num = val+1;
         var elementReference11 = <HTMLInputElement> document.getElementById("ipt"+num);
         elementReference11.focus();
       }

       if(this.listaobjPrincipalInserir[1].value.length == 6){
         this.controlo00=0;
         if(this.listaobjPrincipalInserir[2].value != ""){
           this.controlo00=1;
           //ativa botão PROXIMO
           this.button1= false;
           this.prefixoSOAP = "00";
         }else if(res == "00" && this.controlo00 != 1){
           this.controlo00=1;
           var num = val+1;
           var elementReference11 = <HTMLInputElement> document.getElementById("ipt"+num);
           elementReference11.focus();
         }else{
           //desativa botão PROXIMO
           this.button1= true;
         }

       } else if(this.listaobjPrincipalInserir[1].value.length < 6){
         //desativa botão PROXIMO
         this.button1= true;
       }

     } else if(this.listaobjPrincipalInserir[0].value.length < 19){
       //desativa botão PROXIMO
       this.button1= true;
       //repoe estado para voltar a fazer focus na 2 ou mais tentativa
       this.controlo00=0;
     }

   }


   //iso7064mod112 IH validação de requesicoes
   encode(_code) {
      var code = _code;
      var c = this.computeCheck(code);
      if (c == 10) {
        return code + "X";
      } else {
        return code + c;
      }
    }
    computeCheck(str) {
      var p:number = 0;
      for (var i= 0; i < str.length; i++) {
        var c = parseInt(str[i]); //convert str em int
        p = 2 * (p + c);
      }
      p %= 11;
      return (12 - p) % 11;
    }


   vaiPara(){ //expecifico MCDT
     //
     console.log("VAI VALIDAR SE É VALIDA!!!");
      for (var i = 0; i < this.listaobjPrincipalInserir.length; i++) {
        if (this.listaobjPrincipalInserir[i].dbid=="s1"){
          var num_req = this.listaobjPrincipalInserir[i].value.toUpperCase();
        }
      }

      console.log("num_req: ", num_req);

       if (this.encode(num_req.slice(0,-1)) != num_req) { //retira ultimo digito do num red . Se valor != está mal inserido
         this.stepper.previous(); //recua steps para corrigir num req
         this.apiService.showConfirmation("Requisição Inválida!", "Número de requisição errado. Valide o número de requisição inserido.", "warning", "Cancelar", "Ok", false);
       }else{
         //SE É x00 E TEM CODIGO VERIFICACAO, PEDE DADOS PHP E MOSTRA SPINNER
         switch(this.prefixoSOAP){
           case "04":
             this.bdnrPesquisa();
             break;
           case "00":
             this.bdnrPesquisa();
             break;
           default:
             break;
          }
       }


     }



   //Funcao para permitir apenas inserção de numeros no input (INPUT TYPE NUMBER NÂO PERMITE maxlength)
   isNumberKey(event: KeyboardEvent){
     var charCode = (event.which) ? event.which : event.keyCode
     if (charCode > 31 && (charCode < 48 || charCode > 57) || (charCode >= 96 && charCode <= 105))
       return false;
     return true;
   }





  bdnrPesquisa(){
    const headers = new HttpHeaders({});
    headers.append('Access-Control-Allow-Headers', 'Content-Type');
    headers.append('Access-Control-Allow-Methods', 'get');
    headers.append('Access-Control-Allow-Origin', '*');

    //chama spinner e injeta frase que queros mostrar
    this.spinner.show("Aguarde, estamos a contactar a BDNR....");

    this.http.get(this.apiService.rootUrl+"bdnr_pesquisa?token="+this.apiService.getToken()+"&"+this.listaobjPrincipalInserir[0].dbid+"="+this.listaobjPrincipalInserir[0].value+"&"+this.listaobjPrincipalInserir[1].dbid+"="+this.listaobjPrincipalInserir[1].value, {headers: headers})
    .subscribe(
      res => {
        this.spinner.hide();
        this.result = res;

        if(this.result.status){

          if(this.result.status == "error"){
            this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer);
            this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
              if(borrower == true){
                  //sempre ncessario
                  this.dialogSubscribe.unsubscribe();
                  this.apiService.changeValue(null);
              }
            });

            localStorage.setItem("dialog", "0");
            this.dialogRef.close();
          }else{

              //esconde steps pois vem o novoID
             if(this.result.novoID){
              (<HTMLElement>document.querySelector('mat-dialog-container')).style.display = 'none';
             }

            this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer);
            this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
              if(borrower == true){

                if(this.result.novoID){
                  localStorage.setItem("pedido_id", this.result.novoID);

                  //sempre ncessario
                  this.dialogSubscribe.unsubscribe();
                  this.apiService.changeValue(null);

                  if(this.result.tipodestinoOk == "bdnr_efetiva"){
                    this.apiService.showInputs(this.result.titulodestinoOk, this.result.destinoOk);
                    this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
                      if(borrower == true){
                        console.log("dentro deste!!!");
                        localStorage.setItem("dialog", "0");
                        this.dialogRef.close();

                        //sempre ncessario
                        this.dialogSubscribe.unsubscribe();
                        this.apiService.changeValue(null);
                      }else if(borrower == false){
                        console.log("MAS ESTOU AQUI??");
                        localStorage.setItem("dialog", "0");
                        this.dialogRef.close();

                        //sempre ncessario
                        this.dialogSubscribe.unsubscribe();
                        this.apiService.changeValue(null);
                      }
                    });
                  }else{
                    //this.apiService.showError("ANERR0050");
                    localStorage.setItem("pedido_id", this.result.novoID);
                    localStorage.setItem("dialog", "1");
                    this.dialogRef.close();
                  }
                }else{
                  console.log("MAS ESTOU AQUI??");
                  //sempre ncessario
                  this.dialogSubscribe.unsubscribe();
                  this.apiService.changeValue(null);
                }



              }else if(borrower == false){
                if(this.result.tipodestinoCancelar == "fecha_api_nowait"){
                  console.log("vai fechar fecha_api_nowait");
                  this.http.get(this.apiService.rootUrl+this.result.destinoCancelar+"&token="+this.apiService.getToken()).subscribe();
                  //console.log(this.apiService.rootUrl+this.result.destinoCancelar+"&"+this.apiService.getToken());
                }
                console.log("vai fechar normal");
                localStorage.setItem("dialog", "0");
                this.dialogRef.close();
                //sempre ncessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
              }
            });
          }
        }
    },
    erro => {
      console.log(erro);
      this.spinner.hide();
      this.apiService.showError("ANERR0005");
      this.dialogRef.close();
    });
  }

  novostepantigo(value:any){
    //console.log("Vamos la ver este valor: ", value);
    this.stepantigo=value;
  }

  getDropFilha(id:any, idFunc:any) {

    this.dropFilhaArray = [];

    const headers = new HttpHeaders({});
    headers.append('Access-Control-Allow-Headers', 'Content-Type');
    headers.append('Access-Control-Allow-Methods', 'POST');
    headers.append('Access-Control-Allow-Origin', '*');

    ////console.log(this.apiService.rootUrl+"getDropFilha?id="+id+"&idlinha="+idFunc+"&token="+this.apiService.getToken());
    this.http.get(this.apiService.rootUrl+"getDropFilha?id="+id+"&idlinha="+idFunc+"&token="+this.apiService.getToken(), {headers: headers})
    .subscribe(
      res => {

        var str = res.toString();
        str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
        var array = JSON.parse("[" + str + "]");
        this.dropFilhaArray.push(array);

      },
      erro => {
        console.log(erro);
        this.apiService.showError("ANERR0002");
        this.dialogRef.close();
    });
  }


//------------------------------------------------------------------------------------------- INICIO Função que esta no constructor responsavel por inserir data quando dialog é aberto
  MeteDados(){
    if(this.destino == 'NOVO'){
      this.loader.hide();
      //var cont = 0;

      var str = this.data.array[0].dFAPI.split(';').toString();
      str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
      var array = JSON.parse("[" + str + "]");
      this.dFAPI.push(array);
      console.log("dFAPI NO DETAILS: ",this.dFAPI[0]);

      //HARDCODED - se tiver mais que 1 area de convenção mete sempre a que vem no [0]
      // this.selectedDefault = this.dFAPI[0][2][6][0].nome;
      // console.log("ISTO TEM QUE SER O DEFAULT DA DROPDOWN: ", this.selectedDefault);


      //nome STEPS
      var str = this.data.array[0].steps.split(';').toString();
      str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
      var array = JSON.parse("[" + str + "]");
      this.dynamicFieldsArraySteps.push(array);
      //console.log("dynamicFieldsArraySteps NO DETAILS: ",this.dynamicFieldsArraySteps[0]);

      //variavel para saber numero maximo de steps
      this.steps = this.dynamicFieldsArraySteps[0].length;
      this.steps--; //arrays começam no 0!!!!!!





      //Arranja dados para construir array
      var str = this.data.array[0].dFASI.split(';').toString();
      str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
      var array = JSON.parse("[" + str + "]");
      this.dFASI.push(array);
      console.log("dFASI NO DETAILS: ",this.dFASI[0]);

      if(this.dFAPI[0].length > 0){ //se existe dados
        for(var i=0; i<this.dFAPI[0].length; i++){

          if(this.dFAPI[0][i][9] > this.steps){
            this.maxSteps = this.dFAPI[0][i][9];
          }

          //saber se é CCF. Se tiver numero maior que steps significa que é CCF
          if(this.dFAPI[0][i][9] > this.steps){
            this.mostraCCF = true;
          }else{
            this.mostraCCF = false;
          }

          if(this.dFAPI[0][i][4] == 8){ //converte para INT
            var stringToInt = +this.dFAPI[0][i][0];
            this.listaobjPrincipalInserir.push({ title: this.dFAPI[0][i][2], dbid: this.dFAPI[0][i][1], value: stringToInt});
          }else{ //insere normalmente
            this.listaobjPrincipalInserir.push({ title: this.dFAPI[0][i][2], dbid: this.dFAPI[0][i][1], value: this.dFAPI[0][i][0]});

            //NAO FUNCIONA NO MCDT, FUNCIONA NO PMEDICINES
            // if(this.dFAPI[0][i][4] == 25){ //HARDCODED - para quando tiver campo 25 tem botão com pedido
            //   this.boolBtn25 = true; //funcao vaiPara()
            // }else{
            //   this.boolBtn25 = false; //matStepperNext
            // }

            //FUNCIONA NO MCDT, NAO FUNCIONA NO PMEDICINES
            console.log("O QUE É O 25: ", this.dFAPI[0][i][4]);
            if(this.dFAPI[0][i][4] != 25){
              //console.log("NAO TEM 25!!!!!!!!");
              this.boolBtn25 = false; //matStepperNext
            }else{
              this.boolBtn25 = true; //funcao vaiPara()
            }

          }
        }
      }
      console.log("this.listaobjPrimarioInserir FINAL: ", this.listaobjPrincipalInserir);

      if(this.dFASI[0][0] != null){
        for(var i=0; i<this.dFASI[0].length; i++){
          this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: this.dFASI[0][i][0]});
        }
      }
      console.log("this.listaobjSecundarioInserir FINAL: ", this.listaobjSecundarioInserir);






      if(this.array[0].form_id != null){
        //console.log();
        this.id_formulario = this.array[0].form_id;
      }

    }

    // if(this.destino == 'VER'){
    //   //Entra no VER
    //   ////console.log("dFASI: ", this.dFASI);
    //   ////console.log("this.dados.dataTitleSecundario: ", this.dados.dataTitleSecundario);
    //   //Se for falso nao navega para novo componente
    //   if(this.ondeVouBool == false){
    //     if(this.data.array[0].dFAPV != null){
    //       //dFAPV
    //
    //       var str = this.data.array[0].dFAPV.split(';').toString();
    //
    //       var array = JSON.parse("[" + str + "]");
    //       this.dFAPV.push(array);
    //       //console.log("dFAPV NO DETAILS: ",this.dFAPV[0]);
    //       //listaobjPrimarioVer
    //       for(var i=0; i<this.dFAPV[0].length; i++){
    //         this.listaobjPrimarioVer.push({ title: this.dFAPV[0][i][2], dbid: this.dFAPV[0][i][1], value: this.dFAPV[0][i][0]});
    //       }
    //       console.log("this.listaobjPrimarioVer FINAL: ", this.listaobjPrimarioVer);
    //     }
    //     if(this.data.array[0].dFASV != null){
    //       //dFASV
    //       var str = this.data.array[0].dFASV.split(';').toString();
    //       var array = JSON.parse("[" + str + "]");
    //       this.dFASV.push(array);
    //       //console.log("dFASV NO DETAILS: ",this.dFASV[0][0]);
    //
    //       //listaobjSecundarioVer
    //       for(var i=0; i<this.dFASV[0][0].length; i++){
    //         var listaobjteste1=[];
    //         listaobjteste1.length = 0;
    //         for(var o=0; o<this.dFASV[0][0][i].length; o++){
    //           listaobjteste1.push({ title: this.dFASV[0][0][i][o][2], dbid: this.dFASV[0][0][i][o][1], value: this.dFASV[0][0][i][o][0]});
    //         }
    //         this.listaobjSecundarioVer.push(listaobjteste1);
    //
    //       }
    //       console.log("this.listaobjSecundarioVer FINAL: ", this.listaobjSecundarioVer);
    //     }
    //
    //     //console.log("this.data.array[0].dFASI: ", this.data.array[0].dFASI);
    //     if(this.data.array[0].dFASI != null){
    //       //dFASI
    //       var str = this.data.array[0].dFASI.split(';').toString();
    //       var array = JSON.parse("[" + str + "]");
    //       this.dFASI.push(array);
    //       //console.log("dFASI NO DETAILS: ",this.dFASI[0]);
    //
    //       //listaobjSecundarioInserir
    //       for(var i=0; i<this.dFASI[0].length; i++){
    //         if (this.dFASI[0][i][0]=="99_IDP"){
    //           this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: this.dados.ID});
    //         }else if(this.dFASI[0][i][4]==8){
    //           var stringToInt = +this.dFASI[0][i][0];
    //           //console.log("ATENCAO QUE ESTE TEM STRING E VAI PARA INT:::::: ", stringToInt);
    //           this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: stringToInt});
    //         }else{
    //           this.listaobjSecundarioInserir.push({ title: this.dFASI[0][i][2], dbid: this.dFASI[0][i][1], value: this.dFASI[0][i][0]});
    //         }
    //
    //       }
    //       console.log("this.listaobjSecundarioInserir FINAL: ", this.listaobjSecundarioInserir);
    //     }
    //
    //
    //     if(this.array[0].form_id != null){
    //       this.id_formulario = this.array[0].form_id;
    //     }
    //
    //
    //
    //   }else{
    //     //Se for true navega para caminho definido em seletor
    //     this.router.navigateByUrl(this.dados.ondeVou);
    //     //fecha este dialogRef
    //     this.dialogRef.close();
    //   }
    // }
  }

//------------------------------------------------------------------------------------------- FIM Função que esta no constructor responsavel por inserir data quando dialog é aberto
  inserirComentario(){
    //console.log(this.array[0].uri_gravar_secundario);
    this.body = new HttpParams();
		for (var i = 0; i < this.listaobjSecundarioInserir.length; i++) {
			this.body = this.body.append(this.listaobjSecundarioInserir[i].dbid, this.listaobjSecundarioInserir[i].value);
		};
    //console.log(this.body.toString());
    var path = this.rootUrl+this.array[0].uri_gravar_secundario+'?token='+this.apiService.getToken()+'&'+this.body.toString()+'&pedido_id='+this.dados.ID+'&nvl=2';
    this.getPOST(path);
  }

  inserirNovo(){

    console.log("ATENCAO: ", this.listaobjPrincipalInserir);
    console.log("this.array[0]: ", this.array[0]);

    //HARDCODED - nao pode ativar porque algumas não teem este campo obrigatorio
    // if(this.listaobjSecundarioInserir[13].value == "" || this.listaobjSecundarioInserir[14].value == "" || this.listaobjSecundarioInserir[2].value == ""){
    //   this.apiService.showConfirmation("Alerta","Campos vazio. Insira valor corretos!","warning", "","OK",false);
    //   this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
    //     if(borrower == true){
    //       //sempre ncessario
    //       this.dialogSubscribe.unsubscribe();
    //       this.apiService.changeValue(null);
    //     }else if(borrower == false){
    //       //sempre ncessario
    //       this.dialogSubscribe.unsubscribe();
    //       this.apiService.changeValue(null);
    //     }
    //   });
    // }
    this.body = new HttpParams();
		for (var i = 0; i < this.listaobjPrincipalInserir.length; i++) {
			this.body = this.body.append(this.listaobjPrincipalInserir[i].dbid, this.listaobjPrincipalInserir[i].value);
		};
    //var path = this.rootUrl+this.array[0].uri_gravar+'?token='+this.apiService.getToken()+'&criador_id='+this.apiService.getUserID()+'&'+this.body.toString()+'&nvl=1';

    var path = this.rootUrl+this.array[0].uri_gravar+'?token='+this.apiService.getToken()+'&'+this.body.toString()+'&nvl=1';
    console.log("PATH: ", path)
    this.getPOST(path);
  }

  fechar(){
    localStorage.setItem("dialog", "0");
  }

  getPOST(path:any){
    const headers = new HttpHeaders({});
    headers.append('Access-Control-Allow-Headers', 'Origin, Content-Type, X-Auth-Token');
    headers.append('Access-Control-Allow-Methods', 'POST');
    var path_final = path;

    return this.http.post(path_final+'&form_id='+this.id_formulario, { headers: headers })
    .subscribe(data =>
      {
        this.result = data;
        //console.log("Result: ",this.result);

        if(this.result.status){
          this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer);
          this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
            if(borrower == true){
                console.log("ESTOU NO TRUE");
                //console.log("ok");
                localStorage.setItem("pedido_id", this.result.novoID);
                localStorage.setItem("dialog", "1");
                this.dialogRef.close();
                //sempre ncessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
            }else if(borrower == false){
              console.log("ESTOU NO FALSE");
                //console.log("não ok");
                localStorage.setItem("dialog", "0");
                this.dialogRef.close();
                //sempre ncessario
                this.dialogSubscribe.unsubscribe();
                this.apiService.changeValue(null);
            }
          });
        }

      },
      erro => {
        console.log(erro);
        this.apiService.showError("ANERR0009");
      });
  }
}
