//Base
import { Component, OnInit, Input, Injectable, ViewChild, Inject, NgModule, ChangeDetectorRef } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { MediaMatcher } from '@angular/cdk/layout';
import { BehaviorSubject ,  Observable, Subscription } from 'rxjs';
import { BrowserModule } from '@angular/platform-browser';
//Service
import { APIService } from '../../service/api.service'
import { LoaderService } from '../../loader/loader.service';
import { SpinnerService } from '../../spinner/spinner.service';
//Tabela
import { CdkTableModule } from '@angular/cdk/table';
import { MatTableDataSource, MatSort,MatButtonModule, MatTableModule, MatSortModule, MatPaginatorModule, MatIconModule, MatCardModule, MatFormFieldModule, MatInputModule,  MatPaginator, MatMenuModule, MatDialogModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//HTTP
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
//Forms
import { ReactiveFormsModule, FormControl, Validators, FormGroup, FormsModule } from '@angular/forms';
//Componentes
import { DetailsComponent } from '../details/details.component';
import { DetailstepperComponent } from '../detailstepper/details.component';
//Dialog
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { MatDialog } from '@angular/material/dialog';
// Router
import { Router, NavigationEnd } from '@angular/router';

import { AppComponent } from '../../app.component';

import { DialogComponent } from '../sessao/register/dialog/dialog.component';



// import { Component, OnInit, Input, Injectable, ViewChild, Inject, NgModule, SimpleChanges, ElementRef } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Observable, Subscription } from 'rxjs';
import { FormBuilder } from '@angular/forms';
// //Service
// import { APIService } from '../../service/api.service'
// import { LoaderService } from '../../loader/loader.service';
// import { SpinnerService } from '../../spinner/spinner.service';
import { UploadService } from '../../service/upload.service';
// // Router
// import { Router } from '@angular/router';


@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {

  //Root que vem do API SERVICE GLOBAL
  rootUrl:string;
  dConfig=[];
  dynamicClass="";
  listaobjPrincipalInserir=[];
  //Array que recebe dos dialog-open nos componentes
  dados:any;
  //Recebe array do RestAPI com boolean e msg
  result: any;
  //Subscribe do Dialog
  dialogSubscribe: Subscription;
  //Arrays usados
  par=[];
  impar=[];
  //
  bool_alterado:boolean;

  //UPLOAD FICHEIROS
  form: FormGroup;


  constructor(
      //UPLOAD FILES
      private uploadService: UploadService,
      private formBuilder: FormBuilder,
      private http: HttpClient,
      private apiService: APIService,
      private loader:LoaderService,
      private router: Router,
      private spinner:SpinnerService,
      private app:AppComponent
    ) {

    this.rootUrl = this.apiService.getRestServer();

    //this.http.get("http://www.mocky.io/v2/5ca21d723300009500d33e8e").subscribe(
    this.http.get("http://www.mocky.io/v2/5cb74da73200000314cd4a63").subscribe(

      data => {

        this.result = data;
        console.log(this.result);

        var str = this.result[0].dConfig.split(';').toString();
        str = str.replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\t/g, "\\t").replace(/\f/g, "\\f");
        var array = JSON.parse("[" + str + "]");
        this.dConfig.push(array);
        console.log("dConfig 1",this.dConfig[0]);
        console.log("dConfig 2",this.dConfig[0][0]);
        console.log("dConfig 3",this.dConfig[0][0][0]);
        console.log("dConfig 4",this.dConfig[0][0][0][0]);

        //PAR
        this.listaobjPrincipalInserir=[];
        for(var z=0; z<this.dConfig[0][0].length; z++){
          var temp=[];
          for (var i = 0; i < this.dConfig[0][0][z].length; i++) {
              if(i % 2 === 0) {
                temp.push(this.dConfig[0][0][z][i]);
              }
          }
          this.par.push(temp);
          //IMPAR
          var temp=[];
          var temp1=[];
          for (var i = 0; i < this.dConfig[0][0][z].length; i++) {

              if(i % 2 !== 0) {
                temp.push(this.dConfig[0][0][z][i]);

                for(var t=0; t<this.dConfig[0][0][z][i].length; t++){
                  if (this.dConfig[0][0][z][i][t][0]=="99_IDP"){
                    temp1.push({ index: temp.length-1 , title: this.dConfig[0][0][z][i][t][2], dbid: this.dConfig[0][0][z][i][t][1], value: this.dados.ID, tipo: this.dConfig[0][0][z][i][t][4]});
                  }else if(this.dConfig[0][0][z][i][t][4] == 8){
                    var stringToInt = +this.dConfig[0][0][z][i][t][0];
                    temp1.push({ index: temp.length-1 , title: this.dConfig[0][0][z][i][t][2], dbid: this.dConfig[0][0][z][i][t][1], value: stringToInt, tipo: this.dConfig[0][0][z][i][t][4]});
                  }else if (this.dConfig[0][0][z][i][t][4] == 10){
                    temp1.push({ index: temp.length-1 , title: this.dConfig[0][0][z][i][t][2], dbid: this.dConfig[0][0][z][i][t][1], value: this.dConfig[0][0][z][i][t][0], tipo: this.dConfig[0][0][z][i][t][4], funcao: this.dConfig[0][0][z][i][t][0]});
                  }else{
                    temp1.push({ index: temp.length-1 , title: this.dConfig[0][0][z][i][t][2], dbid: this.dConfig[0][0][z][i][t][1], value: this.dConfig[0][0][z][i][t][0], tipo: this.dConfig[0][0][z][i][t][4]});
                  }
                }

              }
          }
          this.impar.push(temp);
          this.listaobjPrincipalInserir.push(temp1);
        }

        console.log("ARRAY par: ", this.par);
        console.log("ARRAY impar: ", this.impar);
        console.log("this.listaobjPrincipalInserir: ",  this.listaobjPrincipalInserir);

        console.log("O QUE QUERO: ", this.impar[0][0][3]);

      }, erro => {
    		console.log(erro);
    	}
    );
  }

  ngOnInit() {
    //UPLOAD FICHEIROS
    this.form = this.formBuilder.group({
       file: ['']
     });
   }

   regista(){
     console.log("NO REGISTAR!!!!");
   }

   // tipoFuncao(var1,var2){
   //   console.log("OLHAAA:",this.listaobjPrincipalInserir[var1][var2].funcao)
   // }


   exit(){
     this.app.navbarMostra(1);
   }


   //--------------------------- INICIO UPLOAD IMAGEM em FASE DE DESENVOLVIMENTO
      nameFile:string;
      btnShow:boolean;

       onFileSelect(event) {
        if (event.target.files.length > 0) {
          const file = event.target.files[0];
          this.form.get('file').setValue(file);
          this.nameFile = file.name;
          this.btnShow = true;
        }
       }

       onSubmit() {
         //FALTA AGRUMENTOS
        // const formData = new FormData();
        // formData.append('file', this.form.get('file').value);
        //
        // //chama spinner e injeta frase que queros mostrar
        // this.spinner.show("Aguarde, a fazer upload para a nuvem!");
        // this.uploadService.uploadFile(formData).subscribe(
        //   (res) => {
        //     this.spinner.hide()
        //     this.result = res;
        //
        //     if(this.result){
        //       this.apiService.showConfirmation(this.result.titulo,this.result.mensagem, this.result.tipoAlerta, this.result.textoBotaoCancelar, this.result.textoBotaoOk, this.result.botaoCancelar,this.result.timer,this.result.botaoConfirmar);
        //       this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe((borrower) => {
        //         if(borrower == true){
        //             this.reset();
        //             //sempre ncessario
        //             this.dialogSubscribe.unsubscribe();
        //             this.apiService.changeValue(null);
        //         }else if(borrower == false){
        //           console.log("lá vai ele repetir");
        //           //sempre ncessario
        //           this.dialogSubscribe.unsubscribe();
        //           this.apiService.changeValue(null);
        //         }
        //       });
        //     }
        //   },
        //   (err) => {
        //     console.log(err);
        //   }
        // );
       }

      reset() {
        this.btnShow = false;
        this.nameFile = "";
      }


   //--------------------------- FIM UPLOAD IMAGEM em FASE DE DESENVOLVIMENTO


  //Não repete inputs varias vezes
  fazSoUmaVez(indexDaLista, campo, repeticoes){
    if(repeticoes < 1){
      return true;
    }else{
      return false;
    }
  }

  classDiv(array){
    var num;
    num = array.length;
    //console.log("ESTOU AQUI DENTRO DO CLASS DIV: ", num);
    if(num == 1){
      this.dynamicClass="col-lg-12";
    }
    if(num == 2){
      this.dynamicClass="col-lg-6";
    }
    if(num == 3){
      this.dynamicClass="col-lg-4";
    }
    if(num == 4){
      this.dynamicClass="col-lg-3";
    }

    //console.log("this.dynamicClass: ", this.dynamicClass);
    return this.dynamicClass;
  }


  estado(estado, val1,val2, dbid1=0,value1=0,dbid2=0,value2=0,nivel=0) {
    // Estado = 0 vimos do edit. carregamos pela primeira vez na caneta
    // Estado = 1 cancelamos a edição
    // Estado = 2 confirmamos a edição
    // val2 = -1 se estivermos em primário ou então estamos em linhas e é preciso colocar o on_in no ipt
    console.log("INFO::::: ",estado, dbid1,value1,dbid2,value2,nivel);

    if(val2 != -1){
        val1=val1+"_"+val2;
    }
    //console.log("dbid1=",dbid1,"value1=",value1,"dbid2=",dbid2,"value2=",value2,"nivel=",nivel);
    var elementReference = <HTMLInputElement> document.getElementById("ipt"+val1);
    //console.log("ipt atual: ", "ipt"+val1);
    var elementReference1 = <HTMLInputElement> document.getElementById("icnEDIT"+val1);
    //console.log("icon atual: ", "icnEDIT"+val1);
    var elementReference2 = <HTMLInputElement> document.getElementById("icnCHECK"+val1);
    //console.log("icon atual: ", "icnCHECK"+val1);
    var elementReference3 = <HTMLInputElement> document.getElementById("icnCANCEL"+val1);
    //console.log("icon atual: ", "icnCANCEL"+val1);

    if(estado>0){

      this.bool_alterado = true;
      elementReference.disabled = true;
      elementReference1.innerHTML = "edit";
      elementReference2.innerHTML = "";
      elementReference3.innerHTML = "";

      if (estado==2){
        console.log("UPDATE estado = 0: ",dbid1,value1,dbid2,value2,nivel);
        //this.updateField(dbid1,value1,dbid2,value2,nivel);

      }

    }else if(estado<0){
      this.bool_alterado = !this.bool_alterado;
      elementReference1.innerHTML == "edit" ? elementReference1.innerHTML = "" : elementReference1.innerHTML = "edit";
      elementReference3.innerHTML == "cancel" ? elementReference3.innerHTML = "" : elementReference3.innerHTML = "cancel";
      if (estado==-2){
        console.log("UPDATE estado < 0: ",dbid1,value1,dbid2,value2,nivel);
        //this.updateField(dbid1,value1,dbid2,value2,nivel);
      }
    }else{//vai para 0
      this.bool_alterado = true;
      elementReference.disabled = false;
      elementReference1.innerHTML = "";
      elementReference2.innerHTML = "check_circle";
      elementReference3.innerHTML = "cancel";
    }
  }

}





// rootUrl:string;
//
// //Registar
// result: any;
// utilizador : string;
// nome : string;
// Password : string;
// Email : string;
//
// //RGPD_LOGIN
// IDUser:string;
// IDCliente:string;
//
// dialogSubscribe: Subscription;
//
// constructor(private apiService: APIService, public dialog: MatDialog, private http: HttpClient, private loader:LoaderService, private router: Router, private spinner:SpinnerService, private app:AppComponent) {
//   this.rootUrl = this.apiService.getRestServer();
// }
//
// ngOnInit() {
//
// }
//
// exit(){
//   this.app.navbarMostra(1);
// }
//
// register() : void {
//   if(this.utilizador != null || this.nome != null || this.Password != null || this.Email != null) {
//     const body = new HttpParams().set(`utilizador`, this.utilizador).set(`pswd`, this.Password).set(`nome`, this.nome).set(`email`, this.Email);
//     const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
//     console.log(this.rootUrl + 'register?'+body.toString()+'&token='+this.apiService.getToken());
//     this.http.post(this.rootUrl + 'register?'+body.toString()+'&token='+this.apiService.getToken(), { headers: headers })
//     .subscribe(data =>
//       {
//         this.result = data;
//
//         if(this.result.dados.Estado == true){
//           alert(this.result.dados.Mensagem);
//           this.utilizador = '';
//           this.nome = '';
//           this.Password = '';
//           this.Email = '';
//         }else{
//           alert(this.result.dados.Mensagem);
//         }
//       }, err => {
//         console.log(err);
//       }
//     );
//   }else{
//     this.apiService.showConfirmation("Alerta","Preencha todos os campos", "warning", "", "OK", false);
//
//     this.dialogSubscribe = this.apiService.borrowerChangedObservable.subscribe(
//       (borrower) => {
//         if(borrower == true){
//
//           //sempre necessario
//           this.dialogSubscribe.unsubscribe();
//           this.apiService.changeValue(null);
//         }else if(borrower == false){
//
//           //sempre necessario
//           this.dialogSubscribe.unsubscribe();
//           this.apiService.changeValue(null);
//         }
//       });
//   }
// }

// RGPD_LOGIN(){
//   if(this.IDUser != null) {
//     if(confirm("Tem a certeza que pretende RGPD user: "+this.IDUser)){
//       this.http.get(this.rootUrl + '/rgpd/login/'+ this.IDUser)
//   		.subscribe(data =>
//   			{
//           this.result = data;
//
//           if(this.result.dados.Estado == true){
//             alert(this.result.dados.Mensagem);
//             this.IDUser = '';
//           }else{
//             alert(this.result.dados.Mensagem);
//           }
//
//         }, err => {
//   				console.log(err);
//   			}
//   		);
//     }else{
//       alert("Processo cancelado");
//     }
//   }else{
//     alert("Insira ID do User.");
//   }
// }
//
// RGPD_XML_LOGIN(){
//   if(this.IDUser == null){
//     alert("Insira ID do User.");
//   }else{
//     window.open(this.rootUrl+'/xml/login/'+this.IDUser, "_blank");
//   }
// }
//
// RGPD_ATUALIZAR_LOGIN(){
//   if(this.IDUser == null){
//     alert("Insira ID do User.");
//   }else{
//     const dialogRef = this.dialog.open(DialogComponent, {
//       width: '50%',
//       height: '75%',
//       disableClose: true,
//       data: {
//         //Path que vem do HTML com campos da tabela proveniente da DB
//         path: this.IDUser,
//         //Para dialog saber onde ta
//         angular_path: 'user'
//       }
//     });
//   }
// }
//
// RGPD_CLIENTE(){
//   if(this.IDCliente != null) {
//     if(confirm("Tem a certeza que pretende RGPD cliente: "+this.IDCliente)){
//       this.http.get(this.rootUrl + '/rgpd/cliente/'+ this.IDCliente)
//   		.subscribe(data =>
//   			{
//   				console.log("RGPD: ", data);
//
//         }, err => {
//   				console.log(err);
//   			}
//   		);
//     }else{
//       alert("Processo cancelado");
//     }
//   }else{
//     alert("Insira ID do Cliente.");
//   }
// }
//
// RGPD_XML_CLIENTE(){
//   if(this.IDCliente == null){
//     alert("Insira ID do Cliente.");
//   }else{
//     window.open(this.rootUrl+'/xml/cliente/'+this.IDCliente, "_blank");
//   }
// }
//
// RGPD_ATUALIZAR_CLIENTE(){
//   if(this.IDCliente == null){
//     alert("Insira ID do Cliente.");
//   }else{
//     const dialogRef = this.dialog.open(DialogComponent, {
//       width: '50%',
//       height: '75%',
//       disableClose: true,
//       data: {
//         //Path que vem do HTML com campos da tabela proveniente da DB
//         path: this.IDCliente,
//         //Para dialog saber onde ta
//         angular_path: 'cliente'
//       }
//     });
//   }
// }
