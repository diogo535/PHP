import { Component,OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient,HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';
import { APIService } from './service/api.service';
import { Title } from '@angular/platform-browser';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
  dataRefresher: any;
  rootUrl:string;
  cont:number;
  closeResult: string;
  result: any;
  bool:boolean = true;

  constructor(public router: Router, private http: HttpClient, private service: APIService, private titleService: Title) {
    this.rootUrl = this.service.getRestServer();
    this.mudaCor();
  }

  ngOnInit() {
    this.refreshData();
    this.titleService.setTitle(this.service.getBrandName());
  }

  mudaCor(){
    //muda cor
    var cor = localStorage.getItem('platformColour');
    if(cor){
      //console.log("LEVA PERSONALIZADO");
      document.documentElement.style.setProperty('--background', cor);
      document.documentElement.style.setProperty('--backgroundSecundary', this.service.adjustColor(cor,75));
    }else{
      //console.log("LEVA DEFAULT");
      document.documentElement.style.setProperty('--background', '#0080ff');
      document.documentElement.style.setProperty('--backgroundSecundary', '#64e4ff');
    }
  }

  navbarEsconde(val=0){
    if(val == 1){
      this.bool = false;
    }
  }

  navbarMostra(val=0){
    if(val == 1){
      this.bool = true;
    }
  }

  refreshData(){
    this.dataRefresher =
      setInterval(() => {
        this.service.destinoToken();
     }, 180000 );
  }

}
