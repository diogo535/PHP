export class Componente {
  selector: string;
  tipo_formulario: number;
  componente_angular: string;
  pathTitle: string;
  angular_path: string;
  ondevou: string;
  uri_consultar: string;
  uri_gravar: string;
  uri_alterar: string;
  uri_apagar: string;
}
